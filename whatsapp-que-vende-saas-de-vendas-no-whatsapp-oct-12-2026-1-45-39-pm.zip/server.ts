import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
dotenv.config();

import {
  generateCustomerReply,
  generateCustomerReplyStream,
  generateTrainingHint,
  generateTrainingEvaluation,
  transcribeAudioWithGemini,
} from './src/services/trainingAiService';
import {
  sendVerificationEmail,
  getEmailServiceConfig,
  verifySmtpConnection,
} from './src/services/mailService';
import {
  handleRegister,
  handleLogin,
  handleRequestPasswordReset,
  handleResetPasswordWithToken,
} from './src/services/serverAuthService';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  
  // Resolve port: prioritize --port CLI arg (passed by supervisor), then DEFAULT_APP_PORT, always defaulting to 3000
  const portArgIndex = process.argv.indexOf('--port');
  const cliPort = portArgIndex !== -1 && process.argv[portArgIndex + 1] ? parseInt(process.argv[portArgIndex + 1], 10) : null;
  const PORT = cliPort || (process.env.DEFAULT_APP_PORT ? parseInt(process.env.DEFAULT_APP_PORT, 10) : 3000);

  app.use(express.json({ limit: '15mb' }));

  // API Route: Status da configuração do serviço de e-mail
  app.get('/api/auth/email-status', (_req, res) => {
    const status = getEmailServiceConfig();
    return res.json(status);
  });

  // API Route: Testar e verificar conectividade do servidor SMTP
  app.get('/api/auth/verify-smtp', async (_req, res) => {
    const verification = await verifySmtpConnection();
    return res.json(verification);
  });

  // API Routes: Autenticação direta e Recuperação de Senha
  app.post('/api/auth/register', handleRegister);
  app.post('/api/auth/login', handleLogin);
  app.post('/api/auth/request-password-reset', handleRequestPasswordReset);
  app.post('/api/auth/reset-password', handleResetPasswordWithToken);

  // API Route: Enviar e-mail de verificação com código de 6 dígitos
  app.post('/api/auth/send-verification', async (req, res) => {
    try {
      const { email, name, code } = req.body;
      if (!email || !code) {
        return res.status(400).json({ success: false, error: 'E-mail e código são obrigatórios.' });
      }
      const result = await sendVerificationEmail({ to: email, name, code });
      return res.json(result);
    } catch (err: any) {
      console.error('[API /api/auth/send-verification] Error:', err);
      return res.status(500).json({
        success: false,
        delivered: false,
        error: err.message || 'Falha ao processar envio do e-mail de verificação.',
      });
    }
  });

  // API Route: Transcrever áudio via Gemini (quando WebSpeechAPI não estiver disponível no browser ou em iframe)
  app.post('/api/training/transcribe', async (req, res) => {
    try {
      const { audioBase64, mimeType } = req.body;
      if (!audioBase64) {
        return res.status(400).json({ error: 'audioBase64 é obrigatório.' });
      }
      const transcript = await transcribeAudioWithGemini(audioBase64, mimeType || 'audio/webm');
      return res.json({ transcript });
    } catch (err: any) {
      console.error('[API /api/training/transcribe] Error:', err);
      return res.status(500).json({ error: err.message || 'Erro ao transcrever áudio.' });
    }
  });

  // API Route: Gerar resposta do cliente simulado (Streaming via SSE para latência zero)
  app.get('/api/training/reply-stream', async (req, res) => {
    try {
      const configParam = req.query.config ? JSON.parse(decodeURIComponent(req.query.config as string)) : null;
      const messagesParam = req.query.messages ? JSON.parse(decodeURIComponent(req.query.messages as string)) : null;
      const modalityTitle = (req.query.modalityTitle as string) || 'Treinamento de Vendas';

      if (!configParam || !Array.isArray(messagesParam)) {
        return res.status(400).json({ error: 'Parâmetros config e messages são obrigatórios.' });
      }

      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.flushHeaders();

      for await (const chunk of generateCustomerReplyStream(configParam, messagesParam, modalityTitle)) {
        res.write(`data: ${JSON.stringify({ chunk })}\n\n`);
      }

      res.write('data: [DONE]\n\n');
      res.end();
    } catch (err: any) {
      console.error('[API /api/training/reply-stream] Error:', err);
      res.write(`data: ${JSON.stringify({ error: err.message || 'Erro na transmissão.' })}\n\n`);
      res.end();
    }
  });

  // API Route: Gerar resposta do cliente simulado (Fallback JSON instantâneo)
  app.post('/api/training/reply', async (req, res) => {
    try {
      const { config, messages, modalityTitle } = req.body;
      if (!config || !Array.isArray(messages)) {
        return res.status(400).json({ error: 'Parâmetros config e messages são obrigatórios.' });
      }

      const reply = await generateCustomerReply(config, messages, modalityTitle || 'Treinamento de Vendas');
      return res.json({ reply });
    } catch (err: any) {
      console.error('[API /api/training/reply] Error:', err);
      return res.status(500).json({ error: err.message || 'Erro ao processar resposta do simulador.' });
    }
  });

  // API Route: Gerar dica contextual do mentor pedagógico
  app.post('/api/training/hint', async (req, res) => {
    try {
      const { config, messages, modalityTitle } = req.body;
      if (!config || !Array.isArray(messages)) {
        return res.status(400).json({ error: 'Parâmetros config e messages são obrigatórios.' });
      }

      const hint = await generateTrainingHint(config, messages, modalityTitle || 'Treinamento');
      return res.json({ hint });
    } catch (err: any) {
      console.error('[API /api/training/hint] Error:', err);
      return res.status(500).json({ error: err.message || 'Erro ao gerar dica.' });
    }
  });

  // API Route: Gerar avaliação final completa (executada somente após encerramento)
  app.post('/api/training/evaluate', async (req, res) => {
    try {
      const { config, messages, modalityTitle } = req.body;
      if (!config || !Array.isArray(messages)) {
        return res.status(400).json({ error: 'Parâmetros config e messages são obrigatórios.' });
      }

      const evaluation = await generateTrainingEvaluation(config, messages, modalityTitle || 'Treinamento');
      return res.json({ evaluation });
    } catch (err: any) {
      console.error('[API /api/training/evaluate] Error:', err);
      return res.status(500).json({ error: err.message || 'Erro ao gerar avaliação.' });
    }
  });

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Vite integration (dev & prod)
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`[WhatsApp que Vende] Servidor operacional na porta ${PORT}`);
  });

  server.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      console.warn(`[Servidor] Porta ${PORT} em uso. Tentando novamente em 1.5s...`);
      setTimeout(() => {
        server.close();
        server.listen(PORT, '0.0.0.0');
      }, 1500);
    } else {
      console.error('[Servidor] Erro no servidor HTTP:', err);
    }
  });

  process.on('SIGTERM', () => {
    server.close(() => process.exit(0));
  });

  process.on('SIGINT', () => {
    server.close(() => process.exit(0));
  });

  process.on('unhandledRejection', (reason) => {
    console.warn('[Servidor] Unhandled rejection:', reason);
  });
}

startServer().catch((err) => {
  console.error('Falha crítica ao iniciar o servidor:', err);
  process.exit(1);
});
