export type ScreenType =
  | 'login'
  | 'dashboard'
  | 'academy'
  | 'training'
  | 'library'
  | 'message-detail'
  | 'method'
  | 'search'
  | 'favorites'
  | 'profile'
  | 'professions'
  | 'challenge'
  | 'ai-prompts'
  | 'settings';

export type CategoryId =
  | 'primeiro-contato'
  | 'entender-cliente'
  | 'apresentar-preco'
  | 'objecoes'
  | 'follow-up'
  | 'recuperacao'
  | 'fechamento'
  | 'pos-venda';

export interface Category {
  id: CategoryId;
  name: string;
  description: string;
  iconName: string;
  badgeCount: number;
  color: string;
}

export interface MessageItem {
  id: string;
  title: string;
  situation: string;
  content: string;
  explanation: string;
  category: CategoryId;
  methodStage: 1 | 2 | 3 | 4 | 5 | 6; // 1: Atrair, 2: Entender, 3: Conectar, 4: Apresentar, 5: Contornar, 6: Fechar
  tone: 'Direto' | 'Consultivo' | 'Empático' | 'Persuasivo' | 'Descontraído';
  professionTags?: string[];
  viewsCount: number;
  tips?: string[];
  doNotSay?: string;
  suggestedFollowUp?: string;
}

export interface MethodStageInfo {
  number: 1 | 2 | 3 | 4 | 5 | 6;
  name: string;
  subtitle: string;
  description: string;
  objective: string;
  keyRule: string;
  relatedCategory: CategoryId;
  messagesCount: number;
  badge: string;
}

export interface AttendanceOption {
  id: string;
  title: string;
  tone: 'Consultivo' | 'Direto' | 'Persuasivo' | 'Empático' | 'Descontraído';
  text: string;
  whenToUse: string;
  whyItWorks: string;
  faoPillar?: 'Filtro (F)' | 'Alinhamento (A)' | 'Objeção & Agendamento (O)';
}

export interface AttendanceSituation {
  id: string;
  number: number;
  title: string;
  stageName: string;
  description: string;
  faoPillar: 'Filtro (F)' | 'Alinhamento (A)' | 'Objeção & Agendamento (O)';
  iconName: string;
  options: AttendanceOption[];
}

export type ProfessionCategoryId =
  | 'veiculos'
  | 'imoveis'
  | 'comercio-varejo'
  | 'beleza-estetica'
  | 'servicos-profissionais'
  | 'vendas-online'
  | 'vendas-consultivas'
  | 'saude-fitness';

export interface ProfessionNiche {
  id: string;
  name: string;
  icon: string;
  description: string;
  commonObjection: string;
  typicalTicket: string;
  categoryId?: ProfessionCategoryId;
  badge?: string;
  sampleMessages: {
    title: string;
    situation: string;
    text: string;
    tip: string;
  }[];
  attendanceSituations?: AttendanceSituation[];
  aiContext?: {
    roleDescription: string;
    typicalObjections: string[];
    discoveryQuestions: string[];
    evaluationCriteria: string[];
    recommendedTechniques: string[];
  };
}

export interface ProfessionCategory {
  id: ProfessionCategoryId;
  title: string;
  emoji: string;
  description: string;
  professions: ProfessionNiche[];
}

export interface ChallengeDayItem {
  day: number;
  title: string;
  stageName: string;
  objective: string;
  task: string;
  readyMessage: string;
  proTip: string;
  completed: boolean;
}

export interface AIPromptTemplate {
  id: string;
  title: string;
  category: 'criar' | 'melhorar' | 'objecoes' | 'followup' | 'profissao';
  description: string;
  variables: { key: string; label: string; placeholder: string; defaultValue?: string }[];
  template: string;
}

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  profession: string;
  businessType: string;
  tonePreference: 'Direto' | 'Consultivo' | 'Empático' | 'Persuasivo';
  autoCopySignature: boolean;
  businessSignature?: string;
  avatarUrl?: string;
  customProfession?: {
    name: string;
    productOrService: string;
    targetAudience: string;
    commonObjection?: string;
  };

  // SaaS subscription & access fields
  accessStatus: 'active' | 'pending' | 'inactive';
  plan: 'free' | 'paid';
  emailVerified?: boolean;
  verificationCode?: string;
  emailVerificationSentAt?: string;
  purchaseId?: string;
  purchaseDate?: string;
  accessExpiresAt?: string;
  createdAt?: string;
  updatedAt?: string;
}

// -------------------------------------------------------------
// Tipos para o Treinamento de Vendas com IA (IA Simula Cliente)
// -------------------------------------------------------------

export type TrainingModalityId =
  | 'primeiro-contato'
  | 'descoberta-necessidades'
  | 'conexao-confianca'
  | 'apresentacao-preco'
  | 'objecoes'
  | 'apresentacao-orcamento'
  | 'follow-up'
  | 'recuperacao-clientes'
  | 'negociacao'
  | 'fechamento'
  | 'agendamento'
  | 'treinamento-completo';

export type CustomerProfileType =
  | 'indeciso'
  | 'desconfiado'
  | 'apressado'
  | 'sensivel-preco'
  | 'muito-interessado';

export type DifficultyLevel = 'iniciante' | 'intermediario' | 'avancado';

export type TrainingInteractionMode = 'text' | 'voice';

export interface TrainingModality {
  id: TrainingModalityId;
  title: string;
  shortTitle: string;
  emoji: string;
  description: string;
  scenarioDefault: string;
  initialCustomerMessage: string;
  categoryTag: string;
  skillsFocus: string[];
}

export interface TrainingConfig {
  modalityId: TrainingModalityId;
  productOrService: string;
  specificItem?: string;
  customerProfile: CustomerProfileType;
  difficulty: DifficultyLevel;
  commercialDetails?: string;
  professionId?: string;
  professionName?: string;
  interactionMode?: TrainingInteractionMode; // 'text' | 'voice'
  autoSendVoice?: boolean;
  autoPlayAudio?: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'customer' | 'user';
  text: string;
  timestamp: string;
  audioVoiceType?: 'spoken' | 'transcribed';
  audioDuration?: string;
  audioUrl?: string;
  transcript?: string;
}

export interface SkillScore {
  name: string;
  score: number; // 0 a 100
  comment: string;
}

export interface MessageAnalysisItem {
  userMessageSnippet: string;
  whatWorked: string;
  whatCouldImprove: string;
  whyItMatters: string;
}

export interface TrainingEvaluation {
  overallScore: number; // 0 a 100
  scoreExplanation: string;
  skillScores: SkillScore[];
  whatWentWell: string[];
  whatToImprove: string[];
  messageAnalysis: MessageAnalysisItem[];
  betterResponseExamples: { context: string; suggestedMessage: string; explanation: string }[];
  recommendedChallengeId: TrainingModalityId;
  recommendedChallengeReason: string;
}

export interface TrainingSession {
  id: string;
  userId: string;
  modalityId: TrainingModalityId;
  modalityTitle: string;
  config: TrainingConfig;
  messages: ChatMessage[];
  evaluation?: TrainingEvaluation;
  status: 'active' | 'paused' | 'completed';
  createdAt: string;
  updatedAt?: string;
  completedAt?: string;
}

// -------------------------------------------------------------
// ACADEMIA DE VENDAS COM IA (TREINADOR PESSOAL DE VENDAS)
// -------------------------------------------------------------

export type AcademyLevelNumber = 1 | 2 | 3 | 4;

export interface AcademyLevel {
  level: AcademyLevelNumber;
  name: string;
  tagline: string;
  description: string;
  badge: string;
  color: string;
  minCompletedSessions: number;
}

export type SalesTechniqueId =
  | 'spin-selling'
  | 'aida'
  | 'venda-consultiva'
  | 'tratamento-objecoes'
  | 'tecnicas-fechamento'
  | 'atendimento-relacionamento';

export interface SalesTechnique {
  id: SalesTechniqueId;
  title: string;
  shortName: string;
  emoji: string;
  category: string;
  level: AcademyLevelNumber;
  simpleExplanation: string;
  howItWorks: string[];
  whenToUse: string;
  poorApproachExample: string;
  improvedApproachExample: string;
  nicheSpecificExampleTip: string;
  practicalExercise: {
    title: string;
    description: string;
    taskPrompt: string;
    sampleSolution: string;
  };
  recommendedModalityId: TrainingModalityId;
  customerProfileDefault: CustomerProfileType;
}

export interface PracticalChallenge {
  id: string;
  title: string;
  techniqueId: SalesTechniqueId;
  level: AcademyLevelNumber;
  emoji: string;
  scenario: string;
  customerMessage: string;
  instruction: string;
  exampleGoodAnswer: string;
  whyItWorks: string;
}

export interface UserDiagnostic {
  niche: string;
  productSold: string;
  targetAudience: string;
  biggestDifficulty: string;
  skillToImprove: string;
  completedAt?: string;
}

export interface AcademyProgress {
  userId: string;
  currentLevel: AcademyLevelNumber;
  completedLessonIds: string[];
  completedChallengeIds: string[];
  diagnostic?: UserDiagnostic;
  recommendedTechniqueId: SalesTechniqueId;
  recommendationReason: string;
  lastUpdated: string;
}
