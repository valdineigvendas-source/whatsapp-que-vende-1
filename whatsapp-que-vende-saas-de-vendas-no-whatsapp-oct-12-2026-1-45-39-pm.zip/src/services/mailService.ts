import nodemailer from 'nodemailer';

export interface SendMailOptions {
  to: string;
  name?: string;
  code: string;
}

export interface MailDispatchResult {
  success: boolean;
  delivered: boolean;
  provider: 'smtp' | 'resend' | 'brevo' | 'sendgrid' | 'none';
  message: string;
  messageId?: string;
  error?: string;
  needsConfig?: boolean;
  isResendSandboxRestricted?: boolean;
  sandboxOwnerEmail?: string;
  sandboxCode?: string;
}

/**
 * Creates and returns a Nodemailer Transporter based on SMTP environment variables.
 * Prioritizes:
 * - SMTP_HOST (e.g. smtp.gmail.com or smtp.resend.com)
 * - SMTP_PORT (defaults to 587)
 * - SMTP_USER (e.g. seu-email@gmail.com)
 * - SMTP_PASS (senha de app ou credencial SMTP)
 * - SMTP_SECURE ('true' for SSL on 465, false for STARTTLS on 587)
 */
export function getSmtpTransporter() {
  const preferGmail =
    process.env.EMAIL_PROVIDER?.toLowerCase() === 'gmail' ||
    process.env.SMTP_PROVIDER?.toLowerCase() === 'gmail' ||
    (process.env.SMTP_HOST || '').toLowerCase().includes('gmail') ||
    (process.env.SMTP_USER || '').toLowerCase().includes('@gmail.com');

  const host = preferGmail
    ? 'smtp.gmail.com'
    : (process.env.SMTP_HOST || process.env.MAIL_HOST || process.env.EMAIL_HOST);

  const user = preferGmail
    ? (process.env.SMTP_USER || process.env.MAIL_USER || 'suportewppquevende@gmail.com')
    : (process.env.SMTP_USER || process.env.MAIL_USER || process.env.EMAIL_USER);

  const rawPass = process.env.SMTP_PASS || process.env.MAIL_PASS || process.env.EMAIL_PASS;
  // Automatically strip spaces if the user pastes a Google App Password formatted with spaces (e.g. "abcd efgh ijkl mnop")
  const pass = rawPass ? rawPass.trim().replace(/\s+/g, '') : '';
  const rawPort = process.env.SMTP_PORT || process.env.MAIL_PORT || process.env.EMAIL_PORT || '587';
  const port = parseInt(rawPort, 10);
  const secure = process.env.SMTP_SECURE === 'true' || port === 465;

  if (!host || !user || !pass) {
    return null;
  }

  // Dedicated Gmail transport optimization via Nodemailer service: 'gmail'
  if (host.includes('gmail.com') || preferGmail) {
    return nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user,
        pass,
      },
      tls: {
        rejectUnauthorized: false,
      },
      connectionTimeout: 15000,
      greetingTimeout: 15000,
      socketTimeout: 20000,
    });
  }

  // Create transporter with production-ready timeouts and TLS handling
  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: {
      user,
      pass,
    },
    tls: {
      // Helps avoid self-signed or proxy TLS errors across cloud container networks
      rejectUnauthorized: false,
    },
    connectionTimeout: 15000,
    greetingTimeout: 15000,
    socketTimeout: 20000,
  });
}

/**
 * Verifies active SMTP connection.
 */
export async function verifySmtpConnection(): Promise<{
  configured: boolean;
  connected: boolean;
  message: string;
  host?: string;
  user?: string;
  error?: string;
}> {
  const preferGmail =
    process.env.EMAIL_PROVIDER?.toLowerCase() === 'gmail' ||
    process.env.SMTP_PROVIDER?.toLowerCase() === 'gmail' ||
    (process.env.SMTP_HOST || '').toLowerCase().includes('gmail') ||
    (process.env.SMTP_USER || '').toLowerCase().includes('@gmail.com');

  const host = preferGmail
    ? 'smtp.gmail.com'
    : (process.env.SMTP_HOST || process.env.MAIL_HOST);
  const user = preferGmail
    ? (process.env.SMTP_USER || 'suportewppquevende@gmail.com')
    : (process.env.SMTP_USER || process.env.MAIL_USER);
  const rawPass = process.env.SMTP_PASS || process.env.MAIL_PASS || process.env.EMAIL_PASS || '';
  const pass = rawPass.trim().replace(/\s+/g, '');
  const transporter = getSmtpTransporter();

  if (!transporter) {
    return {
      configured: false,
      connected: false,
      message: 'Variáveis de ambiente SMTP incompletas. Defina SMTP_HOST, SMTP_PORT, SMTP_USER e SMTP_PASS.',
    };
  }

  try {
    await transporter.verify();
    return {
      configured: true,
      connected: true,
      message: `Conexão SMTP estabelecida com sucesso com ${host}!`,
      host: host || undefined,
      user: user || undefined,
    };
  } catch (err: any) {
    console.error('[MailService] Falha ao verificar conexão SMTP:', err.message);

    let diagnosticMsg = `Falha ao conectar ao servidor SMTP (${host}): ${err.message}`;
    if (preferGmail && (err.message?.includes('535') || err.message?.includes('BadCredentials'))) {
      diagnosticMsg = `Falha de login no Gmail para ${user}. `;
      if (pass.length !== 16) {
        diagnosticMsg += `Aviso: A Senha de App informada possui ${pass.length} letras. Senhas de App do Google possuem exatamente 16 letras (ex: abcd efgh ijkl mnop).`;
      } else {
        diagnosticMsg += `Verifique se a 'Verificação em duas etapas' está ativa na sua conta Google e crie uma nova Senha de App em myaccount.google.com/apppasswords.`;
      }
    }

    return {
      configured: true,
      connected: false,
      message: diagnosticMsg,
      host: host || undefined,
      user: user || undefined,
      error: err.message,
    };
  }
}

/**
 * Returns active email provider configuration details.
 */
export function getEmailServiceConfig() {
  const smtpHost = process.env.SMTP_HOST || process.env.MAIL_HOST || process.env.EMAIL_HOST;
  const smtpUser = process.env.SMTP_USER || process.env.MAIL_USER || process.env.EMAIL_USER;
  const smtpPass = process.env.SMTP_PASS || process.env.MAIL_PASS || process.env.EMAIL_PASS;

  if (smtpHost && smtpUser && smtpPass) {
    return {
      configured: true,
      provider: 'smtp' as const,
      host: smtpHost,
      user: smtpUser,
    };
  }

  if (process.env.RESEND_API_KEY) return { configured: true, provider: 'resend' as const };
  if (process.env.BREVO_API_KEY || process.env.SENDINBLUE_API_KEY) return { configured: true, provider: 'brevo' as const };
  if (process.env.SENDGRID_API_KEY) return { configured: true, provider: 'sendgrid' as const };

  return { configured: false, provider: 'none' as const };
}

/**
 * Sends a real verification email with 6-digit confirmation code.
 * Prioritizes SMTP via Nodemailer using SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS.
 */
export async function sendVerificationEmail({
  to,
  name,
  code,
}: SendMailOptions): Promise<MailDispatchResult> {
  const cleanEmail = to.trim().toLowerCase();
  const displayName = name?.trim() || 'Vendedor(a)';

  const htmlContent = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Código de Verificação • WhatsApp que Vende</title>
  <style>
    body { margin: 0; padding: 0; background-color: #070B0E; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #E2E8F0; }
    .wrapper { width: 100%; max-width: 580px; margin: 0 auto; padding: 32px 16px; box-sizing: border-box; }
    .card { background-color: #0D1419; border: 1px solid #1F2C34; border-radius: 16px; padding: 32px 24px; text-align: center; }
    .logo-badge { display: inline-block; width: 48px; height: 48px; line-height: 48px; background-color: #25D366; color: #0A1014; font-size: 24px; font-weight: 900; border-radius: 12px; margin-bottom: 16px; text-align: center; }
    h1 { font-size: 22px; font-weight: 800; color: #FFFFFF; margin: 0 0 10px; }
    p { font-size: 14px; line-height: 1.6; color: #94A3B8; margin: 0 0 20px; }
    .code-box { background-color: #121A21; border: 2px dashed #25D366; border-radius: 14px; padding: 20px; margin: 24px 0; }
    .code-label { font-size: 11px; text-transform: uppercase; letter-spacing: 1.5px; color: #25D366; font-weight: 700; margin-bottom: 6px; }
    .code { font-family: 'Courier New', Courier, monospace; font-size: 38px; font-weight: 900; letter-spacing: 10px; color: #FFFFFF; }
    .tip { font-size: 12px; color: #64748B; margin-top: 18px; line-height: 1.5; }
    .footer { font-size: 11px; color: #475569; text-align: center; margin-top: 24px; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="card">
      <div class="logo-badge">W</div>
      <h1>Confirmação de Cadastro</h1>
      <p>Olá, <strong>${displayName}</strong>!<br>Seu cadastro no <strong>WhatsApp que Vende</strong> foi iniciado. Utilize o código de 6 dígitos abaixo para verificar seu e-mail e desbloquear todos os treinamentos e recursos comerciais:</p>
      
      <div class="code-box">
        <div class="code-label">Seu Código de Acesso</div>
        <div class="code">${code}</div>
      </div>

      <p class="tip">⏱️ Este código expira em 30 minutos.<br>Se você não solicitou este cadastro, desconsidere esta mensagem com total segurança.</p>
    </div>
    <div class="footer">
      WhatsApp que Vende • Plataforma Inteligente de Treinamento Comercial
    </div>
  </div>
</body>
</html>
  `;

  const textContent = `Olá ${displayName}! Seu código de verificação no WhatsApp que Vende é: ${code}. Utilize este código para confirmar seu e-mail e desbloquear seu acesso.`;

  // 1. PRIORIDADE MÁXIMA: SMTP REAL VIA NODEMAILER (SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS)
  const transporter = getSmtpTransporter();
  if (transporter) {
    const preferGmail =
      process.env.EMAIL_PROVIDER?.toLowerCase() === 'gmail' ||
      process.env.SMTP_PROVIDER?.toLowerCase() === 'gmail' ||
      (process.env.SMTP_HOST || '').toLowerCase().includes('gmail') ||
      (process.env.SMTP_USER || '').toLowerCase().includes('@gmail.com');

    const smtpHost = preferGmail
      ? 'smtp.gmail.com'
      : (process.env.SMTP_HOST || process.env.MAIL_HOST || '');
    const smtpUser = preferGmail
      ? (process.env.SMTP_USER || process.env.MAIL_USER || 'suportewppquevende@gmail.com')
      : (process.env.SMTP_USER || process.env.MAIL_USER || '');

    let fromAddress =
      process.env.SMTP_FROM ||
      process.env.MAIL_FROM ||
      process.env.EMAIL_FROM;

    const replyToAddress = fromAddress || undefined;
    const isResendSmtp = smtpHost.toLowerCase().includes('resend.com');
    const isGmail = smtpHost.toLowerCase().includes('gmail.com');

    if (isGmail) {
      fromAddress = `"WhatsApp que Vende" <${smtpUser}>`;
    } else if (isResendSmtp) {
      // Resend requires verified domains or onboarding@resend.dev (public webmail like @gmail.com is rejected by Resend with 550)
      const isPublicWebmail = fromAddress && /@(gmail|hotmail|outlook|yahoo)\.com/i.test(fromAddress);
      if (!fromAddress || isPublicWebmail || fromAddress.toLowerCase().includes('resend')) {
        fromAddress = 'WhatsApp que Vende <onboarding@resend.dev>';
      }
    } else if (!fromAddress) {
      fromAddress = `"WhatsApp que Vende" <${smtpUser}>`;
    }

    try {
      console.log(`[MailService] Enviando e-mail via Nodemailer/SMTP (${smtpHost}) para ${cleanEmail} de ${fromAddress}...`);
      let info;
      try {
        info = await transporter.sendMail({
          from: fromAddress,
          to: cleanEmail,
          replyTo: replyToAddress,
          subject: `Código de Verificação: ${code} — WhatsApp que Vende`,
          html: htmlContent,
          text: textContent,
        });
      } catch (sendErr: any) {
        if (
          isResendSmtp &&
          fromAddress !== 'WhatsApp que Vende <onboarding@resend.dev>' &&
          (sendErr.message?.includes('not verified') || sendErr.message?.includes('550'))
        ) {
          console.warn('[MailService] Domínio não verificado no Resend. Alternando para onboarding@resend.dev...');
          info = await transporter.sendMail({
            from: 'WhatsApp que Vende <onboarding@resend.dev>',
            to: cleanEmail,
            replyTo: replyToAddress,
            subject: `Código de Verificação: ${code} — WhatsApp que Vende`,
            html: htmlContent,
            text: textContent,
          });
        } else {
          throw sendErr;
        }
      }

      console.log(`[MailService] E-mail enviado com sucesso via SMTP! Message ID: ${info.messageId}`);
      return {
        success: true,
        delivered: true,
        provider: 'smtp',
        messageId: info.messageId,
        message: 'E-mail de verificação enviado com sucesso via SMTP!',
      };
    } catch (err: any) {
      console.error(`[MailService] Erro ao enviar e-mail via SMTP (${smtpHost}):`, err.message);

      // Detect Gmail BadCredentials
      if (isGmail && (err.message?.includes('535') || err.message?.includes('BadCredentials'))) {
        const rawPass = process.env.SMTP_PASS || '';
        const pass = rawPass.trim().replace(/\s+/g, '');
        let gmailErr = `Erro de autenticação no Gmail (${smtpUser}): Senha de App incorreta. `;
        if (pass.length !== 16) {
          gmailErr += `A Senha de App configurada possui ${pass.length} letras (Senhas de App do Google têm obrigatoriamente 16 letras, ex: abcd efgh ijkl mnop).`;
        } else {
          gmailErr += `Verifique se a 'Verificação em 2 etapas' está ativada e crie uma nova Senha de App em myaccount.google.com/apppasswords.`;
        }
        return {
          success: false,
          delivered: false,
          provider: 'smtp',
          error: err.message,
          message: gmailErr,
        };
      }

      // Detect Resend sandbox limitation (can only send to owner email)
      const isSandboxLimitation =
        err.message?.includes('You can only send testing emails to your own email address') ||
        err.message?.includes('verify a domain at resend.com/domains');

      if (isSandboxLimitation) {
        const ownerMatch = err.message.match(/\(([^)]+)\)/);
        const ownerEmail = ownerMatch ? ownerMatch[1] : 'valdineigvendas@gmail.com';
        console.warn(
          `[MailService] ⚠️ Resend Sandbox ativo: envio para ${cleanEmail} bloqueado pelo Resend pois não possui domínio próprio verificado. Restrito ao e-mail ${ownerEmail}.`
        );

        return {
          success: true, // Do not break registration
          delivered: false,
          provider: 'smtp',
          isResendSandboxRestricted: true,
          sandboxOwnerEmail: ownerEmail,
          sandboxCode: code,
          error: err.message,
          message: `Servidor em modo de teste (Resend Sandbox). No momento, a Resend só entrega para ${ownerEmail}. Para entregar para qualquer e-mail de cliente, verifique um domínio em resend.com/domains.`,
        };
      }

      return {
        success: false,
        delivered: false,
        provider: 'smtp',
        error: err.message,
        message: `Falha no envio de e-mail via servidor SMTP (${smtpHost}): ${err.message}.`,
      };
    }
  }

  // 2. Provedor Secundário: Resend API (se configurado)
  const resendKey = process.env.RESEND_API_KEY;
  if (resendKey) {
    const fromAddress =
      process.env.RESEND_FROM ||
      process.env.EMAIL_FROM ||
      process.env.SMTP_FROM ||
      'WhatsApp que Vende <onboarding@resend.dev>';
    try {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromAddress,
          to: [cleanEmail],
          subject: `Código de Verificação: ${code} — WhatsApp que Vende`,
          html: htmlContent,
          text: textContent,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        console.log(`[MailService] E-mail enviado com sucesso via Resend para ${cleanEmail} (ID: ${data.id})`);
        return {
          success: true,
          delivered: true,
          provider: 'resend',
          messageId: data.id,
          message: 'E-mail de confirmação enviado com sucesso via Resend!',
        };
      } else {
        const errorMsg = data?.message || data?.error || res.statusText;
        console.error('[MailService] Erro na API do Resend:', errorMsg);
        return {
          success: false,
          delivered: false,
          provider: 'resend',
          error: errorMsg,
          message: `Falha ao enviar e-mail via Resend: ${errorMsg}`,
        };
      }
    } catch (err: any) {
      console.error('[MailService] Falha de conexão com Resend:', err.message);
      return {
        success: false,
        delivered: false,
        provider: 'resend',
        error: err.message,
        message: `Falha de conexão com Resend: ${err.message}`,
      };
    }
  }

  // 3. Provedor Secundário: Brevo API (se configurado)
  const brevoKey = process.env.BREVO_API_KEY || process.env.SENDINBLUE_API_KEY;
  if (brevoKey) {
    const brevoEmail =
      process.env.BREVO_SENDER ||
      process.env.EMAIL_FROM ||
      process.env.SMTP_USER ||
      'suporte@whatsappquevende.com';
    const brevoName = process.env.BREVO_SENDER_NAME || 'WhatsApp que Vende';

    try {
      const res = await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST',
        headers: {
          'api-key': brevoKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sender: { name: brevoName, email: brevoEmail },
          to: [{ email: cleanEmail, name: displayName }],
          subject: `Código de Verificação: ${code} — WhatsApp que Vende`,
          htmlContent,
          textContent,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        console.log(`[MailService] E-mail enviado com sucesso via Brevo para ${cleanEmail}`);
        return {
          success: true,
          delivered: true,
          provider: 'brevo',
          message: 'E-mail enviado com sucesso via Brevo!',
        };
      } else {
        const errorMsg = data?.message || res.statusText;
        console.error('[MailService] Erro na API do Brevo:', errorMsg);
        return {
          success: false,
          delivered: false,
          provider: 'brevo',
          error: errorMsg,
          message: `Falha ao enviar e-mail via Brevo: ${errorMsg}`,
        };
      }
    } catch (err: any) {
      console.error('[MailService] Falha de conexão com Brevo:', err.message);
      return {
        success: false,
        delivered: false,
        provider: 'brevo',
        error: err.message,
        message: `Falha de conexão com Brevo: ${err.message}`,
      };
    }
  }

  // 4. Provedor Secundário: SendGrid API (se configurado)
  const sendgridKey = process.env.SENDGRID_API_KEY;
  if (sendgridKey) {
    const sendgridSender =
      process.env.SENDGRID_FROM ||
      process.env.EMAIL_FROM ||
      process.env.SMTP_FROM ||
      process.env.SMTP_USER;
    if (sendgridSender) {
      try {
        const res = await fetch('https://api.sendgrid.com/v3/mail/send', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${sendgridKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            personalizations: [{ to: [{ email: cleanEmail, name: displayName }] }],
            from: { email: sendgridSender, name: 'WhatsApp que Vende' },
            subject: `Código de Verificação: ${code} — WhatsApp que Vende`,
            content: [
              { type: 'text/html', value: htmlContent },
              { type: 'text/plain', value: textContent },
            ],
          }),
        });

        if (res.ok || res.status === 202) {
          console.log(`[MailService] E-mail enviado via SendGrid para ${cleanEmail}`);
          return {
            success: true,
            delivered: true,
            provider: 'sendgrid',
            message: 'E-mail enviado com sucesso via SendGrid!',
          };
        } else {
          const errBody = await res.text().catch(() => '');
          console.error('[MailService] Erro no SendGrid:', errBody);
          return {
            success: false,
            delivered: false,
            provider: 'sendgrid',
            error: errBody,
            message: `Falha ao enviar e-mail via SendGrid: ${errBody}`,
          };
        }
      } catch (err: any) {
        console.error('[MailService] Falha de conexão com SendGrid:', err.message);
        return {
          success: false,
          delivered: false,
          provider: 'sendgrid',
          error: err.message,
          message: `Falha de conexão com SendGrid: ${err.message}`,
        };
      }
    }
  }

  // 5. NENHUMA CONFIGURAÇÃO DE E-MAIL DETECTADA NO SERVIDOR
  console.warn(
    `[MailService] Nenhuma variável SMTP configurada (SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS). O e-mail para ${cleanEmail} não pôde ser enviado.`
  );
  return {
    success: false,
    delivered: false,
    provider: 'none',
    error: 'Serviço SMTP não configurado.',
    message:
      'Configuração SMTP pendente no servidor. Defina as variáveis de ambiente SMTP_HOST, SMTP_PORT, SMTP_USER e SMTP_PASS para envio real dos e-mails.',
  };
}

export interface SendResetPasswordOptions {
  to: string;
  name?: string;
  resetLink: string;
}

/**
 * Dispatches a password reset email with a secure, temporary reset link.
 */
export async function sendPasswordResetEmail({
  to,
  name,
  resetLink,
}: SendResetPasswordOptions): Promise<MailDispatchResult> {
  const cleanEmail = to.trim().toLowerCase();
  const displayName = name?.trim() || 'Usuário';

  const htmlContent = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Redefinição de Senha • WhatsApp que Vende</title>
  <style>
    body { margin: 0; padding: 0; background-color: #070B0E; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #E2E8F0; }
    .wrapper { width: 100%; max-width: 580px; margin: 0 auto; padding: 32px 16px; box-sizing: border-box; }
    .card { background-color: #0D1419; border: 1px solid #1F2C34; border-radius: 16px; padding: 36px 28px; text-align: center; }
    .logo-badge { display: inline-block; width: 48px; height: 48px; line-height: 48px; background-color: #25D366; color: #0A1014; font-size: 24px; font-weight: 900; border-radius: 12px; margin-bottom: 16px; text-align: center; }
    h1 { font-size: 22px; font-weight: 800; color: #FFFFFF; margin: 0 0 12px; }
    p { font-size: 14px; line-height: 1.6; color: #94A3B8; margin: 0 0 24px; text-align: left; }
    .btn-box { margin: 28px 0; }
    .btn { display: inline-block; background-color: #25D366; color: #0A1014 !important; text-decoration: none; font-weight: 800; font-size: 15px; padding: 14px 32px; border-radius: 12px; box-shadow: 0 4px 14px rgba(37, 211, 102, 0.3); }
    .link-alt { font-size: 12px; color: #64748B; word-break: break-all; margin: 20px 0 0; text-align: left; }
    .tip { font-size: 12px; color: #64748B; margin-top: 24px; line-height: 1.5; border-top: 1px solid #1F2C34; padding-top: 18px; text-align: left; }
    .footer { font-size: 11px; color: #475569; text-align: center; margin-top: 24px; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="card">
      <div class="logo-badge">W</div>
      <h1>Recuperação de Acesso</h1>
      <p>Olá, <strong>${displayName}</strong>!<br><br>Recebemos uma solicitação para redefinir a senha da sua conta no <strong>WhatsApp que Vende</strong>. Clique no botão seguro abaixo para cadastrar sua nova senha:</p>
      
      <div class="btn-box">
        <a href="${resetLink}" target="_blank" class="btn">Redefinir Minha Senha</a>
      </div>

      <div class="link-alt">
        Caso o botão acima não funcione, copie e cole o link a seguir no seu navegador:<br>
        <a href="${resetLink}" style="color: #25D366;">${resetLink}</a>
      </div>

      <p class="tip">⏱️ <strong>Segurança:</strong> Este link é temporário e expira em 1 hora.<br>Se você não fez essa solicitação, desconsidere esta mensagem. Sua senha atual permanece inalterada e sua conta protegida.</p>
    </div>
    <div class="footer">
      WhatsApp que Vende • Plataforma Inteligente de Treinamento Comercial
    </div>
  </div>
</body>
</html>
  `;

  const textContent = `Olá ${displayName}! Para redefinir a senha da sua conta no WhatsApp que Vende, acesse o link seguro: ${resetLink} (Link válido por 1 hora). Se você não solicitou, ignore esta mensagem.`;

  // 1. Try SMTP Transporter first
  const transporter = getSmtpTransporter();
  if (transporter) {
    const preferGmail =
      process.env.EMAIL_PROVIDER?.toLowerCase() === 'gmail' ||
      process.env.SMTP_PROVIDER?.toLowerCase() === 'gmail' ||
      (process.env.SMTP_HOST || '').toLowerCase().includes('gmail') ||
      (process.env.SMTP_USER || '').toLowerCase().includes('@gmail.com');

    const smtpHost = preferGmail
      ? 'smtp.gmail.com'
      : (process.env.SMTP_HOST || process.env.MAIL_HOST || '');
    const smtpUser = preferGmail
      ? (process.env.SMTP_USER || process.env.MAIL_USER || 'suportewppquevende@gmail.com')
      : (process.env.SMTP_USER || process.env.MAIL_USER || '');

    let fromAddress =
      process.env.SMTP_FROM ||
      process.env.MAIL_FROM ||
      process.env.EMAIL_FROM;

    const replyToAddress = fromAddress || undefined;
    const isResendSmtp = smtpHost.toLowerCase().includes('resend.com');
    const isGmail = smtpHost.toLowerCase().includes('gmail.com');

    if (isGmail) {
      fromAddress = `"WhatsApp que Vende" <${smtpUser}>`;
    } else if (isResendSmtp) {
      const isPublicWebmail = fromAddress && /@(gmail|hotmail|outlook|yahoo)\.com/i.test(fromAddress);
      if (!fromAddress || isPublicWebmail || fromAddress.toLowerCase().includes('resend')) {
        fromAddress = 'WhatsApp que Vende <onboarding@resend.dev>';
      }
    } else if (!fromAddress) {
      fromAddress = `"WhatsApp que Vende" <${smtpUser}>`;
    }

    try {
      console.log(`[MailService] Enviando e-mail de recuperação de senha via SMTP (${smtpHost}) para ${cleanEmail}...`);
      let info;
      try {
        info = await transporter.sendMail({
          from: fromAddress,
          to: cleanEmail,
          replyTo: replyToAddress,
          subject: 'Redefinição de Senha — WhatsApp que Vende',
          html: htmlContent,
          text: textContent,
        });
      } catch (sendErr: any) {
        if (
          isResendSmtp &&
          fromAddress !== 'WhatsApp que Vende <onboarding@resend.dev>' &&
          (sendErr.message?.includes('not verified') || sendErr.message?.includes('550'))
        ) {
          info = await transporter.sendMail({
            from: 'WhatsApp que Vende <onboarding@resend.dev>',
            to: cleanEmail,
            replyTo: replyToAddress,
            subject: 'Redefinição de Senha — WhatsApp que Vende',
            html: htmlContent,
            text: textContent,
          });
        } else {
          throw sendErr;
        }
      }

      console.log(`[MailService] E-mail de recuperação enviado com sucesso via SMTP! ID: ${info.messageId}`);
      return {
        success: true,
        delivered: true,
        provider: 'smtp',
        messageId: info.messageId,
        message: 'E-mail de recuperação de senha enviado com sucesso!',
      };
    } catch (err: any) {
      console.error('[MailService] Erro ao enviar recuperação de senha via SMTP:', err.message);
      return {
        success: false,
        delivered: false,
        provider: 'smtp',
        error: err.message,
        message: `Falha no envio de e-mail via servidor SMTP (${smtpHost}): ${err.message}`,
      };
    }
  }

  // 2. Provedor Secundário: Resend API
  if (process.env.RESEND_API_KEY) {
    try {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: process.env.RESEND_FROM || 'WhatsApp que Vende <onboarding@resend.dev>',
          to: [cleanEmail],
          subject: 'Redefinição de Senha — WhatsApp que Vende',
          html: htmlContent,
          text: textContent,
        }),
      });
      if (res.ok) {
        const data = await res.json().catch(() => ({}));
        return {
          success: true,
          delivered: true,
          provider: 'resend',
          messageId: data.id,
          message: 'E-mail de recuperação enviado com sucesso via Resend!',
        };
      }
    } catch (err: any) {
      console.error('[MailService] Erro Resend reset password:', err.message);
    }
  }

  return {
    success: false,
    delivered: false,
    provider: 'none',
    error: 'Serviço de e-mail não configurado.',
    message: 'Nenhum servidor SMTP configurado para envio do e-mail de recuperação.',
  };
}
