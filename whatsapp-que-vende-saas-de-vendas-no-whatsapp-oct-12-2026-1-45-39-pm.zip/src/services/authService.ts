// Client-side authentication and credential service with Firestore persistence
// Provides secure account registration, login, session tokens, password hashing,
// email verification via Firebase Authentication REST API, and data isolation per UID.

import { db } from './firebase';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { UserProfile } from '../types';

export interface AuthSession {
  uid: string;
  email: string;
  name: string;
  token: string;
  createdAt: string;
  emailVerified?: boolean;
  isResendSandboxRestricted?: boolean;
  sandboxOwnerEmail?: string;
  sandboxCode?: string;
}

const STORAGE_SESSION_KEY = 'wq_auth_session';

// Helper for crypto hashing password with salt using Web Crypto API
async function hashPassword(password: string, salt: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(`${password}:${salt}:whatsappquevende_v1`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Generate random cryptographic salt or token
function generateRandomHex(length: number = 16): string {
  const arr = new Uint8Array(length);
  crypto.getRandomValues(arr);
  return Array.from(arr).map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Generate numeric 6-digit confirmation code
function generateNumericCode(): string {
  const arr = new Uint32Array(1);
  crypto.getRandomValues(arr);
  return (100000 + (arr[0] % 900000)).toString();
}

// Encode email into a safe Firestore document ID
function emailToDocId(email: string): string {
  return email.trim().toLowerCase().replace(/[^a-zA-Z0-9_-]/g, '_');
}

// Dispatch verification email via backend mailer service
async function dispatchVerificationEmailViaBackend(
  email: string,
  name: string,
  code: string
): Promise<{
  success: boolean;
  delivered?: boolean;
  message?: string;
  provider?: string;
  isResendSandboxRestricted?: boolean;
  sandboxOwnerEmail?: string;
  sandboxCode?: string;
}> {
  try {
    const resp = await fetch('/api/auth/send-verification', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, name, code }),
    });
    const data = await resp.json().catch(() => ({}));
    return {
      success: !!data.success,
      delivered: !!data.delivered,
      message: data.message || data.error || 'Falha ao processar envio de e-mail.',
      provider: data.provider || 'none',
      isResendSandboxRestricted: data.isResendSandboxRestricted,
      sandboxOwnerEmail: data.sandboxOwnerEmail,
      sandboxCode: data.sandboxCode,
    };
  } catch (err: any) {
    console.warn('[authService] Error calling /api/auth/send-verification:', err);
    return { success: false, delivered: false, message: err.message, provider: 'none' };
  }
}

export const authService = {
  // Get active session from localStorage
  getCurrentSession(): AuthSession | null {
    try {
      const stored = localStorage.getItem(STORAGE_SESSION_KEY);
      if (!stored) return null;
      return JSON.parse(stored) as AuthSession;
    } catch {
      return null;
    }
  },

  // Save active session
  setSession(session: AuthSession | null) {
    if (session) {
      localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(session));
    } else {
      localStorage.removeItem(STORAGE_SESSION_KEY);
    }
  },

  // Register a new user account - Immediate access, no confirmation code, no verification email
  async register(
    email: string,
    password: string,
    name: string
  ): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim();

    if (!cleanEmail || !cleanEmail.includes('@')) {
      return { success: false, error: 'Por favor, informe um e-mail válido.' };
    }
    if (!password || password.length < 6) {
      return { success: false, error: 'A senha deve possuir pelo menos 6 caracteres.' };
    }

    try {
      const emailDocId = emailToDocId(cleanEmail);
      const accountRef = doc(db, 'accounts', emailDocId);
      const existingSnap = await getDoc(accountRef);

      if (existingSnap.exists()) {
        return {
          success: false,
          error: 'Este e-mail já está cadastrado. Faça login ou recupere sua senha.',
        };
      }

      // Generate unique user UID
      const uid = 'usr_' + generateRandomHex(12);
      const salt = generateRandomHex(16);
      const passwordHash = await hashPassword(password, salt);
      const now = new Date().toISOString();

      // 1. Create account credential document - Immediately verified!
      const accountData = {
        uid,
        email: cleanEmail,
        salt,
        passwordHash,
        emailVerified: true,
        accessStatus: 'active',
        createdAt: now,
        updatedAt: now,
      };
      await setDoc(accountRef, accountData);

      // 2. Create UserProfile in /users/{uid} with emailVerified: true & accessStatus: active
      const initialProfile: UserProfile = {
        uid,
        name: cleanName || 'Usuário',
        email: cleanEmail,
        profession: 'Corretor de Imóveis',
        businessType: 'Autônomo / MEI',
        tonePreference: 'Consultivo',
        autoCopySignature: false,
        businessSignature: `— Atendimento ${cleanName}`,
        accessStatus: 'active',
        plan: 'free',
        emailVerified: true,
        createdAt: now,
        updatedAt: now,
      };

      const userDocRef = doc(db, 'users', uid);
      await setDoc(userDocRef, initialProfile);

      // 3. Save session with emailVerified: true
      const session: AuthSession = {
        uid,
        email: cleanEmail,
        name: initialProfile.name,
        token: generateRandomHex(32),
        createdAt: now,
        emailVerified: true,
      };
      this.setSession(session);

      return { success: true, user: initialProfile };
    } catch (err: any) {
      console.error('[authService] Error registering:', err);
      return {
        success: false,
        error: err.message || 'Falha ao registrar conta no servidor.',
      };
    }
  },

  // Login with email and password
  async login(
    email: string,
    password: string
  ): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
    const cleanEmail = email.trim().toLowerCase();

    if (!cleanEmail || !cleanEmail.includes('@')) {
      return { success: false, error: 'Formato de e-mail inválido.' };
    }

    try {
      const emailDocId = emailToDocId(cleanEmail);
      const accountRef = doc(db, 'accounts', emailDocId);
      const accountSnap = await getDoc(accountRef);

      if (!accountSnap.exists()) {
        return {
          success: false,
          error: 'E-mail ou senha incorretos.',
        };
      }

      const accountData = accountSnap.data() as {
        uid: string;
        salt: string;
        passwordHash: string;
        emailVerified?: boolean;
      };

      // Verify password hash
      const computedHash = await hashPassword(password, accountData.salt);
      if (computedHash !== accountData.passwordHash) {
        return {
          success: false,
          error: 'E-mail ou senha incorretos.',
        };
      }

      // Automatically activate and verify any new or existing account
      if (!accountData.emailVerified) {
        accountData.emailVerified = true;
        await setDoc(accountRef, { emailVerified: true, accessStatus: 'active' }, { merge: true });
      }

      // Fetch user profile from /users/{uid}
      const userRef = doc(db, 'users', accountData.uid);
      const userSnap = await getDoc(userRef);

      let profile: UserProfile;
      if (userSnap.exists()) {
        profile = userSnap.data() as UserProfile;
        if (!profile.emailVerified || profile.accessStatus !== 'active') {
          profile.emailVerified = true;
          profile.accessStatus = 'active';
          await setDoc(userRef, { emailVerified: true, accessStatus: 'active' }, { merge: true });
        }
      } else {
        // Fallback profile if not yet created
        profile = {
          uid: accountData.uid,
          name: cleanEmail.split('@')[0],
          email: cleanEmail,
          profession: 'Corretor de Imóveis',
          businessType: 'Autônomo / MEI',
          tonePreference: 'Consultivo',
          autoCopySignature: false,
          accessStatus: 'active',
          plan: 'free',
          emailVerified: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await setDoc(userRef, profile);
      }

      profile.emailVerified = true;

      // Save session
      const session: AuthSession = {
        uid: accountData.uid,
        email: cleanEmail,
        name: profile.name,
        token: generateRandomHex(32),
        createdAt: new Date().toISOString(),
        emailVerified: true,
      };
      this.setSession(session);

      return { success: true, user: profile };
    } catch (err: any) {
      console.error('[authService] Login error:', err);
      return {
        success: false,
        error: 'Falha ao autenticar. Verifique sua conexão e tente novamente.',
      };
    }
  },

  // Resend verification email
  async resendVerificationEmail(email: string): Promise<{
    success: boolean;
    error?: string;
    code?: string;
    delivered?: boolean;
    provider?: string;
    message?: string;
    isResendSandboxRestricted?: boolean;
    sandboxOwnerEmail?: string;
    sandboxCode?: string;
  }> {
    const cleanEmail = email.trim().toLowerCase();
    try {
      const emailDocId = emailToDocId(cleanEmail);
      const accountRef = doc(db, 'accounts', emailDocId);
      const accountSnap = await getDoc(accountRef);

      if (!accountSnap.exists()) {
        return { success: false, error: 'Usuário não encontrado.' };
      }

      const accountData = accountSnap.data() as { uid: string; emailVerified?: boolean; name?: string };
      if (accountData.emailVerified) {
        return { success: false, error: 'Este e-mail já foi verificado com sucesso.' };
      }

      const newCode = generateNumericCode();
      const now = new Date().toISOString();

      await setDoc(
        accountRef,
        {
          verificationCode: newCode,
          emailVerificationSentAt: now,
          updatedAt: now,
        },
        { merge: true }
      );

      const userRef = doc(db, 'users', accountData.uid);
      const userSnap = await getDoc(userRef);
      const userName = userSnap.exists() ? (userSnap.data() as UserProfile).name : (accountData.name || '');

      await setDoc(
        userRef,
        {
          verificationCode: newCode,
          emailVerificationSentAt: now,
          updatedAt: now,
        },
        { merge: true }
      );

      // Trigger backend email dispatch
      const mailRes = await dispatchVerificationEmailViaBackend(cleanEmail, userName, newCode);

      const current = this.getCurrentSession();
      if (current && current.email === cleanEmail) {
        current.isResendSandboxRestricted = mailRes.isResendSandboxRestricted;
        current.sandboxOwnerEmail = mailRes.sandboxOwnerEmail;
        current.sandboxCode = mailRes.sandboxCode;
        this.setSession(current);
      }

      return {
        success: mailRes.success,
        code: newCode,
        delivered: mailRes.delivered,
        provider: mailRes.provider,
        message: mailRes.message,
        isResendSandboxRestricted: mailRes.isResendSandboxRestricted,
        sandboxOwnerEmail: mailRes.sandboxOwnerEmail,
        sandboxCode: mailRes.sandboxCode,
        error: !mailRes.delivered && !mailRes.isResendSandboxRestricted ? mailRes.message : undefined,
      };
    } catch (err: any) {
      console.error('[authService] Resend verification error:', err);
      return { success: false, error: 'Erro ao reenviar o e-mail de verificação.' };
    }
  },

  // Confirm email verification strictly with the 6-digit code
  async confirmEmailVerification(
    email: string,
    providedCode?: string
  ): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
    const cleanEmail = email.trim().toLowerCase();
    const cleanCode = (providedCode || '').trim();

    if (!cleanCode) {
      return {
        success: false,
        error: 'Por favor, digite o código de 6 dígitos enviado para seu e-mail.',
      };
    }

    if (cleanCode.length !== 6 || !/^\d{6}$/.test(cleanCode)) {
      return {
        success: false,
        error: 'O código de confirmação deve conter exatamente 6 números.',
      };
    }

    try {
      const emailDocId = emailToDocId(cleanEmail);
      const accountRef = doc(db, 'accounts', emailDocId);
      const accountSnap = await getDoc(accountRef);

      if (!accountSnap.exists()) {
        return { success: false, error: 'Conta não encontrada.' };
      }

      const accountData = accountSnap.data() as {
        uid: string;
        verificationCode?: string;
        emailVerified?: boolean;
      };

      if (accountData.emailVerified) {
        // Already verified
        const userRef = doc(db, 'users', accountData.uid);
        const userSnap = await getDoc(userRef);
        const profile = userSnap.exists() ? (userSnap.data() as UserProfile) : null;
        if (profile) profile.emailVerified = true;
        return { success: true, user: profile || undefined };
      }

      // Strictly validate confirmation code
      if (!accountData.verificationCode || accountData.verificationCode !== cleanCode) {
        return {
          success: false,
          error: 'Código de confirmação incorreto. Verifique os 6 dígitos recebidos e tente novamente.',
        };
      }

      const now = new Date().toISOString();

      // 1. Mark account as verified in /accounts
      await setDoc(
        accountRef,
        {
          emailVerified: true,
          emailVerifiedAt: now,
          verificationCode: null,
          updatedAt: now,
        },
        { merge: true }
      );

      // 2. Mark profile as verified and activate in /users/{uid}
      const userRef = doc(db, 'users', accountData.uid);
      const userSnap = await getDoc(userRef);
      let profile = userSnap.exists() ? (userSnap.data() as UserProfile) : ({} as UserProfile);

      const updatedProfileFields: Partial<UserProfile> = {
        emailVerified: true,
        accessStatus: 'active',
        updatedAt: now,
      };

      await setDoc(userRef, updatedProfileFields, { merge: true });
      profile = { ...profile, ...updatedProfileFields };

      // 3. Update session
      const current = this.getCurrentSession();
      if (current && current.email === cleanEmail) {
        current.emailVerified = true;
        this.setSession(current);
      }

      return { success: true, user: profile };
    } catch (err: any) {
      console.error('[authService] Confirm verification error:', err);
      return { success: false, error: 'Erro ao validar confirmação de e-mail.' };
    }
  },

  // Request password reset link via secure email
  async requestPasswordReset(
    email: string
  ): Promise<{ success: boolean; message?: string; error?: string }> {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      return { success: false, error: 'Por favor, informe um endereço de e-mail válido.' };
    }

    try {
      const resp = await fetch('/api/auth/request-password-reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail }),
      });
      const data = await resp.json().catch(() => ({}));
      if (resp.ok && data.success) {
        return {
          success: true,
          message: data.message || 'Link seguro de recuperação enviado com sucesso para seu e-mail!',
        };
      }
      return {
        success: false,
        error: data.error || data.message || 'Não foi possível enviar o e-mail de recuperação.',
      };
    } catch (err: any) {
      console.error('[authService] Reset request error:', err);
      return {
        success: false,
        error: 'Falha de comunicação ao solicitar recuperação de senha.',
      };
    }
  },

  // Reset password with temporary token received in email link
  async resetPasswordWithToken(
    email: string,
    token: string,
    newPassword: string
  ): Promise<{ success: boolean; message?: string; error?: string }> {
    const cleanEmail = email.trim().toLowerCase();
    const cleanToken = token.trim();

    if (!newPassword || newPassword.length < 6) {
      return { success: false, error: 'A nova senha deve ter no mínimo 6 caracteres.' };
    }

    try {
      const resp = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, token: cleanToken, newPassword }),
      });
      const data = await resp.json().catch(() => ({}));
      if (resp.ok && data.success) {
        return {
          success: true,
          message: data.message || 'Senha redefinida com sucesso! Você já pode entrar com sua nova senha.',
        };
      }
      return {
        success: false,
        error: data.error || data.message || 'Falha ao redefinir senha.',
      };
    } catch (err: any) {
      console.error('[authService] resetPasswordWithToken error:', err);
      return { success: false, error: 'Erro de comunicação ao redefinir senha.' };
    }
  },

  // Direct reset password fallback
  async resetPassword(
    email: string,
    newPassword: string,
    resetCode?: string
  ): Promise<{ success: boolean; error?: string }> {
    const cleanEmail = email.trim().toLowerCase();
    if (!newPassword || newPassword.length < 6) {
      return { success: false, error: 'A nova senha deve ter pelo menos 6 caracteres.' };
    }

    try {
      const emailDocId = emailToDocId(cleanEmail);
      const accountRef = doc(db, 'accounts', emailDocId);
      const accountSnap = await getDoc(accountRef);

      if (!accountSnap.exists()) {
        return { success: false, error: 'Usuário não encontrado.' };
      }

      const accountData = accountSnap.data() as {
        salt: string;
        passwordResetCode?: string;
      };

      if (resetCode && resetCode.trim()) {
        if (accountData.passwordResetCode && accountData.passwordResetCode !== resetCode.trim()) {
          return { success: false, error: 'Código de redefinição inválido.' };
        }
      }

      const newSalt = generateRandomHex(16);
      const newHash = await hashPassword(newPassword, newSalt);
      const now = new Date().toISOString();

      await setDoc(
        accountRef,
        {
          salt: newSalt,
          passwordHash: newHash,
          passwordResetCode: null,
          passwordResetRequestedAt: null,
          updatedAt: now,
        },
        { merge: true }
      );

      return { success: true };
    } catch (err: any) {
      console.error('[authService] resetPassword error:', err);
      return { success: false, error: 'Erro ao redefinir senha.' };
    }
  },

  // Logout
  logout() {
    this.setSession(null);
  },
};
