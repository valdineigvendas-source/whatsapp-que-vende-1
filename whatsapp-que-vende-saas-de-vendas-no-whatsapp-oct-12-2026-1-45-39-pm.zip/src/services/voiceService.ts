// Audio Service para síntese de voz (TTS) e gravação de microfone (MediaRecorder + Web Speech API)
// Suporta prompt de permissão nativo com navigator.mediaDevices.getUserMedia() para garantir
// que o navegador mostre o pop-up de "Permitir microfone", além de fallback seguro e robusto.

class VoiceService {
  private synth: SpeechSynthesis | null = null;
  private recognition: any = null;
  private isRecognitionActive = false;
  private mediaRecorder: MediaRecorder | null = null;
  private mediaStream: MediaStream | null = null;
  private audioChunks: Blob[] = [];
  private recordingStartTime = 0;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
    }
  }

  // Verifica se o navegador suporta síntese de voz
  public isTtsSupported(): boolean {
    return typeof window !== 'undefined' && 'speechSynthesis' in window;
  }

  // Verifica se o microfone está disponível via getUserMedia
  public isMicrophoneSupported(): boolean {
    return typeof navigator !== 'undefined' && !!navigator.mediaDevices && !!navigator.mediaDevices.getUserMedia;
  }

  // Solicitar explicitamente permissão de microfone pelo navegador (dispara pop-up nativo de permissão)
  public async requestMicrophonePermission(): Promise<{ granted: boolean; error?: string }> {
    if (!this.isMicrophoneSupported()) {
      return { granted: false, error: 'Microfone não suportado pelo navegador atual.' };
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Fecha a stream de teste imediatamente após concessão da permissão
      stream.getTracks().forEach((track) => track.stop());
      return { granted: true };
    } catch (err: any) {
      console.warn('[voiceService] Permissão de microfone rejeitada ou erro:', err);
      let errorMsg = 'Permissão de microfone negada pelo navegador.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        errorMsg = 'Acesso ao microfone foi bloqueado. Clique no ícone de cadeado/permissão ao lado do endereço do site para permitir o microfone.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        errorMsg = 'Nenhum microfone foi detectado no seu dispositivo.';
      }
      return { granted: false, error: errorMsg };
    }
  }

  // Parar qualquer reprodução de áudio em andamento
  public stopSpeaking(): void {
    if (this.synth) {
      this.synth.cancel();
    }
  }

  // Falar texto em voz alta com entonação adequada ao perfil do cliente
  public speak(
    text: string,
    options: {
      profile?: string;
      onStart?: () => void;
      onEnd?: () => void;
      onError?: (err: any) => void;
    } = {}
  ): void {
    if (!this.synth) {
      options.onEnd?.();
      return;
    }

    this.synth.cancel();

    const cleanText = text
      .replace(/[*_#`~]/g, '')
      .replace(/\(O cliente.*?\)/gi, '')
      .trim();

    if (!cleanText) {
      options.onEnd?.();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'pt-BR';

    switch (options.profile) {
      case 'apressado':
        utterance.rate = 1.15;
        utterance.pitch = 1.05;
        break;
      case 'indeciso':
        utterance.rate = 0.95;
        utterance.pitch = 0.98;
        break;
      case 'desconfiado':
        utterance.rate = 0.92;
        utterance.pitch = 0.95;
        break;
      case 'sensivel-preco':
        utterance.rate = 1.02;
        utterance.pitch = 1.0;
        break;
      default:
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        break;
    }

    const voices = this.synth.getVoices();
    const ptVoice =
      voices.find(
        (v) =>
          v.lang === 'pt-BR' &&
          (v.name.includes('Google') ||
            v.name.includes('Luciana') ||
            v.name.includes('Felipe') ||
            v.name.includes('Natural'))
      ) || voices.find((v) => v.lang.startsWith('pt'));

    if (ptVoice) {
      utterance.voice = ptVoice;
    }

    utterance.onstart = () => {
      options.onStart?.();
    };

    utterance.onend = () => {
      options.onEnd?.();
    };

    utterance.onerror = (e) => {
      console.warn('[voiceService] Erro na reprodução de voz:', e);
      options.onError?.(e);
      options.onEnd?.();
    };

    this.synth.speak(utterance);
  }

  // Iniciar gravação de voz híbrida:
  // 1. Obtém permissão garantida via getUserMedia (disparando o diálogo de permissão do navegador)
  // 2. Grava os dados do áudio via MediaRecorder com duração precisa
  // 3. Tenta paralelamente o SpeechRecognition para transcrição instantânea em tela
  public async startRecording(callbacks: {
    onInterimTranscript?: (text: string) => void;
    onFinalAudioRecorded: (audioBlob: Blob, textFallback: string, durationSeconds: number) => void;
    onError: (error: string) => void;
    onEnd: () => void;
  }): Promise<() => void> {
    try {
      if (!this.isMicrophoneSupported()) {
        callbacks.onError('Microfone não suportado no navegador.');
        return () => {};
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.mediaStream = stream;
      this.audioChunks = [];
      this.recordingStartTime = Date.now();

      let mimeType = 'audio/webm';
      if (typeof MediaRecorder !== 'undefined') {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          mimeType = 'audio/mp4';
        } else if (MediaRecorder.isTypeSupported('audio/ogg')) {
          mimeType = 'audio/ogg';
        }
      }

      this.mediaRecorder = new MediaRecorder(stream, { mimeType });
      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          this.audioChunks.push(event.data);
        }
      };

      let liveTranscript = '';

      const SpeechRecognitionAPI =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRecognitionAPI) {
        try {
          this.recognition = new SpeechRecognitionAPI();
          this.recognition.lang = 'pt-BR';
          this.recognition.continuous = true;
          this.recognition.interimResults = true;

          this.recognition.onresult = (event: any) => {
            let interim = '';
            let final = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
              const text = event.results[i][0].transcript;
              if (event.results[i].isFinal) {
                final += text;
              } else {
                interim += text;
              }
            }
            const current = (final || interim).trim();
            if (current) {
              liveTranscript = current;
              callbacks.onInterimTranscript?.(current);
            }
          };

          this.recognition.onerror = () => {};

          this.isRecognitionActive = true;
          this.recognition.start();
        } catch {
          // Fallback gracioso
        }
      }

      this.mediaRecorder.onstop = () => {
        const durationSec = Math.max(1, Math.round((Date.now() - this.recordingStartTime) / 1000));
        const audioBlob = new Blob(this.audioChunks, { type: mimeType });
        callbacks.onFinalAudioRecorded(audioBlob, liveTranscript, durationSec);
        callbacks.onEnd();

        if (this.mediaStream) {
          this.mediaStream.getTracks().forEach((track) => track.stop());
          this.mediaStream = null;
        }
      };

      this.mediaRecorder.start(250);

      return () => {
        this.stopRecording();
      };
    } catch (err: any) {
      console.warn('[voiceService] Falha ao iniciar gravação:', err);
      let errorMsg = 'Não foi possível acessar o microfone.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        errorMsg = 'Permissão de microfone bloqueada. Verifique as configurações de permissões do navegador ou clique no cadeado na barra de endereços.';
      }
      callbacks.onError(errorMsg);
      return () => {};
    }
  }

  // Finalizar a gravação
  public stopRecording(): void {
    if (this.recognition && this.isRecognitionActive) {
      try {
        this.recognition.stop();
      } catch {}
      this.isRecognitionActive = false;
    }

    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      try {
        this.mediaRecorder.stop();
      } catch {}
    }
  }
}

export const voiceService = new VoiceService();
