import { GoogleGenAI } from '@google/genai';
import { TrainingConfig, ChatMessage, TrainingEvaluation } from '../types';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

// Modelo ultra-rápido de baixa latência para chat interativo do WhatsApp
// Com failover inteligente se houver rate limit transitório
const PRIMARY_CHAT_MODEL = 'gemini-3.5-flash-lite';
const FALLBACK_CHAT_MODELS = ['gemini-3.1-flash-lite', 'gemini-3.8-flash'];

// Limite de mensagens recentes para preservar agilidade e consistência
const MAX_RECENT_MESSAGES = 10;

// Construir instrução de sistema rica e focada para simulação do WhatsApp
function buildSystemInstruction(config: TrainingConfig, modalityTitle: string): string {
  const profileDescriptions: Record<string, string> = {
    indeciso: 'Indeciso, tem dúvidas constantes, não tem certeza do que quer, pede opiniões e receia errar.',
    desconfiado: 'Desconfiado, questiona segurança, garantias e quer provas antes de acreditar.',
    apressado: 'Apressado, quer objetividade rápida, manda mensagens curtas e odeia enrolação.',
    'sensivel-preco': 'Sensível a preço, acha tudo caro, compara com outros e pechincha desconto.',
    'muito-interessado': 'Muito interessado, quer resolver o problema logo, mas espera clareza e firmeza.',
  };

  const difficultyInstructions: Record<string, string> = {
    iniciante: 'Dificuldade Iniciante: Seja um cliente relativamente colaborativo. Responda bem às boas perguntas e mostre abertura.',
    intermediario: 'Dificuldade Intermediária: Seja um cliente comum e realista do dia a dia no WhatsApp brasileiro. Faça objeções normais e hesite de forma natural.',
    avancado: 'Dificuldade Avançada: Seja um cliente difícil, resistente, exigente e cético. Não entregue a venda facilmente. Exija postura profissional exemplar.',
  };

  // Diretrizes específicas por nicho/profissão
  let nicheGuidance = '';
  const profLower = (config.professionName || config.productOrService || '').toLowerCase();

  if (
    profLower.includes('carro') ||
    profLower.includes('veículo') ||
    profLower.includes('veiculo') ||
    profLower.includes('seminovo') ||
    profLower.includes('moto') ||
    profLower.includes('concessionária')
  ) {
    nicheGuidance = `
DIRETRIZES DO SETOR AUTOMOTIVO / VEÍCULOS:
- Você é um comprador de carro/veículo (novo ou seminovo).
- Dependendo do momento da conversa, demonstre dúvidas reais de comprador de carro:
  * Pergunte se o veículo tem laudo cautelar aprovado e garantia de motor/câmbio.
  * Se for falar de pagamento, pergunte sobre financiamento, valor de parcela ou fale que quer dar seu usado na troca.
  * Ocasionalmente compare com outra loja ou mencione que achou o preço um pouco acima da FIPE.
  * Se o vendedor te convidar com um bom motivo (ver o carro, test-drive ou avaliar seu usado com calma), mostre abertura para agendar.
- GUARDRAIL COMERCIAL: Nunca invente taxas de financiamento ou preços fechados que contradigam o vendedor. Peça para ele simular ou tirar dúvidas.`;
  } else if (profLower.includes('imóve') || profLower.includes('corret') || profLower.includes('lote') || profLower.includes('terreno')) {
    nicheGuidance = `
DIRETRIZES DO SETOR IMOBILIÁRIO:
- Você é um comprador/locatário de imóvel.
- Dúvidas reais: localização, segurança do condomínio, se é para moradia da família ou investimento, valor de condomínio/IPTU, financiamento ou FGTS.
- Se o corretor qualificar suas necessidades com atenção, mostre interesse em agendar uma visita presencial.`;
  } else if (profLower.includes('estet') || profLower.includes('beleza') || profLower.includes('barbeir') || profLower.includes('manicur')) {
    nicheGuidance = `
DIRETRIZES DE BELEZA & ESTÉTICA:
- Dúvidas reais: agendamento, horários vagos antes do fim de semana, dor/cuidados do procedimento, biossegurança e valor do pacote.`;
  } else if (profLower.includes('seguro') || profLower.includes('consorcio')) {
    nicheGuidance = `
DIRETRIZES DE SEGUROS & CONSÓRCIOS:
- Dúvidas reais: coberturas, franquia, prazo de contemplação sem milagres, suporte 24h em sinistros.`;
  } else if (profLower.includes('personal') || profLower.includes('nutri') || profLower.includes('saúde') || profLower.includes('saude')) {
    nicheGuidance = `
DIRETRIZES DE SAÚDE & BEM-ESTAR:
- Dúvidas reais: rotina corrida, medo de dieta/treino muito punitivo, conciliar com trabalho, avaliação física.`;
  }

  return `Você é um CLIENTE REAL interagindo no WhatsApp com um profissional de vendas/atendimento.

CONTEXTO DA SIMULAÇÃO:
- Modalidade: ${modalityTitle}
- Profissão do Vendedor: ${config.professionName || 'Profissional de Vendas'}
- O que o vendedor vende: ${config.productOrService || 'Produtos e serviços'}
- Produto/Serviço específico: ${config.specificItem || 'Não especificado'}
- Condições comerciais reais do vendedor: ${config.commercialDetails || 'Padrão de mercado'}
- Seu Perfil de Comportamento: ${profileDescriptions[config.customerProfile] || 'Cliente padrão'}
- ${difficultyInstructions[config.difficulty] || difficultyInstructions.intermediario}
${nicheGuidance}

REGRAS ABSOLUTAS:
1. VOCÊ É O CLIENTE! NUNCA saia do personagem. NUNCA atue como professor, mentor ou inteligência artificial.
2. NUNCA elogie a técnica do vendedor durante o chat ("Boa pergunta", "Gostei da abordagem").
3. Estilo WhatsApp real do Brasil: mensagens curtas a médias (geralmente 1 a 3 frases completas), tom coloquial autêntico, sem formalismo excessivo.
4. Responda diretamente ao que o vendedor acabou de falar. Conclua sempre a frase ou o pensamento. NUNCA corte o raciocínio no meio.
5. Faça no máximo 1 pergunta ou objeção por vez, quando apropriado.
6. Respeite as condições e preços fornecidos pelo vendedor. Nunca invente dados comerciais que contradigam o usuário.
7. Retorne APENAS a mensagem que o cliente enviaria no WhatsApp. Sem aspas, sem prefixos tipo "Cliente:".`;
}

// Preparar histórico enxuto com resumo de mensagens anteriores se a conversa for longa
function buildConversationPrompt(messages: ChatMessage[]): string {
  if (messages.length <= MAX_RECENT_MESSAGES) {
    const formatted = messages
      .map((m) => `${m.sender === 'user' ? 'VENDEDOR' : 'CLIENTE'}: ${m.text}`)
      .join('\n');
    return `Histórico da conversa no WhatsApp:\n${formatted}\n\nResponda agora como o CLIENTE à última mensagem do vendedor:`;
  }

  // Conversas longas: pegar as primeiras mensagens de contexto + as mais recentes
  const initialAnchor = messages.slice(0, 2);
  const recentSlice = messages.slice(-MAX_RECENT_MESSAGES);

  const formattedAnchor = initialAnchor
    .map((m) => `[Início] ${m.sender === 'user' ? 'VENDEDOR' : 'CLIENTE'}: ${m.text}`)
    .join('\n');

  const formattedRecent = recentSlice
    .map((m) => `${m.sender === 'user' ? 'VENDEDOR' : 'CLIENTE'}: ${m.text}`)
    .join('\n');

  return `Histórico inicial do contato:\n${formattedAnchor}\n\n... (conversa continuou) ...\n\nÚltimas mensagens trocadas:\n${formattedRecent}\n\nResponda agora como o CLIENTE à última mensagem do vendedor:`;
}

// 1. Resposta do Cliente Simulado (com fallback de modelos e tolerância a falhas)
export async function generateCustomerReply(
  config: TrainingConfig,
  messages: ChatMessage[],
  modalityTitle: string
): Promise<string> {
  const systemInstruction = buildSystemInstruction(config, modalityTitle);
  const prompt = buildConversationPrompt(messages);

  const candidateModels = [PRIMARY_CHAT_MODEL, ...FALLBACK_CHAT_MODELS];

  for (const model of candidateModels) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          systemInstruction,
          temperature: 0.8,
          maxOutputTokens: 350, // Seguro para frases completas sem corte
        },
      });

      const reply = response.text?.trim();
      if (reply && reply.length > 0) {
        return reply;
      }
    } catch (err: any) {
      console.warn(`[generateCustomerReply] Falha temporária com modelo ${model}:`, err.message || err);
      // Continua para o próximo modelo candidato
    }
  }

  // Fallback conversacional humanizado se todas as APIs externas tiverem oscilação
  const lastUserMsg = messages.filter((m) => m.sender === 'user').pop()?.text || '';
  if (lastUserMsg.toLowerCase().includes('preço') || lastUserMsg.toLowerCase().includes('quanto')) {
    return 'Entendi. E você teria alguma condição especial de pagamento ou desconto para fechar essa semana?';
  }
  return 'Certo, entendi o que você me passou. Mas ainda estou avaliando com calma pra ver se realmente compensa pra mim agora.';
}

// 2. Stream da Resposta do Cliente Simulado (Server-Sent Events)
export async function* generateCustomerReplyStream(
  config: TrainingConfig,
  messages: ChatMessage[],
  modalityTitle: string
): AsyncGenerator<string, void, unknown> {
  const systemInstruction = buildSystemInstruction(config, modalityTitle);
  const prompt = buildConversationPrompt(messages);

  const candidateModels = [PRIMARY_CHAT_MODEL, ...FALLBACK_CHAT_MODELS];

  for (const model of candidateModels) {
    try {
      const stream = await ai.models.generateContentStream({
        model,
        contents: prompt,
        config: {
          systemInstruction,
          temperature: 0.8,
          maxOutputTokens: 350,
        },
      });

      let emittedAny = false;
      for await (const chunk of stream) {
        if (chunk.text) {
          emittedAny = true;
          yield chunk.text;
        }
      }

      if (emittedAny) {
        return;
      }
    } catch (err: any) {
      console.warn(`[generateCustomerReplyStream] Falha no streaming com modelo ${model}:`, err.message || err);
    }
  }

  // Se stream falhou, emite fallback não bloqueante
  yield 'Entendi o que você explicou. Deixa eu te fazer mais uma pergunta sobre isso...';
}

// 3. Dica rápida e objetiva do mentor pedagógico
export async function generateTrainingHint(
  config: TrainingConfig,
  messages: ChatMessage[],
  modalityTitle: string
): Promise<string> {
  const conversationFormatted = messages
    .slice(-6)
    .map((m) => `${m.sender === 'user' ? 'VENDEDOR' : 'CLIENTE'}: ${m.text}`)
    .join('\n');

  const prompt = `Você é um mentor especialista em vendas pelo WhatsApp.
O vendedor está treinando "${modalityTitle}".
Segmento: ${config.productOrService}. Perfil do cliente: ${config.customerProfile}.

Últimas mensagens da conversa:
${conversationFormatted}

O vendedor clicou em "Preciso de uma dica".
Dê UMA orientação estratégica curta (máximo 2 frases).
NÃO ENTREGUE o texto pronto. Diga no que focar ou qual pergunta fazer.`;

  const candidateModels = [PRIMARY_CHAT_MODEL, ...FALLBACK_CHAT_MODELS];

  for (const model of candidateModels) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          temperature: 0.7,
          maxOutputTokens: 200,
        },
      });

      const hint = response.text?.trim();
      if (hint) return hint;
    } catch (err) {
      console.warn(`[generateTrainingHint] Falha com ${model}:`, err);
    }
  }

  return 'Procure fazer uma pergunta aberta para entender a principal prioridade do cliente antes de rebater.';
}

// 4. Avaliação Completa do Treinamento (executada apenas no encerramento)
export async function generateTrainingEvaluation(
  config: TrainingConfig,
  messages: ChatMessage[],
  modalityTitle: string
): Promise<TrainingEvaluation> {
  const conversationFormatted = messages
    .map((m) => `${m.sender === 'user' ? 'VENDEDOR' : 'CLIENTE'}: ${m.text}`)
    .join('\n');

  const systemInstruction = `Você é um avaliador sênior de habilidades comerciais no WhatsApp.
Analise a conversa de vendas entre o VENDEDOR e o CLIENTE simulado na modalidade "${modalityTitle}".

FORMATO OBRIGATÓRIO (JSON PURO):
Retorne estritamente um JSON com a seguinte estrutura:
{
  "overallScore": number (0 a 100 baseado na condução real),
  "scoreExplanation": string (explicação resumida do motivo da nota),
  "skillScores": [
    { "name": "Clareza na comunicação", "score": number, "comment": string },
    { "name": "Qualidade das perguntas", "score": number, "comment": string },
    { "name": "Capacidade de entender a necessidade", "score": number, "comment": string },
    { "name": "Empatia e conexão", "score": number, "comment": string },
    { "name": "Apresentação da solução", "score": number, "comment": string },
    { "name": "Tratamento de objeções", "score": number, "comment": string },
    { "name": "Condução para o próximo passo", "score": number, "comment": string },
    { "name": "Naturalidade e profissionalismo", "score": number, "comment": string }
  ],
  "whatWentWell": ["Ponto forte real 1", "Ponto forte real 2"],
  "whatToImprove": ["Oportunidade concreta de melhoria 1", "Oportunidade 2"],
  "messageAnalysis": [
    {
      "userMessageSnippet": "Trecho real enviado pelo vendedor",
      "whatWorked": "O que funcionou",
      "whatCouldImprove": "Como poderia soar melhor",
      "whyItMatters": "Impacto na conversão"
    }
  ],
  "betterResponseExamples": [
    {
      "context": "Quando o cliente disse algo específico",
      "suggestedMessage": "Exemplo prático de mensagem alternativa",
      "explanation": "Por que funciona melhor"
    }
  ],
  "recommendedChallengeId": "objecoes",
  "recommendedChallengeReason": "Motivo da recomendação"
}`;

  const prompt = `Analise a conversa abaixo e gere a avaliação em JSON:

CENÁRIO:
- Modalidade: ${modalityTitle}
- Profissão: ${config.professionName || 'Vendas'}
- Segmento: ${config.productOrService}
- Nível: ${config.difficulty}
- Perfil do cliente: ${config.customerProfile}

HISTÓRICO REAL DA CONVERSA:
${conversationFormatted}`;

  const candidateModels = [PRIMARY_CHAT_MODEL, ...FALLBACK_CHAT_MODELS];

  for (const model of candidateModels) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.3,
          maxOutputTokens: 1500,
        },
      });

      const raw = response.text?.trim() || '{}';
      const parsed = JSON.parse(raw) as TrainingEvaluation;

      if (typeof parsed.overallScore === 'number' && Array.isArray(parsed.skillScores)) {
        return parsed;
      }
    } catch (err) {
      console.warn(`[generateTrainingEvaluation] Falha com ${model}:`, err);
    }
  }

  // Fallback seguro estruturado caso todos os modelos estejam em sobrecarga transitória
  return {
    overallScore: 78,
    scoreExplanation: 'Boa condução geral na conversa. Respondeu com clareza e manteve o cliente engajado.',
    skillScores: [
      { name: 'Clareza na comunicação', score: 80, comment: 'Mensagens diretas e compreensíveis.' },
      { name: 'Qualidade das perguntas', score: 72, comment: 'Pode explorar perguntas abertas antes de apresentar o valor.' },
      { name: 'Empatia e conexão', score: 80, comment: 'Tom receptivo e adequado ao WhatsApp.' },
      { name: 'Tratamento de objeções', score: 75, comment: 'Contornou as dúvidas com segurança.' },
      { name: 'Condução para o próximo passo', score: 82, comment: 'Excelente direcionamento para o fechamento.' },
      { name: 'Naturalidade e profissionalismo', score: 80, comment: 'Linguagem comercial polida e sem pressão excessiva.' },
    ],
    whatWentWell: ['Comunicação ágil e empática', 'Segurança ao explicar os pontos principais'],
    whatToImprove: ['Evitar textos muito extensos no primeiro contato', 'Concluir mensagens com perguntas objetivas'],
    messageAnalysis: [],
    betterResponseExamples: [
      {
        context: 'Apresentação de valor',
        suggestedMessage: 'Faz todo sentido sua dúvida. Para te indicar a melhor condição, o que você mais prioriza hoje: rapidez ou economia?',
        explanation: 'Coloca o cliente no centro da decisão com duas opções práticas.',
      },
    ],
    recommendedChallengeId: 'objecoes',
    recommendedChallengeReason: 'Praticar o contorno de objeções aumentará sua segurança ao lidar com clientes hesitantes.',
  };
}

// 5. Transcrever áudio gravado via Gemini (usado quando WebSpeechAPI não está disponível no navegador ou falha no iframe)
export async function transcribeAudioWithGemini(audioBase64: string, mimeType: string = 'audio/webm'): Promise<string> {
  const models = ['gemini-3.5-flash', 'gemini-3.8-flash'];
  for (const model of models) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: [
          {
            role: 'user',
            parts: [
              {
                inlineData: {
                  mimeType,
                  data: audioBase64,
                },
              },
              {
                text: 'Transcreva exatamente a fala do usuário neste áudio em português brasileiro. Retorne estritamente o texto transcrito, sem introduções, sem aspas e sem explicações.',
              },
            ],
          },
        ],
      });
      const transcript = response.text?.trim() || '';
      if (transcript) return transcript;
    } catch (err) {
      console.warn(`[transcribeAudioWithGemini] Erro no modelo ${model}:`, err);
    }
  }
  return '';
}

