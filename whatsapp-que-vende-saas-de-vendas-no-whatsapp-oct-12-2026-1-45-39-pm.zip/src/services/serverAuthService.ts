import { Request, Response, NextFunction } from 'express';
import { db } from './firebase';
import { doc, getDoc, setDoc, deleteDoc } from 'firebase/firestore';
import { sendVerificationEmail, sendPasswordResetEmail } from './mailService';
import { UserProfile } from '../types';

export function emailToDocId(email: string): string {
  return email.trim().toLowerCase().replace(/[^a-zA-Z0-9_-]/g, '_');
}

export async function hashPassword(password: string, salt: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(`${password}:${salt}:whatsappquevende_v1`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function generateRandomHex(length: number = 16): string {
  const arr = new Uint8Array(length);
  crypto.getRandomValues(arr);
  return Array.from(arr).map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function generateNumericCode(): string {
  const arr = new Uint32Array(1);
  crypto.getRandomValues(arr);
  return (100000 + (arr[0] % 900000)).toString();
}

/**
 * Middleware that strictly protects backend API routes.
 * Rejects requests if user is not authenticated OR if their email
 * has NOT been confirmed on the server in Firestore.
 */
export async function requireVerifiedUser(req: Request, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    const bearerToken = authHeader?.startsWith('Bearer ')
      ? authHeader.substring(7).trim()
      : (req.query.token as string);

    const emailHeader = (req.headers['x-user-email'] as string) || (req.query.email as string);

    if (!emailHeader || !bearerToken) {
      return res.status(401).json({
        error: 'Acesso não autorizado: credenciais de autenticação ausentes.',
      });
    }

    const emailDocId = emailToDocId(emailHeader);
    const accountRef = doc(db, 'accounts', emailDocId);
    const accountSnap = await getDoc(accountRef);

    if (!accountSnap.exists()) {
      return res.status(401).json({
        error: 'Sessão inválida: conta não encontrada.',
      });
    }

    const account = accountSnap.data();

    // Verify session token matches
    if (account.sessionToken && account.sessionToken !== bearerToken) {
      return res.status(401).json({
        error: 'Sessão expirada ou substituída. Faça login novamente.',
      });
    }

    // Auto-verify and activate all accounts so new and existing users access normally
    if (account.emailVerified !== true || account.accessStatus !== 'active') {
      account.emailVerified = true;
      account.accessStatus = 'active';
      await setDoc(
        accountRef,
        { emailVerified: true, accessStatus: 'active', updatedAt: new Date().toISOString() },
        { merge: true }
      );
    }

    // Attach verified user account data to request for downstream handlers
    (req as any).verifiedUser = {
      uid: account.uid,
      email: account.email,
    };

    return next();
  } catch (err: any) {
    console.error('[requireVerifiedUser] Erro ao validar usuário:', err);
    return res.status(500).json({ error: 'Erro interno ao validar autenticação.' });
  }
}

/**
 * Handle user registration on the server:
 * 1. Validates inputs
 * 2. Checks if email already exists
 * 3. Creates account with emailVerified: false
 * 4. Generates single-use 6-digit code with 15-minute expiration
 * 5. Dispatches verification email via real mail provider
 * 6. Returns truthful delivery state (never mocks success)
 */
export async function handleRegister(req: Request, res: Response) {
  try {
    const { email, password, name } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanName = (name || '').trim();

    if (!cleanEmail || !cleanEmail.includes('@')) {
      return res.status(400).json({ error: 'Por favor, informe um e-mail válido.' });
    }
    if (!password || password.length < 6) {
      return res.status(400).json({ error: 'A senha deve possuir pelo menos 6 caracteres.' });
    }
    if (!cleanName) {
      return res.status(400).json({ error: 'Por favor, informe seu nome completo.' });
    }

    const emailDocId = emailToDocId(cleanEmail);
    const accountRef = doc(db, 'accounts', emailDocId);
    const existingSnap = await getDoc(accountRef);

    if (existingSnap.exists()) {
      return res.status(400).json({
        error: 'Este e-mail já está cadastrado. Faça login ou recupere sua senha.',
      });
    }

    const uid = 'usr_' + generateRandomHex(12);
    const salt = generateRandomHex(16);
    const passwordHash = await hashPassword(password, salt);
    const sessionToken = generateRandomHex(32);
    const now = new Date().toISOString();

    // 1. Create account record in /accounts/{emailDocId} - Immediately verified and active!
    const accountData = {
      uid,
      email: cleanEmail,
      salt,
      passwordHash,
      emailVerified: true,
      accessStatus: 'active',
      sessionToken,
      createdAt: now,
      updatedAt: now,
    };
    await setDoc(accountRef, accountData);

    // 2. Create user profile in /users/{uid} - Immediately active!
    const userProfile: UserProfile = {
      uid,
      name: cleanName,
      email: cleanEmail,
      profession: 'Corretor de Imóveis',
      businessType: 'Autônomo / MEI',
      tonePreference: 'Consultivo',
      autoCopySignature: false,
      businessSignature: `— Atendimento ${cleanName}`,
      accessStatus: 'active',
      plan: 'free',
      emailVerified: true,
      createdAt: now,
      updatedAt: now,
    };
    const userRef = doc(db, 'users', uid);
    await setDoc(userRef, userProfile);

    // Return immediate success session without requiring email verification
    return res.status(201).json({
      success: true,
      user: userProfile,
      session: {
        uid,
        email: cleanEmail,
        name: cleanName,
        token: sessionToken,
        emailVerified: true,
      },
      message: 'Conta criada com sucesso! Acesso liberado.',
    });
  } catch (err: any) {
    console.error('[handleRegister] Erro no registro:', err);
    return res.status(500).json({ error: err.message || 'Falha ao registrar conta.' });
  }
}

/**
 * Handle user login:
 * Validates password and ensures active verified access for all new and existing accounts.
 */
export async function handleLogin(req: Request, res: Response) {
  try {
    const { email, password } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();

    if (!cleanEmail || !password) {
      return res.status(400).json({ error: 'E-mail e senha são obrigatórios.' });
    }

    const emailDocId = emailToDocId(cleanEmail);
    const accountRef = doc(db, 'accounts', emailDocId);
    const accountSnap = await getDoc(accountRef);

    if (!accountSnap.exists()) {
      return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
    }

    const account = accountSnap.data();
    const computedHash = await hashPassword(password, account.salt);

    if (computedHash !== account.passwordHash) {
      return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
    }

    // Refresh session token and ensure active verified status
    const newSessionToken = generateRandomHex(32);
    await setDoc(
      accountRef,
      {
        sessionToken: newSessionToken,
        emailVerified: true,
        accessStatus: 'active',
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    // Fetch user profile and ensure active status
    const userRef = doc(db, 'users', account.uid);
    const userSnap = await getDoc(userRef);
    let profile: UserProfile;

    if (userSnap.exists()) {
      profile = userSnap.data() as UserProfile;
      if (!profile.emailVerified || profile.accessStatus !== 'active') {
        profile.emailVerified = true;
        profile.accessStatus = 'active';
        await setDoc(
          userRef,
          {
            emailVerified: true,
            accessStatus: 'active',
            updatedAt: new Date().toISOString(),
          },
          { merge: true }
        );
      }
    } else {
      profile = {
        uid: account.uid,
        name: cleanEmail.split('@')[0],
        email: cleanEmail,
        profession: 'Corretor de Imóveis',
        businessType: 'Autônomo / MEI',
        tonePreference: 'Consultivo',
        autoCopySignature: false,
        accessStatus: 'active',
        plan: 'free',
        emailVerified: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      await setDoc(userRef, profile);
    }

    return res.json({
      success: true,
      user: profile,
      emailVerified: true,
      session: {
        uid: account.uid,
        email: cleanEmail,
        name: profile.name,
        token: newSessionToken,
        emailVerified: true,
      },
    });
  } catch (err: any) {
    console.error('[handleLogin] Erro no login:', err);
    return res.status(500).json({ error: 'Falha ao autenticar.' });
  }
}

/**
 * Handle verification code confirmation strictly on the server:
 * Validates expiration, attempt counts, and single-use code matching.
 */
export async function handleVerifyCode(req: Request, res: Response) {
  try {
    const { email, code } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanCode = (code || '').trim();

    if (!cleanEmail) {
      return res.status(400).json({ error: 'Endereço de e-mail é obrigatório.' });
    }

    if (!cleanCode || cleanCode.length !== 6 || !/^\d{6}$/.test(cleanCode)) {
      return res.status(400).json({
        error: 'O código de confirmação deve conter exatamente 6 números.',
      });
    }

    const emailDocId = emailToDocId(cleanEmail);
    const accountRef = doc(db, 'accounts', emailDocId);
    const accountSnap = await getDoc(accountRef);

    if (!accountSnap.exists()) {
      return res.status(404).json({ error: 'Conta não encontrada com este e-mail.' });
    }

    const account = accountSnap.data();

    // If already verified, return success
    if (account.emailVerified === true) {
      const userRef = doc(db, 'users', account.uid);
      const userSnap = await getDoc(userRef);
      const user = userSnap.exists() ? (userSnap.data() as UserProfile) : null;
      return res.json({
        success: true,
        verified: true,
        user,
        message: 'E-mail já verificado anteriormente.',
      });
    }

    const attempts = account.verificationAttempts || 0;

    // Rate limit: max 5 failed attempts per issued code
    if (attempts >= 5) {
      return res.status(429).json({
        error: 'Limite de 5 tentativas incorretas excedido. Por segurança, clique em "Reenviar código" para gerar um novo.',
        requiresNewCode: true,
      });
    }

    // Expiration check: 15 minutes
    if (account.verificationExpiresAt) {
      const expirationDate = new Date(account.verificationExpiresAt).getTime();
      if (Date.now() > expirationDate) {
        return res.status(400).json({
          error: 'Este código de verificação expirou (validade de 15 minutos). Clique em "Reenviar código" para receber um novo.',
          expired: true,
        });
      }
    }

    // Exact code match check
    if (!account.verificationCode || account.verificationCode !== cleanCode) {
      const newAttempts = attempts + 1;
      await setDoc(
        accountRef,
        {
          verificationAttempts: newAttempts,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );

      return res.status(400).json({
        error: `Código incorreto. Tentativa ${newAttempts} de 5. Verifique os 6 dígitos recebidos no seu e-mail.`,
        remainingAttempts: 5 - newAttempts,
      });
    }

    // SUCCESS: Mark verified in Firestore
    const now = new Date().toISOString();

    await setDoc(
      accountRef,
      {
        emailVerified: true,
        emailVerifiedAt: now,
        verificationCode: null, // Clear single-use code
        verificationExpiresAt: null,
        verificationAttempts: 0,
        updatedAt: now,
      },
      { merge: true }
    );

    const userRef = doc(db, 'users', account.uid);
    const userSnap = await getDoc(userRef);
    let profile = userSnap.exists() ? (userSnap.data() as UserProfile) : ({} as UserProfile);

    const updatedProfileFields: Partial<UserProfile> = {
      emailVerified: true,
      accessStatus: 'active',
      updatedAt: now,
    };
    await setDoc(userRef, updatedProfileFields, { merge: true });
    profile = { ...profile, ...updatedProfileFields };

    return res.json({
      success: true,
      verified: true,
      user: profile,
      message: 'E-mail verificado com sucesso no servidor!',
    });
  } catch (err: any) {
    console.error('[handleVerifyCode] Erro na verificação:', err);
    return res.status(500).json({ error: 'Erro ao validar confirmação de e-mail.' });
  }
}

/**
 * Handle "Já confirmei meu e-mail":
 * Strictly queries the server's true state in Firestore.
 * NEVER mutates or trusts the frontend button blindly.
 */
export async function handleCheckStatus(req: Request, res: Response) {
  try {
    const email = (req.body?.email || req.query?.email || '') as string;
    const cleanEmail = email.trim().toLowerCase();

    if (!cleanEmail) {
      return res.status(400).json({ error: 'E-mail é obrigatório.' });
    }

    const emailDocId = emailToDocId(cleanEmail);
    const accountRef = doc(db, 'accounts', emailDocId);
    const accountSnap = await getDoc(accountRef);

    if (!accountSnap.exists()) {
      return res.status(404).json({ error: 'Conta não encontrada.' });
    }

    const account = accountSnap.data();
    const verified = account.emailVerified === true;

    return res.json({
      verified,
      emailVerifiedAt: account.emailVerifiedAt || null,
      message: verified
        ? 'E-mail verificado com sucesso.'
        : 'E-mail ainda não verificado. Digite o código de 6 dígitos enviado para seu e-mail.',
    });
  } catch (err: any) {
    console.error('[handleCheckStatus] Erro ao consultar status:', err);
    return res.status(500).json({ error: 'Erro ao consultar status de verificação.' });
  }
}

/**
 * Handle Resend verification email:
 * Enforces cooldown (60s), rate limit (5/hour), generates new code,
 * dispatches email and returns truthful status.
 */
export async function handleResendCode(req: Request, res: Response) {
  try {
    const { email } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();

    if (!cleanEmail) {
      return res.status(400).json({ error: 'E-mail é obrigatório.' });
    }

    const emailDocId = emailToDocId(cleanEmail);
    const accountRef = doc(db, 'accounts', emailDocId);
    const accountSnap = await getDoc(accountRef);

    if (!accountSnap.exists()) {
      return res.status(404).json({ error: 'Conta não encontrada.' });
    }

    const account = accountSnap.data();

    if (account.emailVerified === true) {
      return res.status(400).json({
        error: 'Este e-mail já foi verificado com sucesso.',
      });
    }

    const now = Date.now();

    // 1. Cooldown check: 60 seconds
    if (account.lastVerificationSentAt) {
      const elapsedSeconds = Math.floor(
        (now - new Date(account.lastVerificationSentAt).getTime()) / 1000
      );
      if (elapsedSeconds < 60) {
        const remainingCooldown = 60 - elapsedSeconds;
        return res.status(429).json({
          error: `Por favor, aguarde ${remainingCooldown} segundos antes de solicitar um novo reenvio.`,
          cooldownSeconds: remainingCooldown,
        });
      }
    }

    // 2. Hourly rate limit check: max 5 per hour
    const oneHourAgo = now - 60 * 60 * 1000;
    let resendCount = account.resendCountInHour || 0;
    let windowStart = account.resendWindowStart
      ? new Date(account.resendWindowStart).getTime()
      : 0;

    if (windowStart < oneHourAgo) {
      resendCount = 0;
      windowStart = now;
    }

    if (resendCount >= 5) {
      return res.status(429).json({
        error: 'Limite de reenvios por hora atingido (máximo de 5 envios por hora). Tente novamente mais tarde.',
      });
    }

    // 3. Generate new 6-digit code and 15 min expiration
    const newCode = generateNumericCode();
    const newExpiresAt = new Date(now + 15 * 60 * 1000).toISOString();
    const isoNow = new Date(now).toISOString();

    await setDoc(
      accountRef,
      {
        verificationCode: newCode,
        verificationExpiresAt: newExpiresAt,
        verificationAttempts: 0,
        lastVerificationSentAt: isoNow,
        resendCountInHour: resendCount + 1,
        resendWindowStart: new Date(windowStart).toISOString(),
        updatedAt: isoNow,
      },
      { merge: true }
    );

    // Fetch user name for personalized email
    const userRef = doc(db, 'users', account.uid);
    const userSnap = await getDoc(userRef);
    const userName = userSnap.exists() ? (userSnap.data() as UserProfile).name : '';

    // 4. Attempt real email dispatch
    const mailResult = await sendVerificationEmail({
      to: cleanEmail,
      name: userName,
      code: newCode,
    });

    return res.json({
      success: mailResult.delivered || !!mailResult.isResendSandboxRestricted,
      delivered: mailResult.delivered,
      message: mailResult.message,
      provider: mailResult.provider,
      needsConfig: mailResult.needsConfig,
      isResendSandboxRestricted: mailResult.isResendSandboxRestricted,
      sandboxOwnerEmail: mailResult.sandboxOwnerEmail,
      sandboxCode: mailResult.sandboxCode,
      error: mailResult.error,
    });
  } catch (err: any) {
    console.error('[handleResendCode] Erro ao reenviar código:', err);
    return res.status(500).json({ error: 'Erro ao processar reenvio de código.' });
  }
}

/**
 * Handle correcting destination email address if typed wrong:
 */
export async function handleChangeEmail(req: Request, res: Response) {
  try {
    const { oldEmail, newEmail, sessionToken } = req.body;
    const cleanOld = (oldEmail || '').trim().toLowerCase();
    const cleanNew = (newEmail || '').trim().toLowerCase();

    if (!cleanOld || !cleanNew || !cleanNew.includes('@')) {
      return res.status(400).json({ error: 'Informe um novo e-mail válido.' });
    }

    if (cleanOld === cleanNew) {
      return res.status(400).json({ error: 'O novo e-mail é idêntico ao atual.' });
    }

    const oldDocId = emailToDocId(cleanOld);
    const oldAccountRef = doc(db, 'accounts', oldDocId);
    const oldAccountSnap = await getDoc(oldAccountRef);

    if (!oldAccountSnap.exists()) {
      return res.status(404).json({ error: 'Conta de origem não encontrada.' });
    }

    const oldAccount = oldAccountSnap.data();

    // Validate session token
    if (sessionToken && oldAccount.sessionToken && oldAccount.sessionToken !== sessionToken) {
      return res.status(401).json({ error: 'Sessão inválida para alteração.' });
    }

    // Check if new email is already taken
    const newDocId = emailToDocId(cleanNew);
    const newAccountRef = doc(db, 'accounts', newDocId);
    const newAccountSnap = await getDoc(newAccountRef);

    if (newAccountSnap.exists()) {
      return res.status(400).json({
        error: 'Este novo endereço de e-mail já pertence a outra conta cadastrada.',
      });
    }

    const newCode = generateNumericCode();
    const now = new Date().toISOString();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();

    // Create new account document
    const newAccountData = {
      ...oldAccount,
      email: cleanNew,
      emailVerified: false,
      verificationCode: newCode,
      verificationExpiresAt: expiresAt,
      verificationAttempts: 0,
      lastVerificationSentAt: now,
      updatedAt: now,
    };
    await setDoc(newAccountRef, newAccountData);

    // Remove old account document
    await deleteDoc(oldAccountRef);

    // Update user profile email
    const userRef = doc(db, 'users', oldAccount.uid);
    await setDoc(
      userRef,
      {
        email: cleanNew,
        emailVerified: false,
        updatedAt: now,
      },
      { merge: true }
    );

    // Send email to new address
    const userSnap = await getDoc(userRef);
    const userName = userSnap.exists() ? (userSnap.data() as UserProfile).name : '';

    const mailResult = await sendVerificationEmail({
      to: cleanNew,
      name: userName,
      code: newCode,
    });

    return res.json({
      success: true,
      newEmail: cleanNew,
      mailDelivered: mailResult.delivered,
      mailMessage: mailResult.message,
      needsConfig: mailResult.needsConfig,
    });
  } catch (err: any) {
    console.error('[handleChangeEmail] Erro ao alterar e-mail:', err);
    return res.status(500).json({ error: 'Erro ao atualizar endereço de e-mail.' });
  }
}

/**
 * Handle password reset link request:
 * Generates a secure, temporary 1-hour token and sends email with reset link.
 */
export async function handleRequestPasswordReset(req: Request, res: Response) {
  try {
    const { email } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();

    if (!cleanEmail || !cleanEmail.includes('@')) {
      return res.status(400).json({ error: 'Informe um endereço de e-mail válido.' });
    }

    const emailDocId = emailToDocId(cleanEmail);
    const accountRef = doc(db, 'accounts', emailDocId);
    const accountSnap = await getDoc(accountRef);

    if (!accountSnap.exists()) {
      return res.status(404).json({ error: 'Nenhuma conta encontrada com este e-mail.' });
    }

    const account = accountSnap.data();
    const userRef = doc(db, 'users', account.uid);
    const userSnap = await getDoc(userRef);
    const userName = userSnap.exists() ? (userSnap.data() as UserProfile).name : cleanEmail.split('@')[0];

    // Generate secure temporary token and 1-hour expiration
    const resetToken = generateRandomHex(32);
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000).toISOString();

    await setDoc(
      accountRef,
      {
        passwordResetToken: resetToken,
        passwordResetExpiresAt: expiresAt,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    // Build secure reset link URL
    const origin =
      req.headers.origin ||
      (req.headers.referer ? req.headers.referer.split('#')[0].replace(/\/$/, '') : null) ||
      process.env.APP_URL ||
      'http://localhost:3000';

    const resetLink = `${origin}/#reset-password?token=${resetToken}&email=${encodeURIComponent(cleanEmail)}`;

    // Dispatch email with reset link
    const mailResult = await sendPasswordResetEmail({
      to: cleanEmail,
      name: userName,
      resetLink,
    });

    if (!mailResult.delivered) {
      return res.status(502).json({
        success: false,
        error:
          mailResult.message ||
          mailResult.error ||
          'Não foi possível enviar o e-mail de recuperação de senha no momento. Tente novamente mais tarde.',
      });
    }

    return res.json({
      success: true,
      delivered: true,
      message: 'Link seguro de recuperação enviado com sucesso para seu e-mail! Verifique sua Caixa de Entrada e a pasta de Spam.',
    });
  } catch (err: any) {
    console.error('[handleRequestPasswordReset] Erro:', err);
    return res.status(500).json({ error: 'Erro ao processar solicitação de recuperação de senha.' });
  }
}

/**
 * Handle resetting password with temporary token:
 * Validates token, hashes new password and updates account.
 */
export async function handleResetPasswordWithToken(req: Request, res: Response) {
  try {
    const { email, token, newPassword } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanToken = (token || '').trim();

    if (!cleanEmail || !cleanToken) {
      return res.status(400).json({ error: 'Parâmetros de redefinição inválidos ou incompletos.' });
    }

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: 'A nova senha deve ter no mínimo 6 caracteres.' });
    }

    const emailDocId = emailToDocId(cleanEmail);
    const accountRef = doc(db, 'accounts', emailDocId);
    const accountSnap = await getDoc(accountRef);

    if (!accountSnap.exists()) {
      return res.status(404).json({ error: 'Conta não encontrada.' });
    }

    const account = accountSnap.data();

    // Validate reset token
    if (!account.passwordResetToken || account.passwordResetToken !== cleanToken) {
      return res.status(400).json({ error: 'Link de redefinição inválido ou já utilizado.' });
    }

    // Validate expiration
    const expiresAt = new Date(account.passwordResetExpiresAt || 0).getTime();
    if (expiresAt < Date.now()) {
      return res.status(400).json({ error: 'Este link de redefinição expirou. Solicite um novo link.' });
    }

    // Generate new salt and hash new password
    const newSalt = generateRandomHex(16);
    const newPasswordHash = await hashPassword(newPassword, newSalt);

    await setDoc(
      accountRef,
      {
        salt: newSalt,
        passwordHash: newPasswordHash,
        passwordResetToken: null,
        passwordResetExpiresAt: null,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    return res.json({
      success: true,
      message: 'Senha redefinida com sucesso! Você já pode entrar com sua nova senha.',
    });
  } catch (err: any) {
    console.error('[handleResetPasswordWithToken] Erro:', err);
    return res.status(500).json({ error: 'Erro ao redefinir senha.' });
  }
}
