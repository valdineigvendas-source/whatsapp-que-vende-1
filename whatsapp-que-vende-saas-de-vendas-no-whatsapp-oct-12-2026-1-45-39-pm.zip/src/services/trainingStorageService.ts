import { db } from './firebase';
import {
  collection,
  doc,
  setDoc,
  getDocs,
  getDoc,
  deleteDoc,
  query,
  orderBy,
  limit,
} from 'firebase/firestore';
import { TrainingSession } from '../types';

const LOCAL_STORAGE_ACTIVE_SESSION_PREFIX = 'wq_active_training_session_';

export const trainingStorageService = {
  // Salvar ou atualizar sessão no Firestore do usuário autenticado: /users/{userId}/trainings/{sessionId}
  async saveTrainingSession(userId: string, session: TrainingSession): Promise<void> {
    if (!userId || !session.id) return;

    const payload: TrainingSession = {
      ...session,
      updatedAt: new Date().toISOString(),
    };

    // Backup em LocalStorage imediato para tolerância a offline / refresh da aba
    try {
      localStorage.setItem(`${LOCAL_STORAGE_ACTIVE_SESSION_PREFIX}${userId}`, JSON.stringify(payload));
    } catch {
      // Ignora erro de cota de localStorage
    }

    try {
      const sessionDocRef = doc(db, 'users', userId, 'trainings', session.id);
      await setDoc(sessionDocRef, payload, { merge: true });
    } catch (err) {
      console.error('[trainingStorageService] Erro ao sincronizar sessão de treino no Firestore:', err);
    }
  },

  // Buscar uma sessão específica por ID
  async getTrainingSession(userId: string, sessionId: string): Promise<TrainingSession | null> {
    if (!userId || !sessionId) return null;
    try {
      const sessionDocRef = doc(db, 'users', userId, 'trainings', sessionId);
      const snap = await getDoc(sessionDocRef);
      if (snap.exists()) {
        return snap.data() as TrainingSession;
      }
    } catch (err) {
      console.warn('[trainingStorageService] Falha ao ler Firestore, checando cache local:', err);
    }

    // Fallback local
    try {
      const cached = localStorage.getItem(`${LOCAL_STORAGE_ACTIVE_SESSION_PREFIX}${userId}`);
      if (cached) {
        const parsed = JSON.parse(cached) as TrainingSession;
        if (parsed.id === sessionId) return parsed;
      }
    } catch {}

    return null;
  },

  // Buscar todas as sessões do usuário (ativas, pausadas e concluídas)
  async getUserTrainings(userId: string): Promise<TrainingSession[]> {
    if (!userId) return [];
    try {
      const trainingsCol = collection(db, 'users', userId, 'trainings');
      const q = query(trainingsCol, orderBy('createdAt', 'desc'), limit(50));
      const snap = await getDocs(q);

      const items: TrainingSession[] = [];
      snap.forEach((docSnap) => {
        items.push(docSnap.data() as TrainingSession);
      });

      // Se houver sessão recente no cache local não sincronizada, mesclar
      try {
        const cached = localStorage.getItem(`${LOCAL_STORAGE_ACTIVE_SESSION_PREFIX}${userId}`);
        if (cached) {
          const cachedSession = JSON.parse(cached) as TrainingSession;
          const exists = items.some((i) => i.id === cachedSession.id);
          if (!exists) {
            items.unshift(cachedSession);
          } else {
            // Atualizar com a versão mais recente
            const idx = items.findIndex((i) => i.id === cachedSession.id);
            if (idx >= 0 && cachedSession.updatedAt && (!items[idx].updatedAt || cachedSession.updatedAt > items[idx].updatedAt!)) {
              items[idx] = cachedSession;
            }
          }
        }
      } catch {}

      return items;
    } catch (err) {
      console.error('[trainingStorageService] Erro ao carregar histórico de treinos:', err);
      // Fallback para cache local
      try {
        const cached = localStorage.getItem(`${LOCAL_STORAGE_ACTIVE_SESSION_PREFIX}${userId}`);
        if (cached) return [JSON.parse(cached) as TrainingSession];
      } catch {}
      return [];
    }
  },

  // Excluir permanentemente uma sessão
  async deleteTrainingSession(userId: string, sessionId: string): Promise<void> {
    if (!userId || !sessionId) return;
    try {
      const sessionDocRef = doc(db, 'users', userId, 'trainings', sessionId);
      await deleteDoc(sessionDocRef);
    } catch (err) {
      console.error('[trainingStorageService] Erro ao deletar sessão:', err);
    }

    try {
      const cached = localStorage.getItem(`${LOCAL_STORAGE_ACTIVE_SESSION_PREFIX}${userId}`);
      if (cached) {
        const parsed = JSON.parse(cached) as TrainingSession;
        if (parsed.id === sessionId) {
          localStorage.removeItem(`${LOCAL_STORAGE_ACTIVE_SESSION_PREFIX}${userId}`);
        }
      }
    } catch {}
  },
};
