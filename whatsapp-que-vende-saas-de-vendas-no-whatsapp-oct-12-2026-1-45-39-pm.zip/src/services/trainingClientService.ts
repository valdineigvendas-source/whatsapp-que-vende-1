import { TrainingConfig, ChatMessage, TrainingEvaluation } from '../types';
import { authService } from './authService';

function getAuthHeaders(): Record<string, string> {
  const session = authService.getCurrentSession();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (session?.token) {
    headers['Authorization'] = `Bearer ${session.token}`;
  }
  if (session?.email) {
    headers['x-user-email'] = session.email;
  }
  return headers;
}

export const trainingClientService = {
  // Enviar mensagem e receber reação com streaming ou fallback seguro
  async sendCustomerReplyWithStream(
    config: TrainingConfig,
    messages: ChatMessage[],
    modalityTitle: string,
    onChunk: (chunk: string, accumulated: string) => void
  ): Promise<string> {
    try {
      const configEncoded = encodeURIComponent(JSON.stringify(config));
      const messagesEncoded = encodeURIComponent(JSON.stringify(messages));
      const titleEncoded = encodeURIComponent(modalityTitle);

      const session = authService.getCurrentSession();
      const authQuery = session
        ? `&email=${encodeURIComponent(session.email)}&token=${encodeURIComponent(session.token)}`
        : '';

      const response = await fetch(
        `/api/training/reply-stream?config=${configEncoded}&messages=${messagesEncoded}&modalityTitle=${titleEncoded}${authQuery}`,
        {
          headers: getAuthHeaders(),
        }
      );

      if (!response.ok || !response.body) {
        throw new Error('Streaming indisponível, acionando fallback.');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulated = '';
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data: ')) continue;
          const payload = trimmed.replace('data: ', '');

          if (payload === '[DONE]') {
            break;
          }

          try {
            const data = JSON.parse(payload);
            if (data.chunk) {
              accumulated += data.chunk;
              onChunk(data.chunk, accumulated);
            }
          } catch {
            // Ignora linhas incompletas no buffer
          }
        }
      }

      if (accumulated.trim().length > 0) {
        return accumulated.trim();
      }
    } catch (streamErr) {
      console.warn('[trainingClientService] Falha no streaming SSE, usando POST regular:', streamErr);
    }

    // Fallback regular via POST se streaming tiver qualquer instabilidade de conexão
    return await this.sendCustomerReply(config, messages, modalityTitle);
  },

  // Enviar mensagem do usuário e receber reação do cliente simulado
  async sendCustomerReply(
    config: TrainingConfig,
    messages: ChatMessage[],
    modalityTitle: string
  ): Promise<string> {
    const res = await fetch('/api/training/reply', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ config, messages, modalityTitle }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Falha ao obter resposta do cliente.');
    }

    const data = await res.json();
    return data.reply;
  },

  // Obter dica pedagógica sem revelar a resposta pronta
  async getHint(
    config: TrainingConfig,
    messages: ChatMessage[],
    modalityTitle: string
  ): Promise<string> {
    const res = await fetch('/api/training/hint', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ config, messages, modalityTitle }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Falha ao obter dica.');
    }

    const data = await res.json();
    return data.hint;
  },

  // Gerar avaliação final completa do treinamento
  async evaluateSession(
    config: TrainingConfig,
    messages: ChatMessage[],
    modalityTitle: string
  ): Promise<TrainingEvaluation> {
    const res = await fetch('/api/training/evaluate', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ config, messages, modalityTitle }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Falha ao processar avaliação.');
    }

    const data = await res.json();
    return data.evaluation;
  },

  // Transcrever áudio gravado via MediaRecorder no backend (fallback caso SpeechRecognition falhe ou sem permissão na WebSpeech)
  async transcribeAudio(audioBlob: Blob): Promise<string> {
    const arrayBuffer = await audioBlob.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const audioBase64 = btoa(binary);

    const res = await fetch('/api/training/transcribe', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({
        audioBase64,
        mimeType: audioBlob.type || 'audio/webm',
      }),
    });

    if (!res.ok) {
      throw new Error('Falha ao processar áudio.');
    }

    const data = await res.json();
    return data.transcript || '';
  },
};
