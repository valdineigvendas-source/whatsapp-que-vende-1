import { db } from './firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { AcademyProgress, UserDiagnostic, SalesTechniqueId, AcademyLevelNumber } from '../types';

const LOCAL_STORAGE_KEY_PREFIX = 'wq_academy_progress_';

export const academyStorageService = {
  // Obter progresso da Academia do usuário
  async getProgress(userId: string): Promise<AcademyProgress> {
    const defaultProgress: AcademyProgress = {
      userId,
      currentLevel: 1,
      completedLessonIds: [],
      completedChallengeIds: [],
      recommendedTechniqueId: 'aida',
      recommendationReason: 'Ideal para estruturar mensagens claras e objetivas no primeiro contato.',
      lastUpdated: new Date().toISOString(),
    };

    if (!userId) return defaultProgress;

    try {
      const docRef = doc(db, 'users', userId, 'academy_progress', 'main');
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        return snap.data() as AcademyProgress;
      }
    } catch (err) {
      console.warn('[academyStorageService] Firestore indisponível, usando localStorage:', err);
    }

    try {
      const local = localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}${userId}`);
      if (local) {
        return JSON.parse(local) as AcademyProgress;
      }
    } catch {}

    return defaultProgress;
  },

  // Salvar ou atualizar progresso da Academia
  async saveProgress(userId: string, progress: Partial<AcademyProgress>): Promise<AcademyProgress> {
    const current = await this.getProgress(userId);
    const updated: AcademyProgress = {
      ...current,
      ...progress,
      userId,
      lastUpdated: new Date().toISOString(),
    };

    try {
      localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}${userId}`, JSON.stringify(updated));
    } catch {}

    try {
      const docRef = doc(db, 'users', userId, 'academy_progress', 'main');
      await setDoc(docRef, updated, { merge: true });
    } catch (err) {
      console.warn('[academyStorageService] Erro ao salvar no Firestore:', err);
    }

    return updated;
  },

  // Marcar aula de técnica como concluída
  async completeLesson(userId: string, techniqueId: SalesTechniqueId): Promise<AcademyProgress> {
    const current = await this.getProgress(userId);
    const completed = new Set(current.completedLessonIds);
    completed.add(techniqueId);

    // Avaliar evolução de nível:
    let newLevel = current.currentLevel;
    if (completed.size >= 5 && current.currentLevel < 4) {
      newLevel = 4;
    } else if (completed.size >= 3 && current.currentLevel < 3) {
      newLevel = 3;
    } else if (completed.size >= 1 && current.currentLevel < 2) {
      newLevel = 2;
    }

    return await this.saveProgress(userId, {
      completedLessonIds: Array.from(completed),
      currentLevel: newLevel,
    });
  },

  // Marcar desafio prático como concluído
  async completeChallenge(userId: string, challengeId: string): Promise<AcademyProgress> {
    const current = await this.getProgress(userId);
    const completed = new Set(current.completedChallengeIds);
    completed.add(challengeId);

    return await this.saveProgress(userId, {
      completedChallengeIds: Array.from(completed),
    });
  },

  // Salvar diagnóstico do usuário
  async saveDiagnostic(userId: string, diagnostic: UserDiagnostic): Promise<AcademyProgress> {
    // Escolher recomendação inteligente baseada na dificuldade relatada
    let recommendedTechniqueId: SalesTechniqueId = 'aida';
    let recommendationReason = 'Recomendado para organizar sua abordagem inicial com clareza.';

    const diff = (diagnostic.biggestDifficulty || '').toLowerCase();
    if (diff.includes('preço') || diff.includes('caro') || diff.includes('objeç')) {
      recommendedTechniqueId = 'tratamento-objecoes';
      recommendationReason = 'Você mencionou dificuldade com objeções de preço. Essa técnica ensina a contornar sem dar descontos.';
    } else if (diff.includes('fechar') || diff.includes('fechamento') || diff.includes('converter')) {
      recommendedTechniqueId = 'tecnicas-fechamento';
      recommendationReason = 'Focado em transformar conversas bem encaminhadas em compras fechadas.';
    } else if (diff.includes('sumiu') || diff.includes('resposta') || diff.includes('responder')) {
      recommendedTechniqueId = 'atendimento-relacionamento';
      recommendationReason = 'Técnica ideal para recuperar clientes que pararam de responder sem parecer insistente.';
    } else if (diff.includes('entender') || diff.includes('necessidade') || diff.includes('pergunta')) {
      recommendedTechniqueId = 'spin-selling';
      recommendationReason = 'Perfeito para descobrir necessidades ocultas antes de apresentar a solução.';
    }

    return await this.saveProgress(userId, {
      diagnostic: {
        ...diagnostic,
        completedAt: new Date().toISOString(),
      },
      recommendedTechniqueId,
      recommendationReason,
    });
  },
};
