import React, { useState } from 'react';
import { SalesTechnique, UserDiagnostic } from '../../types';
import {
  X,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  BookOpen,
  HelpCircle,
  ThumbsDown,
  ThumbsUp,
  Target,
  Bot,
  Lightbulb,
} from 'lucide-react';

interface AcademyTechniqueDetailModalProps {
  technique: SalesTechnique;
  isCompleted: boolean;
  userNiche: string;
  onComplete: (techniqueId: string) => void;
  onPracticeWithAi: (technique: SalesTechnique) => void;
  onClose: () => void;
}

export const AcademyTechniqueDetailModal: React.FC<AcademyTechniqueDetailModalProps> = ({
  technique,
  isCompleted,
  userNiche,
  onComplete,
  onPracticeWithAi,
  onClose,
}) => {
  const [userExerciseAnswer, setUserExerciseAnswer] = useState('');
  const [showExerciseSolution, setShowExerciseSolution] = useState(false);
  const [copiedExercise, setCopiedExercise] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#0D141A] border border-[#1E2C36] rounded-2xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl relative overflow-hidden max-h-[92vh] flex flex-col">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-56 h-56 bg-[#25D366]/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header */}
        <div className="flex items-start justify-between gap-3 pb-4 border-b border-[#1E2C36] shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-3xl p-2 rounded-xl bg-[#14221A] border border-[#25D366]/30">
              {technique.emoji}
            </span>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#1B2936] text-slate-300">
                  {technique.category}
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#25D366]/15 text-[#25D366] border border-[#25D366]/30">
                  Nível {technique.level}
                </span>
                {isCompleted && (
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Concluída
                  </span>
                )}
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white mt-1">
                {technique.title}
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            type="button"
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800/60 transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto pr-1 py-4 space-y-6 flex-1 text-slate-200">
          {/* 1. O que é de forma simples */}
          <div className="bg-[#121A22] border border-[#1F2C37] rounded-xl p-4">
            <div className="flex items-center gap-2 text-xs font-bold text-[#25D366] uppercase tracking-wider mb-2">
              <BookOpen className="w-4 h-4" />
              <span>O que é de forma simples</span>
            </div>
            <p className="text-sm text-slate-300 leading-relaxed">
              {technique.simpleExplanation}
            </p>
          </div>

          {/* 2. Como funciona passo a passo no WhatsApp */}
          <div className="bg-[#121A22] border border-[#1F2C37] rounded-xl p-4">
            <div className="flex items-center gap-2 text-xs font-bold text-sky-400 uppercase tracking-wider mb-3">
              <Sparkles className="w-4 h-4" />
              <span>Como aplicar no WhatsApp passo a passo</span>
            </div>
            <div className="space-y-2.5">
              {technique.howItWorks.map((step, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-2.5 p-2.5 rounded-lg bg-[#0E151C] border border-[#1B2732] text-xs sm:text-sm text-slate-300 leading-relaxed"
                >
                  <span className="w-5 h-5 rounded-full bg-[#25D366]/20 text-[#25D366] font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span>{step}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 3. Quando usar */}
          <div className="p-3.5 rounded-xl bg-[#14231E]/60 border border-[#25D366]/30 text-xs sm:text-sm text-slate-300 leading-relaxed">
            <span className="font-bold text-[#25D366] mr-1.5">📌 Quando usar:</span>
            {technique.whenToUse}
          </div>

          {/* 4. Comparativo: Abordagem Amadora vs Profissional */}
          <div className="space-y-3">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Comparativo de Atendimento no WhatsApp
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Amadora */}
              <div className="bg-[#1C1315] border border-red-500/30 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-red-400">
                  <ThumbsDown className="w-3.5 h-3.5" />
                  <span>Abordagem Fraca / Amadora</span>
                </div>
                <div className="bg-[#120B0D] p-3 rounded-lg text-xs text-red-200 border border-red-500/20 italic leading-relaxed">
                  {technique.poorApproachExample}
                </div>
              </div>

              {/* Profissional */}
              <div className="bg-[#101D16] border border-[#25D366]/40 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#25D366]">
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span>Abordagem de Alta Conversão</span>
                </div>
                <div className="bg-[#0A160F] p-3 rounded-lg text-xs text-emerald-200 border border-[#25D366]/30 italic leading-relaxed">
                  {technique.improvedApproachExample}
                </div>
              </div>
            </div>
          </div>

          {/* 5. Dica de ouro para o seu nicho */}
          <div className="bg-gradient-to-r from-[#141C24] to-[#12231A] border border-[#233544] rounded-xl p-4 flex items-start gap-3">
            <Lightbulb className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-1">
                Dica prática para seu segmento ({userNiche || 'Geral'})
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {technique.nicheSpecificExampleTip}
              </p>
            </div>
          </div>

          {/* 6. Exercício prático interativo */}
          <div className="bg-[#111A22] border border-[#1F2C37] rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold text-purple-400 uppercase tracking-wider">
                <Target className="w-4 h-4" />
                <span>{technique.practicalExercise.title}</span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {technique.practicalExercise.description}
            </p>

            <div className="bg-[#0B1218] p-3 rounded-lg border border-[#1A2632] text-xs text-slate-300">
              <span className="font-bold text-white">Cenário: </span>
              {technique.practicalExercise.taskPrompt}
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                Como você responderia a essa situação? (Pratique aqui):
              </label>
              <textarea
                value={userExerciseAnswer}
                onChange={(e) => setUserExerciseAnswer(e.target.value)}
                placeholder="Digite sua resposta aplicando a técnica..."
                rows={3}
                className="w-full bg-[#141F28] border border-[#22313E] rounded-xl p-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366] resize-none"
              />
            </div>

            <div className="flex items-center justify-between gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowExerciseSolution(!showExerciseSolution)}
                className="text-xs font-semibold text-[#25D366] hover:underline flex items-center gap-1 cursor-pointer"
              >
                {showExerciseSolution ? 'Ocultar Resposta Modelo' : 'Ver Resposta Modelo e Por que Funciona'}
              </button>
            </div>

            {showExerciseSolution && (
              <div className="p-3 rounded-lg bg-[#14231E] border border-[#25D366]/40 text-xs text-emerald-200 space-y-1.5 animate-in fade-in">
                <div className="font-bold text-[#25D366]">💡 Resposta Modelo Recomendada:</div>
                <div className="italic bg-[#0A160F] p-2.5 rounded border border-[#25D366]/20">
                  {technique.practicalExercise.sampleSolution}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-[#1E2C36] flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={() => onComplete(technique.id)}
            className={`w-full sm:w-auto px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              isCompleted
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30'
                : 'bg-[#1E2C36] hover:bg-[#283B48] text-white border border-[#2C3E4C]'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{isCompleted ? 'Concluída (Clique para reavaliar)' : 'Marcar Aula como Concluída'}</span>
          </button>

          <button
            type="button"
            onClick={() => onPracticeWithAi(technique)}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#25D366]/20 cursor-pointer"
          >
            <Bot className="w-4 h-4" />
            <span>Praticar com Cliente IA</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
