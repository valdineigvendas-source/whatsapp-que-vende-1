import React, { useState } from 'react';
import { PracticalChallenge } from '../../types';
import {
  X,
  Target,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  MessageCircle,
  ThumbsUp,
  HelpCircle,
} from 'lucide-react';

interface AcademyChallengeModalProps {
  challenge: PracticalChallenge;
  isCompleted: boolean;
  onComplete: (challengeId: string) => void;
  onClose: () => void;
}

export const AcademyChallengeModal: React.FC<AcademyChallengeModalProps> = ({
  challenge,
  isCompleted,
  onComplete,
  onClose,
}) => {
  const [userResponse, setUserResponse] = useState('');
  const [revealed, setRevealed] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#0D141A] border border-[#1E2C36] rounded-2xl max-w-xl w-full p-5 sm:p-6 shadow-2xl relative overflow-hidden max-h-[92vh] flex flex-col">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#25D366]/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-[#1E2C36] shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-2xl p-2 rounded-xl bg-[#14221A] border border-[#25D366]/30">
              {challenge.emoji}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#25D366]/15 text-[#25D366] border border-[#25D366]/30">
                  Desafio Prático
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#1B2936] text-slate-300">
                  Nível {challenge.level}
                </span>
                {isCompleted && (
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Concluído
                  </span>
                )}
              </div>
              <h2 className="text-base sm:text-lg font-bold text-white mt-1">
                {challenge.title}
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            type="button"
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800/60 transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto pr-1 py-4 space-y-4 flex-1 text-slate-200">
          {/* Scenario description */}
          <div className="bg-[#121A22] border border-[#1F2C37] rounded-xl p-3.5 space-y-1.5">
            <div className="text-[11px] font-bold text-[#25D366] uppercase tracking-wider">
              Contexto da Situação
            </div>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {challenge.scenario}
            </p>
          </div>

          {/* Customer message balloon */}
          <div className="space-y-1.5">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <MessageCircle className="w-3.5 h-3.5 text-sky-400" />
              <span>Mensagem do Cliente no WhatsApp:</span>
            </div>
            <div className="flex justify-start">
              <div className="bg-[#1F2C34] border border-[#2B3B46] text-white p-3.5 rounded-2xl rounded-tl-sm max-w-[90%] text-xs sm:text-sm shadow-md">
                <div className="text-[10px] text-slate-400 mb-0.5 font-semibold">Cliente</div>
                <div className="leading-relaxed">{challenge.customerMessage}</div>
              </div>
            </div>
          </div>

          {/* Mission Instruction */}
          <div className="p-3 rounded-xl bg-[#14231E]/60 border border-[#25D366]/30 text-xs sm:text-sm text-slate-300">
            <span className="font-bold text-[#25D366] mr-1">🎯 Sua Missão:</span>
            {challenge.instruction}
          </div>

          {/* User input */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-semibold text-slate-300">
              Escreva sua resposta comercial:
            </label>
            <textarea
              value={userResponse}
              onChange={(e) => setUserResponse(e.target.value)}
              placeholder="Digite exatamente como você enviaria no WhatsApp..."
              rows={3}
              className="w-full bg-[#141F28] border border-[#22313E] rounded-xl p-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366] resize-none"
            />
          </div>

          {/* Button to reveal model solution */}
          <div>
            <button
              type="button"
              onClick={() => setRevealed(!revealed)}
              className="text-xs font-semibold text-[#25D366] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              {revealed ? 'Ocultar Comparação Profissional' : 'Comparar com a Resposta Profissional'}
            </button>
          </div>

          {/* Revealed Solution */}
          {revealed && (
            <div className="space-y-3 p-4 rounded-xl bg-[#101D16] border border-[#25D366]/40 animate-in fade-in">
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-[#25D366] uppercase tracking-wider flex items-center gap-1.5">
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span>Resposta Modelo Recomendada:</span>
                </div>
                <div className="flex justify-end">
                  <div className="bg-[#005C4B] text-white p-3.5 rounded-2xl rounded-tr-sm max-w-[95%] text-xs sm:text-sm shadow-md">
                    <div className="text-[10px] text-emerald-200 mb-0.5 font-semibold">Você (Alta Conversão)</div>
                    <div className="leading-relaxed">{challenge.exampleGoodAnswer}</div>
                  </div>
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-[#0A160F] border border-[#25D366]/20 text-xs text-emerald-300/90 leading-relaxed">
                <span className="font-bold text-[#25D366] mr-1">Por que funciona:</span>
                {challenge.whyItWorks}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-[#1E2C36] flex items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white cursor-pointer"
          >
            Fechar
          </button>

          <button
            type="button"
            onClick={() => {
              onComplete(challenge.id);
            }}
            className="px-5 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#25D366]/20 cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{isCompleted ? 'Desafio Concluído! ✓' : 'Marcar Desafio como Concluído'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
