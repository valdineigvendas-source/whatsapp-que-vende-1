import React, { useState } from 'react';
import { UserDiagnostic } from '../../types';
import { Sparkles, Target, Check, HelpCircle, X, ArrowRight } from 'lucide-react';

interface AcademyDiagnosticModalProps {
  initialNiche: string;
  onSave: (diagnostic: UserDiagnostic) => void;
  onCancel: () => void;
}

export const AcademyDiagnosticModal: React.FC<AcademyDiagnosticModalProps> = ({
  initialNiche,
  onSave,
  onCancel,
}) => {
  const [niche, setNiche] = useState(initialNiche || 'Serviços e Vendas');
  const [productSold, setProductSold] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [biggestDifficulty, setBiggestDifficulty] = useState('Cliente diz que está caro');
  const [skillToImprove, setSkillToImprove] = useState('Contornar objeções de preço');

  const difficulties = [
    'Cliente diz que está caro e pede desconto',
    'Cliente visualiza o preço e para de responder',
    'Cliente diz que vai pensar ou falar com outra pessoa',
    'Dificuldade em puxar assunto e prender atenção no primeiro contato',
    'Fazer o fechamento sem parecer agressivo ou chato',
  ];

  const skills = [
    'Contornar objeções de preço',
    'Fazer perguntas certas para descobrir a necessidade',
    'Apresentar preço com valor agregado',
    'Follow-up elegante sem ser invasivo',
    'Fechamento natural e seguro',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      niche: niche.trim() || initialNiche,
      productSold: productSold.trim() || 'Produtos e Serviços',
      targetAudience: targetAudience.trim() || 'Público geral',
      biggestDifficulty,
      skillToImprove,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#0D141A] border border-[#1E2C36] rounded-2xl max-w-xl w-full p-6 sm:p-7 shadow-2xl relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#25D366]/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close */}
        <button
          onClick={onCancel}
          type="button"
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800/50 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-5">
          <div className="inline-flex items-center gap-2 text-xs font-bold text-[#25D366] uppercase tracking-wider mb-1.5">
            <Sparkles className="w-4 h-4" />
            <span>Diagnóstico do Treinador de Vendas</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Personalize sua Academia de Vendas
          </h2>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            Responda em 30 segundos para que a IA adapte todas as aulas, exemplos e clientes simulados exatamente ao seu negócio.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Qual é o seu nicho de atuação?
            </label>
            <input
              type="text"
              value={niche}
              onChange={(e) => setNiche(e.target.value)}
              placeholder="Ex: Imóveis, Estética, Roupas, Barbearia, Consultoria, Alimentação..."
              className="w-full bg-[#141E26] border border-[#253644] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              O que você vende no dia a dia?
            </label>
            <input
              type="text"
              value={productSold}
              onChange={(e) => setProductSold(e.target.value)}
              placeholder="Ex: Apartamentos de médio padrão, Corte e barba, Procedimentos corporais..."
              className="w-full bg-[#141E26] border border-[#253644] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Quem é o seu cliente ideal? (Opcional)
            </label>
            <input
              type="text"
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value)}
              placeholder="Ex: Famílias buscando o primeiro imóvel, Mulheres de 25 a 45 anos..."
              className="w-full bg-[#141E26] border border-[#253644] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
            />
          </div>

          {/* Dificuldade */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Qual é a sua maior dificuldade atual para vender no WhatsApp?
            </label>
            <div className="space-y-1.5">
              {difficulties.map((diff, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setBiggestDifficulty(diff)}
                  className={`w-full p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer flex items-center justify-between ${
                    biggestDifficulty === diff
                      ? 'bg-[#15251C] border-[#25D366] text-[#25D366] font-bold'
                      : 'bg-[#131C23] border-[#22323F] text-slate-300 hover:text-white'
                  }`}
                >
                  <span>{diff}</span>
                  {biggestDifficulty === diff && <Check className="w-4 h-4 shrink-0 text-[#25D366]" />}
                </button>
              ))}
            </div>
          </div>

          {/* Habilidade a melhorar */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Qual habilidade você quer priorizar primeiro?
            </label>
            <select
              value={skillToImprove}
              onChange={(e) => setSkillToImprove(e.target.value)}
              className="w-full bg-[#141E26] border border-[#253644] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-[#25D366] cursor-pointer"
            >
              {skills.map((s, idx) => (
                <option key={idx} value={s} className="bg-[#0E151B]">
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div className="pt-3">
            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#25D366]/20 cursor-pointer"
            >
              <span>Salvar e Gerar Trilha Personalizada</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
