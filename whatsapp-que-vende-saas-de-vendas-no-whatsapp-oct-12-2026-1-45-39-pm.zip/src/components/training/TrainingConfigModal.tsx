import React, { useState } from 'react';
import {
  TrainingConfig,
  TrainingModality,
  CustomerProfileType,
  DifficultyLevel,
  TrainingInteractionMode,
} from '../../types';
import { CUSTOMER_PROFILES, DIFFICULTY_LEVELS } from '../../data/trainingData';
import {
  Sparkles,
  ArrowRight,
  X,
  Mic,
  Keyboard,
  Zap,
  Volume2,
} from 'lucide-react';

interface TrainingConfigModalProps {
  modality: TrainingModality;
  defaultProduct: string;
  onStart: (config: TrainingConfig) => void;
  onCancel: () => void;
}

export const TrainingConfigModal: React.FC<TrainingConfigModalProps> = ({
  modality,
  defaultProduct,
  onStart,
  onCancel,
}) => {
  const [interactionMode, setInteractionMode] = useState<TrainingInteractionMode>('text');
  const [productOrService, setProductOrService] = useState(defaultProduct || 'Consultoria e Vendas');
  const [specificItem, setSpecificItem] = useState('');
  const [customerProfile, setCustomerProfile] = useState<CustomerProfileType>('indeciso');
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('intermediario');
  const [commercialDetails, setCommercialDetails] = useState('');
  const [autoPlayAudio, setAutoPlayAudio] = useState(true);

  const handleStartCustom = (e: React.FormEvent) => {
    e.preventDefault();
    onStart({
      modalityId: modality.id,
      productOrService: productOrService.trim() || 'Serviços e Produtos',
      specificItem: specificItem.trim() || undefined,
      professionName: defaultProduct,
      customerProfile,
      difficulty,
      commercialDetails: commercialDetails.trim() || undefined,
      interactionMode,
      autoPlayAudio,
      autoSendVoice: false,
    });
  };

  const handleStartQuick = (mode: TrainingInteractionMode) => {
    onStart({
      modalityId: modality.id,
      productOrService: defaultProduct || 'Produtos e Serviços',
      professionName: defaultProduct,
      customerProfile: 'indeciso',
      difficulty: 'intermediario',
      interactionMode: mode,
      autoPlayAudio: true,
      autoSendVoice: false,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#0D141A] border border-[#1E2C36] rounded-2xl max-w-xl w-full p-6 sm:p-7 shadow-2xl relative overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#25D366]/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close */}
        <button
          onClick={onCancel}
          type="button"
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800/50 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-5">
          <div className="inline-flex items-center gap-2 text-xs font-bold text-[#25D366] uppercase tracking-wider mb-1.5">
            <span>{modality.emoji}</span>
            <span>Configuração do Treino</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            {modality.title}
          </h2>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            {modality.description}
          </p>
        </div>

        {/* Escolha do Modo de Interação: TEXTO ou VOZ */}
        <div className="mb-5 p-4 rounded-xl bg-[#111A22] border border-[#233544] space-y-2.5">
          <label className="block text-xs font-bold text-white">
            Como você deseja treinar agora?
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setInteractionMode('text')}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                interactionMode === 'text'
                  ? 'bg-[#15251C] border-[#25D366] text-white shadow-md shadow-[#25D366]/10 font-bold'
                  : 'bg-[#131C23] border-[#202E3B] text-slate-300 hover:text-white'
              }`}
            >
              <Keyboard className={`w-5 h-5 ${interactionMode === 'text' ? 'text-[#25D366]' : 'text-slate-400'}`} />
              <span className="text-xs">⌨️ Treinar por texto</span>
              <span className="text-[10px] text-slate-400 text-center font-normal">Digite suas respostas no WhatsApp</span>
            </button>

            <button
              type="button"
              onClick={() => setInteractionMode('voice')}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                interactionMode === 'voice'
                  ? 'bg-[#15251C] border-[#25D366] text-white shadow-md shadow-[#25D366]/10 font-bold'
                  : 'bg-[#131C23] border-[#202E3B] text-slate-300 hover:text-white'
              }`}
            >
              <Mic className={`w-5 h-5 ${interactionMode === 'voice' ? 'text-[#25D366]' : 'text-slate-400'}`} />
              <span className="text-xs">🎙️ Treinar por voz</span>
              <span className="text-[10px] text-slate-400 text-center font-normal">Fale no microfone e ouça o cliente</span>
            </button>
          </div>

          {interactionMode === 'voice' && (
            <div className="pt-2 flex items-center gap-2 text-[11px] text-slate-300">
              <input
                type="checkbox"
                id="autoPlayAudio"
                checked={autoPlayAudio}
                onChange={(e) => setAutoPlayAudio(e.target.checked)}
                className="rounded accent-[#25D366]"
              />
              <label htmlFor="autoPlayAudio" className="cursor-pointer flex items-center gap-1">
                <Volume2 className="w-3.5 h-3.5 text-[#25D366]" />
                <span>Ouvir a fala do cliente automaticamente ao receber a resposta</span>
              </label>
            </div>
          )}
        </div>

        {/* Quick Start Option */}
        <div className="mb-5 p-3.5 rounded-xl bg-[#121B22] border border-[#233543] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <span className="text-xs font-semibold text-white block">Quer começar agora sem preencher?</span>
            <span className="text-[11px] text-slate-400 truncate block">Usar cenário padrão pronto ({defaultProduct})</span>
          </div>
          <button
            type="button"
            onClick={() => handleStartQuick(interactionMode)}
            className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-[#25D366] border border-emerald-500/30 text-xs font-bold flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Treino Rápido</span>
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleStartCustom} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              O que você vende?
            </label>
            <input
              type="text"
              value={productOrService}
              onChange={(e) => setProductOrService(e.target.value)}
              placeholder="Ex: Imóveis, Roupas, Procedimentos estéticos, Consultoria..."
              className="w-full bg-[#141E26] border border-[#253644] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Qual produto ou serviço específico será utilizado no treino? (Opcional)
            </label>
            <input
              type="text"
              value={specificItem}
              onChange={(e) => setSpecificItem(e.target.value)}
              placeholder="Ex: Apartamento 2 quartos, Pacote de 10 sessões, Mentoria semestral..."
              className="w-full bg-[#141E26] border border-[#253644] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
            />
          </div>

          {/* Perfil do cliente */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Qual é o perfil do cliente simulado?
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {CUSTOMER_PROFILES.map((prof) => (
                <button
                  key={prof.id}
                  type="button"
                  onClick={() => setCustomerProfile(prof.id)}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                    customerProfile === prof.id
                      ? 'bg-[#15251C] border-[#25D366] text-[#25D366] font-bold'
                      : 'bg-[#131C23] border-[#22323F] text-slate-300 hover:text-white'
                  }`}
                >
                  <span className="mr-1.5">{prof.emoji}</span>
                  <span>{prof.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Nível de dificuldade */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Nível de dificuldade:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {DIFFICULTY_LEVELS.map((lvl) => (
                <button
                  key={lvl.id}
                  type="button"
                  onClick={() => setDifficulty(lvl.id)}
                  className={`p-2.5 rounded-xl border text-center text-xs transition-all cursor-pointer ${
                    difficulty === lvl.id
                      ? 'bg-[#15251C] border-[#25D366] text-[#25D366] font-bold'
                      : 'bg-[#131C23] border-[#22323F] text-slate-300 hover:text-white'
                  }`}
                >
                  {lvl.label}
                </button>
              ))}
            </div>
          </div>

          {/* Condições comerciais personalizadas */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Preço, prazo ou condições da sua oferta para a IA respeitar (Opcional):
            </label>
            <input
              type="text"
              value={commercialDetails}
              onChange={(e) => setCommercialDetails(e.target.value)}
              placeholder="Ex: R$ 450,00 à vista ou 3x sem juros, garantia de 30 dias"
              className="w-full bg-[#141E26] border border-[#253644] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
            />
            <span className="text-[10px] text-slate-500 mt-0.5 block">
              A simulação respeitará rigorosamente esses dados sem inventar valores.
            </span>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#25D366]/20 cursor-pointer"
            >
              <span>{interactionMode === 'voice' ? 'Iniciar Simulação por Voz 🎙️' : 'Iniciar no Simulador ⌨️'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
