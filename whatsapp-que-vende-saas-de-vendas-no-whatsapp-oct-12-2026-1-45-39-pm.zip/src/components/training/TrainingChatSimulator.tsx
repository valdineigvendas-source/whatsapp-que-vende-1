import React, { useState, useEffect, useRef } from 'react';
import { TrainingConfig, ChatMessage, TrainingInteractionMode } from '../../types';
import { trainingClientService } from '../../services/trainingClientService';
import { voiceService } from '../../services/voiceService';
import {
  Send,
  Lightbulb,
  X,
  RotateCcw,
  User,
  Loader2,
  CheckCheck,
  CheckCircle,
  AlertCircle,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  PauseCircle,
  Play,
  Pause,
  ChevronDown,
  ChevronUp,
  Trash2,
  Lock,
} from 'lucide-react';
import { TRAINING_MODALITIES } from '../../data/trainingData';

interface TrainingChatSimulatorProps {
  config: TrainingConfig;
  initialMessages: ChatMessage[];
  onFinish: (finalMessages: ChatMessage[]) => void;
  onPause: (currentMessages: ChatMessage[]) => void;
  onAutoSave?: (currentMessages: ChatMessage[]) => void;
  onCancel: () => void;
  onRestart: () => void;
}

export const TrainingChatSimulator: React.FC<TrainingChatSimulatorProps> = ({
  config,
  initialMessages,
  onFinish,
  onPause,
  onAutoSave,
  onCancel,
  onRestart,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isFinishing, setIsFinishing] = useState(false);
  const [hint, setHint] = useState<string | null>(null);
  const [loadingHint, setLoadingHint] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Modo de interação e áudio
  const [mode, setMode] = useState<TrainingInteractionMode>(config.interactionMode || 'voice');
  const [autoPlayAudio, setAutoPlayAudio] = useState<boolean>(config.autoPlayAudio !== false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Estados de Gravação de Voz (Audio Recorder)
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [isProcessingAudio, setIsProcessingAudio] = useState(false);
  const [showPermissionModal, setShowPermissionModal] = useState(false);

  // Áudio player local para ouvir a própria gravação
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const currentAudioElementRef = useRef<HTMLAudioElement | null>(null);

  // Exibir / ocultar transcrição discreta
  const [expandedTranscripts, setExpandedTranscripts] = useState<Record<string, boolean>>({});

  const stopListeningRef = useRef<(() => void) | null>(null);
  const recordingTimerRef = useRef<any>(null);

  // Streaming text placeholder ID
  const [streamingMessageId, setStreamingMessageId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const modality = TRAINING_MODALITIES.find((m) => m.id === config.modalityId) || TRAINING_MODALITIES[0];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping, isRecording, isProcessingAudio]);

  useEffect(() => {
    inputRef.current?.focus();

    // Se iniciado em modo de voz com auto-reprodução e há apenas a mensagem inicial do cliente, falar
    if (mode === 'voice' && autoPlayAudio && messages.length === 1 && messages[0].sender === 'customer') {
      handleSpeakMessage(messages[0].text);
    }

    return () => {
      voiceService.stopSpeaking();
      if (stopListeningRef.current) {
        stopListeningRef.current();
      }
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
      if (currentAudioElementRef.current) {
        currentAudioElementRef.current.pause();
      }
    };
  }, []);

  // Falar texto em voz alta via sintetizador do cliente
  const handleSpeakMessage = (text: string) => {
    setIsSpeaking(true);
    voiceService.speak(text, {
      profile: config.customerProfile,
      onStart: () => setIsSpeaking(true),
      onEnd: () => setIsSpeaking(false),
      onError: () => setIsSpeaking(false),
    });
  };

  const handleStopSpeaking = () => {
    voiceService.stopSpeaking();
    setIsSpeaking(false);
  };

  // Reproduzir áudio gravado pelo usuário
  const handlePlayUserAudio = (msgId: string, audioUrl?: string) => {
    if (!audioUrl) return;

    if (playingAudioId === msgId && currentAudioElementRef.current) {
      currentAudioElementRef.current.pause();
      setPlayingAudioId(null);
      return;
    }

    if (currentAudioElementRef.current) {
      currentAudioElementRef.current.pause();
    }

    const audio = new Audio(audioUrl);
    currentAudioElementRef.current = audio;
    setPlayingAudioId(msgId);

    audio.onended = () => {
      setPlayingAudioId(null);
    };

    audio.onerror = () => {
      setPlayingAudioId(null);
    };

    audio.play();
  };

  // Solicitar permissão explicitamente pelo clique do usuário
  const handleRequestMicrophonePrompt = async () => {
    setShowPermissionModal(false);
    const result = await voiceService.requestMicrophonePermission();
    if (result.granted) {
      setErrorMessage(null);
      handleStartRecording();
    } else {
      setErrorMessage(result.error || 'Permissão do microfone negada pelo navegador.');
    }
  };

  // Formatar segundos no estilo WhatsApp (ex: 0:07)
  const formatDuration = (totalSeconds: number) => {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  // Iniciar gravação de voz pelo microfone
  const handleStartRecording = async () => {
    if (isRecording) {
      handleStopRecording();
      return;
    }

    handleStopSpeaking();
    setErrorMessage(null);
    setIsRecording(true);
    setRecordingSeconds(0);

    if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    recordingTimerRef.current = setInterval(() => {
      setRecordingSeconds((prev) => prev + 1);
    }, 1000);

    const stopFn = await voiceService.startRecording({
      onInterimTranscript: (text) => {
        // feedback visual discreto
      },
      onFinalAudioRecorded: async (audioBlob, textFallback, durationSec) => {
        setIsRecording(false);
        if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);

        const durationFormatted = formatDuration(durationSec);
        let audioBlobUrl: string | undefined;
        try {
          audioBlobUrl = URL.createObjectURL(audioBlob);
        } catch {}

        let speechText = (textFallback || '').trim();

        // Se o navegador não transcreveu pelo SpeechRecognition, transcreve o áudio gravado via Gemini
        if (!speechText && audioBlob.size > 0) {
          setIsProcessingAudio(true);
          try {
            speechText = await trainingClientService.transcribeAudio(audioBlob);
          } catch (err) {
            console.warn('[handleStartRecording] Erro ao transcrever áudio gravado:', err);
          } finally {
            setIsProcessingAudio(false);
          }
        }

        if (speechText) {
          handleSendAudioMessage(speechText, durationFormatted, audioBlobUrl);
        } else {
          setErrorMessage('Não foi possível identificar a voz com clareza. Fale mais próximo do microfone ou envie por texto.');
        }
      },
      onError: (err) => {
        setIsRecording(false);
        setIsProcessingAudio(false);
        if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
        if (err.includes('Permissão') || err.includes('bloqueada') || err.includes('cadeado')) {
          setShowPermissionModal(true);
        } else {
          setErrorMessage(err);
        }
      },
      onEnd: () => {
        setIsRecording(false);
        if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      },
    });

    stopListeningRef.current = stopFn;
  };

  // Parar gravação e processar áudio
  const handleStopRecording = () => {
    if (stopListeningRef.current) {
      stopListeningRef.current();
      stopListeningRef.current = null;
    }
    setIsRecording(false);
    if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
  };

  // Cancelar gravação atual sem enviar
  const handleCancelRecording = () => {
    voiceService.stopRecording();
    if (stopListeningRef.current) {
      stopListeningRef.current();
      stopListeningRef.current = null;
    }
    setIsRecording(false);
    setIsProcessingAudio(false);
    if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    setRecordingSeconds(0);
    setInputValue('');
  };

  // Enviar Mensagem de Áudio gravada com balão WhatsApp
  const handleSendAudioMessage = async (transcriptText: string, durationFormatted: string, audioBlobUrl?: string) => {
    handleStopSpeaking();
    setErrorMessage(null);

    const userMessage: ChatMessage = {
      id: 'msg-' + Date.now(),
      sender: 'user',
      text: transcriptText,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      audioVoiceType: 'spoken',
      audioDuration: durationFormatted,
      audioUrl: audioBlobUrl,
      transcript: transcriptText,
    };

    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setIsTyping(true);

    onAutoSave?.(nextMessages);

    const customerMsgId = 'msg-cust-' + (Date.now() + 1);
    setStreamingMessageId(customerMsgId);

    try {
      let createdCustomerBubble = false;

      const finalReply = await trainingClientService.sendCustomerReplyWithStream(
        config,
        nextMessages,
        modality.title,
        (_chunk, accumulated) => {
          if (!createdCustomerBubble) {
            createdCustomerBubble = true;
            setIsTyping(false);
            setMessages((prev) => [
              ...prev,
              {
                id: customerMsgId,
                sender: 'customer',
                text: accumulated,
                timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
              },
            ]);
          } else {
            setMessages((prev) =>
              prev.map((m) => (m.id === customerMsgId ? { ...m, text: accumulated } : m))
            );
          }
        }
      );

      const finalMessagesList = (() => {
        const exists = nextMessages.some((m) => m.id === customerMsgId);
        if (exists) {
          return nextMessages.map((m) => (m.id === customerMsgId ? { ...m, text: finalReply } : m));
        }
        return [
          ...nextMessages,
          {
            id: customerMsgId,
            sender: 'customer' as const,
            text: finalReply,
            timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          },
        ];
      })();

      setMessages(finalMessagesList);
      onAutoSave?.(finalMessagesList);

      if (autoPlayAudio) {
        handleSpeakMessage(finalReply);
      }
    } catch (err: any) {
      console.error('Erro na resposta do cliente:', err);
      setErrorMessage('O cliente demorou a responder. Clique no botão abaixo para tentar novamente.');
    } finally {
      setIsTyping(false);
      setStreamingMessageId(null);
    }
  };

  // Enviar mensagem de texto normal
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const text = inputValue.trim();
    if (!text || isTyping || isFinishing) return;

    handleStopSpeaking();
    setInputValue('');
    setErrorMessage(null);

    const userMessage: ChatMessage = {
      id: 'msg-' + Date.now(),
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    };

    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setIsTyping(true);

    onAutoSave?.(nextMessages);

    const customerMsgId = 'msg-cust-' + (Date.now() + 1);
    setStreamingMessageId(customerMsgId);

    try {
      let createdCustomerBubble = false;

      const finalReply = await trainingClientService.sendCustomerReplyWithStream(
        config,
        nextMessages,
        modality.title,
        (_chunk, accumulated) => {
          if (!createdCustomerBubble) {
            createdCustomerBubble = true;
            setIsTyping(false);
            setMessages((prev) => [
              ...prev,
              {
                id: customerMsgId,
                sender: 'customer',
                text: accumulated,
                timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
              },
            ]);
          } else {
            setMessages((prev) =>
              prev.map((m) => (m.id === customerMsgId ? { ...m, text: accumulated } : m))
            );
          }
        }
      );

      const finalMessagesList = (() => {
        const exists = nextMessages.some((m) => m.id === customerMsgId);
        if (exists) {
          return nextMessages.map((m) => (m.id === customerMsgId ? { ...m, text: finalReply } : m));
        }
        return [
          ...nextMessages,
          {
            id: customerMsgId,
            sender: 'customer' as const,
            text: finalReply,
            timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          },
        ];
      })();

      setMessages(finalMessagesList);
      onAutoSave?.(finalMessagesList);

      if (autoPlayAudio) {
        handleSpeakMessage(finalReply);
      }
    } catch (err: any) {
      console.error('Erro na resposta do cliente:', err);
      setErrorMessage('O cliente demorou a responder. Clique no botão abaixo para tentar novamente.');
    } finally {
      setIsTyping(false);
      setStreamingMessageId(null);
    }
  };

  const handleRetryLastMessage = async () => {
    setErrorMessage(null);
    setIsTyping(true);

    const lastUserMessage = [...messages].reverse().find((m) => m.sender === 'user');
    if (!lastUserMessage) {
      setIsTyping(false);
      return;
    }

    const customerMsgId = 'msg-cust-retry-' + Date.now();
    try {
      const finalReply = await trainingClientService.sendCustomerReply(config, messages, modality.title);
      const updatedMessages: ChatMessage[] = [
        ...messages,
        {
          id: customerMsgId,
          sender: 'customer',
          text: finalReply,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        },
      ];
      setMessages(updatedMessages);
      onAutoSave?.(updatedMessages);

      if (autoPlayAudio) {
        handleSpeakMessage(finalReply);
      }
    } catch {
      setErrorMessage('Falha temporária ao conectar com a IA. Tente mais uma vez.');
    } finally {
      setIsTyping(false);
    }
  };

  const handleRequestHint = async () => {
    if (loadingHint) return;
    setLoadingHint(true);
    setErrorMessage(null);
    try {
      const advice = await trainingClientService.getHint(config, messages, modality.title);
      setHint(advice);
    } catch {
      setHint('Foque em descobrir o que é mais importante para o cliente antes de rebater.');
    } finally {
      setLoadingHint(false);
    }
  };

  const handleFinishTraining = () => {
    handleStopSpeaking();
    const userCount = messages.filter((m) => m.sender === 'user').length;
    if (userCount === 0) {
      setErrorMessage('Envie ao menos um áudio ou mensagem para o cliente antes de concluir o treino.');
      return;
    }
    setIsFinishing(true);
    onFinish(messages);
  };

  const handlePauseTraining = () => {
    handleStopSpeaking();
    handleCancelRecording();
    onPause(messages);
  };

  const toggleTranscript = (msgId: string) => {
    setExpandedTranscripts((prev) => ({
      ...prev,
      [msgId]: !prev[msgId],
    }));
  };

  return (
    <div className="max-w-4xl mx-auto flex flex-col h-[85vh] bg-[#ECE5DD] dark:bg-[#0B141A] border border-[#D1D7DB] dark:border-[#222E35] rounded-2xl overflow-hidden shadow-2xl relative animate-in fade-in duration-200">
      {/* Modal explicativo de permissão do microfone */}
      {showPermissionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#111B21] border border-[#222E35] p-6 rounded-2xl max-w-md w-full space-y-4 shadow-2xl text-white">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-[#25D366] border border-emerald-500/30 flex items-center justify-center mx-auto">
              <Mic className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="text-base font-bold">Permitir Microfone no WhatsApp</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Para enviar mensagens de áudio na simulação, autorize o microfone no navegador.
              </p>
            </div>
            <div className="bg-[#202C33] p-3 rounded-xl border border-[#2A3942] text-[11px] text-slate-300 space-y-1">
              <span className="font-semibold text-emerald-400 block">💡 Como permitir:</span>
              <p>1. Clique em <strong>Pedir Permissão Agora</strong> abaixo.</p>
              <p>2. Na caixa de diálogo do navegador, clique em <strong>Permitir</strong>.</p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={handleRequestMicrophonePrompt}
                className="flex-1 py-2.5 px-4 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0B141A] font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-[#25D366]/20 cursor-pointer"
              >
                <Mic className="w-4 h-4" />
                <span>Pedir Permissão Agora</span>
              </button>
              <button
                type="button"
                onClick={() => setShowPermissionModal(false)}
                className="py-2.5 px-3 rounded-xl bg-[#202C33] hover:bg-[#2A3942] text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Digitar Texto
              </button>
            </div>
          </div>
        </div>
      )}

      {/* WhatsApp Native Styled Header */}
      <div className="bg-[#008069] dark:bg-[#202C33] px-4 py-3 flex items-center justify-between text-white z-10 shrink-0 shadow-md">
        <div className="flex items-center gap-3 min-w-0">
          {/* Avatar com status online */}
          <div className="relative shrink-0">
            <div className="w-10 h-10 rounded-full bg-[#E9EDEF] dark:bg-[#111B21] flex items-center justify-center text-slate-700 dark:text-slate-300 font-bold text-sm shadow-inner">
              <User className="w-5 h-5 text-slate-500 dark:text-slate-400" />
            </div>
            <span className="w-2.5 h-2.5 rounded-full bg-[#25D366] ring-2 ring-[#008069] dark:ring-[#202C33] absolute bottom-0 right-0 animate-pulse" />
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white truncate">
                Cliente Simulado
              </h3>
              <span className="text-[10px] px-2 py-0.2 rounded-full bg-white/20 dark:bg-emerald-950/60 text-white dark:text-[#25D366] font-medium border border-white/20 dark:border-emerald-500/30 shrink-0">
                {config.customerProfile}
              </span>
            </div>
            <p className="text-[11px] text-emerald-100 dark:text-[#8696A0] flex items-center gap-1.5 truncate">
              {isSpeaking ? (
                <span className="text-amber-200 dark:text-[#25D366] flex items-center gap-1 font-semibold">
                  <Volume2 className="w-3 h-3 animate-pulse" />
                  <span>Falando áudio...</span>
                </span>
              ) : isTyping ? (
                <span className="text-emerald-100 dark:text-[#25D366] font-semibold animate-pulse">digitando...</span>
              ) : (
                <span>online • {modality.shortTitle}</span>
              )}
            </p>
          </div>
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Pausar Treinamento */}
          <button
            type="button"
            onClick={handlePauseTraining}
            className="px-2.5 py-1.5 rounded-xl bg-black/15 hover:bg-black/25 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-white/10"
            title="Pausar o treino e salvar para continuar depois"
          >
            <PauseCircle className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden sm:inline">Pausar</span>
          </button>

          {/* Dica do Mentor */}
          <button
            type="button"
            onClick={handleRequestHint}
            disabled={loadingHint || isTyping}
            className="px-2.5 py-1.5 rounded-xl bg-amber-400 text-[#0B141A] text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            title="Dica estratégica de vendas"
          >
            <Lightbulb className={`w-3.5 h-3.5 ${loadingHint ? 'animate-spin' : ''}`} />
            <span className="hidden md:inline">{loadingHint ? 'Pensando...' : 'Dica'}</span>
          </button>

          {/* Encerrar e Avaliar */}
          <button
            type="button"
            onClick={handleFinishTraining}
            disabled={isFinishing}
            className="px-3 py-1.5 rounded-xl bg-white text-[#008069] dark:bg-[#25D366] dark:text-[#0B141A] text-xs font-bold flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
            title="Concluir e gerar relatório de avaliação"
          >
            {isFinishing ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span className="hidden sm:inline">Avaliando...</span>
              </>
            ) : (
              <>
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Concluir</span>
              </>
            )}
          </button>

          {/* Sair */}
          <button
            type="button"
            onClick={onCancel}
            title="Sair (salvo automaticamente)"
            className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-black/10 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Floating Hint Box */}
      {hint && (
        <div className="bg-amber-100 dark:bg-[#1E2328] border-b border-amber-300 dark:border-amber-500/30 px-4 py-2 flex items-center justify-between text-xs text-amber-900 dark:text-amber-200 animate-in slide-in-from-top-2 duration-200 z-10 shrink-0">
          <div className="flex items-center gap-2 pr-4">
            <Lightbulb className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
            <span><strong>Dica do Mentor:</strong> {hint}</span>
          </div>
          <button
            onClick={() => setHint(null)}
            className="text-amber-800 dark:text-amber-400 hover:opacity-75 p-1 rounded cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Context Sub-bar */}
      <div className="bg-[#F0F2F5] dark:bg-[#182229] px-4 py-1.5 border-b border-[#D1D7DB] dark:border-[#222E35] flex items-center justify-between text-[11px] text-[#54656F] dark:text-[#8696A0] shrink-0">
        <span className="truncate">
          Vendendo: <strong>{config.productOrService}</strong> {config.specificItem ? `(${config.specificItem})` : ''}
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setAutoPlayAudio(!autoPlayAudio)}
            className="text-[10px] text-[#54656F] dark:text-[#8696A0] hover:text-[#111B21] dark:hover:text-white flex items-center gap-1 cursor-pointer"
            title="Ativar ou desativar áudio falado do cliente"
          >
            {autoPlayAudio ? <Volume2 className="w-3 h-3 text-[#008069] dark:text-[#25D366]" /> : <VolumeX className="w-3 h-3 text-slate-400" />}
            <span>Áudio da IA {autoPlayAudio ? 'ligado' : 'mudo'}</span>
          </button>
          <span className="text-[10px] font-mono opacity-75">
            {config.difficulty.toUpperCase()}
          </span>
        </div>
      </div>

      {/* Chat Messages Body com WhatsApp Wallpaper Dotted Texture */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-3 bg-[#EFEAE2] dark:bg-[#0B141A] relative">
        {/* Textura sutil do WhatsApp */}
        <div className="absolute inset-0 bg-[radial-gradient(#CBD5E1_1px,transparent_1px)] dark:bg-[radial-gradient(#182229_1px,transparent_1px)] [background-size:20px_20px] opacity-40 pointer-events-none" />

        {/* Pill de Criptografia / Simulação */}
        <div className="text-center my-1 select-none">
          <span className="inline-flex items-center gap-1.5 bg-[#FFEECD] dark:bg-[#182229] text-[#54656F] dark:text-[#FFD279] text-[10px] px-3 py-1 rounded-lg shadow-2xs border border-[#E9EDEF] dark:border-[#222E35]">
            <Lock className="w-3 h-3 text-[#F59E0B]" />
            <span>Simulação comercial interativa • Envie áudio ou texto</span>
          </span>
        </div>

        {/* Message Bubbles */}
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          const isAudio = msg.audioVoiceType === 'spoken';
          const isExpanded = expandedTranscripts[msg.id];

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} relative z-1`}
            >
              <div
                className={`max-w-[88%] sm:max-w-[72%] rounded-xl px-3.5 py-2 text-xs sm:text-sm shadow-sm leading-relaxed ${
                  isUser
                    ? 'bg-[#D9FDD3] dark:bg-[#005C4B] text-[#111B21] dark:text-[#E9EDEF] rounded-tr-xs'
                    : 'bg-[#FFFFFF] dark:bg-[#202C33] text-[#111B21] dark:text-[#E9EDEF] rounded-tl-xs'
                }`}
              >
                {/* Se for áudio enviado pelo usuário: Renderiza Balão de Mensagem de Voz do WhatsApp */}
                {isUser && isAudio ? (
                  <div className="space-y-2 min-w-[210px] sm:min-w-[240px]">
                    <div className="flex items-center gap-3 pt-1">
                      {/* Botão Play / Pause do Áudio */}
                      <button
                        type="button"
                        onClick={() => handlePlayUserAudio(msg.id, msg.audioUrl)}
                        className="w-9 h-9 rounded-full bg-[#008069] dark:bg-[#25D366] text-white dark:text-[#0B141A] flex items-center justify-center shadow-sm hover:scale-105 transition-transform cursor-pointer shrink-0"
                        title={playingAudioId === msg.id ? 'Pausar áudio' : 'Ouvir áudio gravado'}
                      >
                        {playingAudioId === msg.id ? (
                          <Pause className="w-4 h-4 fill-current" />
                        ) : (
                          <Play className="w-4 h-4 fill-current ml-0.5" />
                        )}
                      </button>

                      {/* Onda Sonora Fictícia do WhatsApp */}
                      <div className="flex-1 flex items-center gap-0.5 h-6">
                        {[40, 70, 30, 90, 50, 80, 60, 100, 45, 65, 85, 30, 75, 55, 95, 60, 40].map((h, i) => (
                          <span
                            key={i}
                            className={`w-1 rounded-full transition-all ${
                              playingAudioId === msg.id
                                ? 'bg-[#008069] dark:bg-[#25D366] animate-pulse'
                                : 'bg-[#8696A0] dark:bg-[#8696A0]'
                            }`}
                            style={{ height: `${h}%` }}
                          />
                        ))}
                      </div>

                      {/* Ícone de Microfone e Duração */}
                      <div className="flex flex-col items-end text-[10px] font-mono text-[#667781] dark:text-[#8696A0] shrink-0">
                        <Mic className="w-3 h-3 text-[#008069] dark:text-[#25D366]" />
                        <span>{msg.audioDuration || '0:05'}</span>
                      </div>
                    </div>

                    {/* Botão Discreto: Ver transcrição */}
                    <div className="border-t border-black/5 dark:border-white/5 pt-1.5">
                      <button
                        type="button"
                        onClick={() => toggleTranscript(msg.id)}
                        className="text-[11px] text-[#008069] dark:text-[#25D366] font-semibold flex items-center gap-1 hover:underline cursor-pointer"
                      >
                        <span>{isExpanded ? 'Ocultar transcrição' : 'Ver transcrição do áudio'}</span>
                        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </button>

                      {isExpanded && (
                        <p className="mt-1.5 text-xs text-[#3B4A54] dark:text-slate-300 bg-black/5 dark:bg-black/20 p-2 rounded-lg italic border border-black/5 dark:border-white/5 leading-relaxed">
                          "{msg.transcript || msg.text}"
                        </p>
                      )}
                    </div>
                  </div>
                ) : (
                  /* Mensagem de Texto Normal */
                  <div className="whitespace-pre-wrap break-words">{msg.text}</div>
                )}

                {/* Rodapé da Mensagem (Horário + Ouvir para a IA + Ticks) */}
                <div
                  className={`flex items-center justify-between gap-2 text-[9px] mt-1 select-none pt-0.5 border-t border-black/5 dark:border-white/5 ${
                    isUser
                      ? 'text-[#667781] dark:text-[#8696A0]'
                      : 'text-[#667781] dark:text-[#8696A0]'
                  }`}
                >
                  {!isUser ? (
                    <button
                      type="button"
                      onClick={() => handleSpeakMessage(msg.text)}
                      className="text-[#008069] dark:text-[#25D366] hover:opacity-80 flex items-center gap-1 font-semibold cursor-pointer"
                      title="Ouvir resposta falada"
                    >
                      <Volume2 className="w-3 h-3" />
                      <span>Ouvir</span>
                    </button>
                  ) : (
                    <span className="text-[10px]">
                      {isAudio ? 'Áudio enviado' : ''}
                    </span>
                  )}

                  <div className="flex items-center gap-1">
                    <span>{msg.timestamp}</span>
                    {isUser && <CheckCheck className="w-3.5 h-3.5 text-[#53BDEB]" />}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {/* Indicador de Digitação da IA */}
        {isTyping && !streamingMessageId && (
          <div className="flex items-center gap-2 text-xs text-[#54656F] dark:text-[#8696A0] bg-white dark:bg-[#202C33] w-fit px-3 py-2 rounded-xl rounded-tl-xs shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-[#008069] dark:bg-[#25D366] animate-pulse" />
            <span>Cliente digitando resposta...</span>
          </div>
        )}

        {/* Indicador: Ouvindo seu áudio... (Transcrevendo com IA) */}
        {isProcessingAudio && (
          <div className="flex items-center gap-2 text-xs text-[#008069] dark:text-[#25D366] bg-emerald-50 dark:bg-[#111B21] border border-emerald-200 dark:border-emerald-500/30 w-fit ml-auto px-3.5 py-2 rounded-xl shadow-xs animate-pulse">
            <Loader2 className="w-4 h-4 animate-spin text-[#008069] dark:text-[#25D366]" />
            <span>Ouvindo seu áudio e interpretando mensagem...</span>
          </div>
        )}

        {/* Mensagem de Erro com Botão de Tentar Novamente */}
        {errorMessage && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-500/30 text-rose-800 dark:text-rose-300 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 shadow-xs">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 dark:text-rose-400" />
              <span>{errorMessage}</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowPermissionModal(true)}
                className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[11px] font-bold shrink-0 hover:bg-emerald-700 transition-colors cursor-pointer"
              >
                Permitir Microfone
              </button>
              <button
                onClick={handleRetryLastMessage}
                className="px-2.5 py-1 rounded-lg bg-rose-200 dark:bg-rose-900/40 text-rose-800 dark:text-rose-200 text-[11px] font-bold shrink-0 hover:opacity-80 transition-opacity cursor-pointer"
              >
                Tentar Novamente
              </button>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Barra de Gravação Ativa no Estilo WhatsApp */}
      {isRecording ? (
        <div className="bg-[#F0F2F5] dark:bg-[#202C33] p-3 border-t border-[#D1D7DB] dark:border-[#222E35] flex items-center justify-between gap-3 z-10 shrink-0 animate-in slide-in-from-bottom-2 duration-150">
          {/* Indicador Vermelho Piscando + Timer */}
          <div className="flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-rose-500 animate-ping shrink-0" />
            <div className="flex items-center gap-1.5 font-mono text-sm font-bold text-rose-600 dark:text-rose-400">
              <Mic className="w-4 h-4 animate-bounce" />
              <span>{formatDuration(recordingSeconds)}</span>
            </div>
            <span className="text-xs text-[#54656F] dark:text-[#8696A0] hidden sm:inline">
              Gravando mensagem de voz...
            </span>
          </div>

          {/* Ações de Cancelar / Enviar Áudio */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleCancelRecording}
              className="flex items-center gap-1 text-xs text-rose-600 dark:text-rose-400 hover:underline font-bold px-2 py-1.5 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>Cancelar</span>
            </button>

            <button
              type="button"
              onClick={handleStopRecording}
              className="px-4 py-2 rounded-full bg-[#008069] dark:bg-[#25D366] hover:bg-[#00705c] dark:hover:bg-[#20bd5a] text-white dark:text-[#0B141A] font-bold text-xs flex items-center gap-1.5 shadow-md hover:scale-105 transition-all cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Enviar Áudio</span>
            </button>
          </div>
        </div>
      ) : (
        /* Barra de Entrada Padrão (Texto + Botão de Microfone) */
        <form
          onSubmit={handleSendMessage}
          className="bg-[#F0F2F5] dark:bg-[#202C33] p-2.5 sm:p-3 border-t border-[#D1D7DB] dark:border-[#222E35] flex items-center gap-2 z-10 shrink-0"
        >
          {/* Campo de Texto para digitar */}
          <div className="flex-1 relative">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={
                isProcessingAudio
                  ? 'Transcrevendo áudio...'
                  : isTyping
                  ? 'Aguarde o cliente responder...'
                  : 'Mensagem (digite ou toque no microfone para falar)...'
              }
              disabled={isTyping || isFinishing || isProcessingAudio}
              className="w-full bg-white dark:bg-[#2A3942] border border-transparent dark:border-transparent rounded-full px-4 py-2.5 text-xs sm:text-sm text-[#111B21] dark:text-[#E9EDEF] placeholder-[#8696A0] focus:outline-none focus:ring-1 focus:ring-[#008069] dark:focus:ring-[#25D366] shadow-2xs"
            />
          </div>

          {/* Botão de Envio: Se houver texto, mostra botão de enviar texto; Senão, botão de microfone verde */}
          {inputValue.trim().length > 0 ? (
            <button
              type="submit"
              disabled={isTyping || isFinishing || isProcessingAudio}
              className="w-10 h-10 rounded-full bg-[#008069] dark:bg-[#25D366] hover:bg-[#00705c] dark:hover:bg-[#20bd5a] text-white dark:text-[#0B141A] flex items-center justify-center transition-all shadow-md cursor-pointer shrink-0"
              title="Enviar mensagem de texto"
            >
              <Send className="w-4 h-4 ml-0.5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleStartRecording}
              disabled={isTyping || isFinishing || isProcessingAudio}
              className="w-10 h-10 rounded-full bg-[#008069] dark:bg-[#25D366] hover:bg-[#00705c] dark:hover:bg-[#20bd5a] text-white dark:text-[#0B141A] flex items-center justify-center transition-all shadow-md hover:scale-105 cursor-pointer shrink-0"
              title="Gravar mensagem de áudio"
            >
              <Mic className="w-5 h-5" />
            </button>
          )}
        </form>
      )}
    </div>
  );
};
