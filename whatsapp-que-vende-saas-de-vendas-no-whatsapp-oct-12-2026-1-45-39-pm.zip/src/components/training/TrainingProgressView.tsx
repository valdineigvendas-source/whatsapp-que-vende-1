import React, { useState, useEffect } from 'react';
import { TrainingSession } from '../../types';
import { trainingStorageService } from '../../services/trainingStorageService';
import {
  Trophy,
  Play,
  RotateCcw,
  Trash2,
  Clock,
  MessageSquare,
  CheckCircle2,
  AlertTriangle,
  History,
  Target,
} from 'lucide-react';

interface TrainingProgressViewProps {
  userId: string;
  onResumeSession?: (session: TrainingSession) => void;
  onSelectModality: (modalityId: any) => void;
  onBackToHub: () => void;
}

export const TrainingProgressView: React.FC<TrainingProgressViewProps> = ({
  userId,
  onResumeSession,
  onSelectModality,
  onBackToHub,
}) => {
  const [sessions, setSessions] = useState<TrainingSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | 'ongoing' | 'completed'>('all');

  const loadSessions = async () => {
    setLoading(true);
    const data = await trainingStorageService.getUserTrainings(userId);
    setSessions(data);
    setLoading(false);
  };

  useEffect(() => {
    loadSessions();
  }, [userId]);

  const ongoingSessions = sessions.filter((s) => s.status === 'active' || s.status === 'paused');
  const completedSessions = sessions.filter((s) => s.status === 'completed' && s.evaluation);

  const totalTrainings = completedSessions.length;
  const averageScore = totalTrainings > 0
    ? Math.round(
        completedSessions.reduce((acc, curr) => acc + (curr.evaluation?.overallScore || 0), 0) /
          totalTrainings
      )
    : 0;

  const handleDeleteSession = async (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Tem certeza que deseja excluir esta sessão de treino?')) {
      await trainingStorageService.deleteTrainingSession(userId, sessionId);
      setSessions((prev) => prev.filter((s) => s.id !== sessionId));
    }
  };

  const displayedSessions =
    activeTab === 'ongoing'
      ? ongoingSessions
      : activeTab === 'completed'
      ? completedSessions
      : sessions;

  return (
    <div className="space-y-6 animate-in fade-in duration-300 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold text-[#25D366] uppercase tracking-wider mb-1">
            <Trophy className="w-4 h-4" />
            <span>📚 Seus Treinamentos & Progresso</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Evolução e Sessões em Andamento
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Retome sessões pausadas de onde parou ou consulte suas avaliações concluídas.
          </p>
        </div>

        <button
          onClick={onBackToHub}
          className="px-4 py-2 rounded-xl bg-[#16222C] hover:bg-[#1E2E3C] text-slate-200 hover:text-white border border-[#253543] text-xs font-semibold self-start sm:self-auto transition-colors cursor-pointer"
        >
          ← Voltar para modalidades
        </button>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-[#0E151B] border border-[#1E2B35] space-y-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
            Treinos em Andamento / Pausados
          </span>
          <div className="text-3xl font-black text-amber-400">{ongoingSessions.length}</div>
          <p className="text-[11px] text-slate-500">Prontos para você continuar quando quiser</p>
        </div>

        <div className="p-5 rounded-2xl bg-[#0E151B] border border-[#1E2B35] space-y-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
            Treinos Concluídos & Avaliados
          </span>
          <div className="text-3xl font-black text-white">{totalTrainings}</div>
          <p className="text-[11px] text-slate-500">Práticas finalizadas com notas e feedback</p>
        </div>

        <div className="p-5 rounded-2xl bg-[#0E151B] border border-[#1E2B35] space-y-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
            Média Geral de Desempenho
          </span>
          <div className="text-3xl font-black text-[#25D366]">
            {averageScore > 0 ? `${averageScore} pts` : '—'}
          </div>
          <p className="text-[11px] text-slate-500">De 0 a 100 avaliado pela IA nas sessões</p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-[#1E2B35] pb-2">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
            activeTab === 'all'
              ? 'bg-[#15251C] text-[#25D366] border border-[#25D366]/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Todas as sessões ({sessions.length})
        </button>
        <button
          onClick={() => setActiveTab('ongoing')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
            activeTab === 'ongoing'
              ? 'bg-[#15251C] text-[#25D366] border border-[#25D366]/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Continuar Treinando ({ongoingSessions.length})
        </button>
        <button
          onClick={() => setActiveTab('completed')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
            activeTab === 'completed'
              ? 'bg-[#15251C] text-[#25D366] border border-[#25D366]/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Concluídos ({completedSessions.length})
        </button>
      </div>

      {/* List of Sessions */}
      <div className="bg-[#0E151B] border border-[#1E2B35] p-5 sm:p-6 rounded-2xl space-y-4">
        {loading ? (
          <div className="py-8 text-center text-xs text-slate-500">
            Carregando sessões do Firestore...
          </div>
        ) : displayedSessions.length === 0 ? (
          <div className="py-12 text-center space-y-3">
            <Target className="w-10 h-10 text-slate-600 mx-auto" />
            <p className="text-sm text-slate-400">Nenhuma sessão encontrada nesta categoria.</p>
            <button
              onClick={onBackToHub}
              className="px-4 py-2 rounded-xl bg-[#25D366] text-[#0A1014] font-bold text-xs cursor-pointer"
            >
              Iniciar Novo Treinamento
            </button>
          </div>
        ) : (
          <div className="divide-y divide-[#1A252E]">
            {displayedSessions.map((sess) => {
              const isOngoing = sess.status === 'active' || sess.status === 'paused';
              return (
                <div
                  key={sess.id}
                  className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-white">{sess.modalityTitle}</span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                          isOngoing
                            ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                            : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        }`}
                      >
                        {isOngoing ? 'Pausado / Em Andamento' : 'Concluído'}
                      </span>
                      <span className="text-[10px] px-2 py-0.2 rounded-md bg-[#16222C] text-slate-400 border border-[#233543]">
                        {sess.config.customerProfile}
                      </span>
                      <span className="text-[10px] px-2 py-0.2 rounded-md bg-[#16222C] text-slate-400 border border-[#233543]">
                        {sess.config.interactionMode === 'voice' ? '🎙️ Voz' : '⌨️ Texto'}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-400 flex items-center gap-2 pt-0.5">
                      <span>{sess.config.productOrService}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <MessageSquare className="w-3 h-3 text-slate-500" />
                        {sess.messages?.length || 0} mensagens
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-500" />
                        {sess.updatedAt ? new Date(sess.updatedAt).toLocaleDateString('pt-BR') : new Date(sess.createdAt).toLocaleDateString('pt-BR')}
                      </span>
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    {/* Botão de Retomar ou Pontuação */}
                    {isOngoing ? (
                      <button
                        onClick={() => onResumeSession?.(sess)}
                        className="px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-[#25D366]/20 cursor-pointer"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>▶️ Retomar Treinamento</span>
                      </button>
                    ) : (
                      <div className="text-right">
                        <span className="text-[11px] text-slate-400 block font-medium">Nota Geral</span>
                        <span className="text-base font-black text-[#25D366]">
                          {sess.evaluation?.overallScore}/100
                        </span>
                      </div>
                    )}

                    {/* Treinar novamente ou Excluir */}
                    {!isOngoing && (
                      <button
                        onClick={() => onSelectModality(sess.modalityId)}
                        className="p-2 rounded-lg bg-[#152028] hover:bg-[#1E2E3A] text-slate-300 hover:text-white transition-colors cursor-pointer"
                        title="Treinar essa habilidade novamente"
                      >
                        <RotateCcw className="w-4 h-4 text-[#25D366]" />
                      </button>
                    )}

                    <button
                      onClick={(e) => handleDeleteSession(sess.id, e)}
                      className="p-2 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                      title="Excluir histórico deste treino"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
