import React from 'react';
import { TrainingEvaluation, TrainingModalityId } from '../../types';
import {
  Trophy,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  Sparkles,
  ArrowRight,
  RotateCcw,
  History,
  Home,
  Target,
  Quote,
} from 'lucide-react';
import { TRAINING_MODALITIES } from '../../data/trainingData';

interface TrainingEvaluationViewProps {
  evaluation: TrainingEvaluation;
  onRetry: () => void;
  onSelectAnother: () => void;
  onSelectRecommended: (modalityId: TrainingModalityId) => void;
  onViewProgress: () => void;
  onGoHome: () => void;
}

export const TrainingEvaluationView: React.FC<TrainingEvaluationViewProps> = ({
  evaluation,
  onRetry,
  onSelectAnother,
  onSelectRecommended,
  onViewProgress,
  onGoHome,
}) => {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-[#25D366] border-[#25D366] bg-[#25D366]/10';
    if (score >= 60) return 'text-amber-400 border-amber-400 bg-amber-400/10';
    return 'text-rose-400 border-rose-400 bg-rose-400/10';
  };

  const getScoreBarBg = (score: number) => {
    if (score >= 80) return 'bg-[#25D366]';
    if (score >= 60) return 'bg-amber-400';
    return 'bg-rose-400';
  };

  const recommendedModality = TRAINING_MODALITIES.find(
    (m) => m.id === evaluation.recommendedChallengeId
  ) || TRAINING_MODALITIES[0];

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-[#111A22] via-[#0E151B] to-[#121E18] border border-[#233544] p-6 sm:p-8 rounded-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#25D366]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#25D366] uppercase tracking-wider mb-2">
              <Trophy className="w-4 h-4" />
              <span>Relatório de Desempenho do Treino</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              📊 Avaliação do seu treinamento
            </h1>
            <p className="mt-2 text-sm text-slate-300 max-w-xl leading-relaxed">
              {evaluation.scoreExplanation}
            </p>
          </div>

          {/* Overall Score Badge */}
          <div className="flex flex-col items-center justify-center shrink-0 w-32 h-32 rounded-2xl border-2 bg-[#0A1014]/80 backdrop-blur-md shadow-2xl p-4 text-center">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1">
              Pontuação Geral
            </span>
            <span className={`text-4xl font-black ${getScoreColor(evaluation.overallScore).split(' ')[0]}`}>
              {evaluation.overallScore}
            </span>
            <span className="text-[10px] text-slate-500 font-medium mt-0.5">de 100 pontos</span>
          </div>
        </div>
      </div>

      {/* Grid: O que fez bem vs O que pode melhorar */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* O que você fez bem */}
        <div className="bg-[#0F171E] border border-emerald-500/20 p-5 rounded-2xl space-y-3">
          <div className="flex items-center gap-2 text-emerald-400">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <h3 className="text-sm font-bold text-white">O que você fez bem</h3>
          </div>
          <ul className="space-y-2 pt-1">
            {evaluation.whatWentWell.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300 leading-relaxed">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* O que pode melhorar */}
        <div className="bg-[#0F171E] border border-amber-500/20 p-5 rounded-2xl space-y-3">
          <div className="flex items-center gap-2 text-amber-400">
            <AlertTriangle className="w-5 h-5 shrink-0" />
            <h3 className="text-sm font-bold text-white">O que pode melhorar</h3>
          </div>
          <ul className="space-y-2 pt-1">
            {evaluation.whatToImprove.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300 leading-relaxed">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Avaliação por Habilidade */}
      <div className="bg-[#0E151B] border border-[#1E2B35] p-6 rounded-2xl space-y-5">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#25D366]" />
            <span>Avaliação Detalhada por Habilidade</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Critérios específicos observados durante a sua condução no WhatsApp.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {evaluation.skillScores.map((skill, idx) => (
            <div key={idx} className="p-3.5 rounded-xl bg-[#131A21] border border-[#1E2933] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white">{skill.name}</span>
                <span className="text-xs font-bold text-slate-200">{skill.score}/100</span>
              </div>
              <div className="w-full bg-[#1F2C37] rounded-full h-1.5 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${getScoreBarBg(skill.score)}`}
                  style={{ width: `${skill.score}%` }}
                />
              </div>
              {skill.comment && (
                <p className="text-[11px] text-slate-400 leading-relaxed">{skill.comment}</p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Análise de Mensagens Concretas */}
      {evaluation.messageAnalysis && evaluation.messageAnalysis.length > 0 && (
        <div className="bg-[#0E151B] border border-[#1E2B35] p-6 rounded-2xl space-y-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Quote className="w-4 h-4 text-[#25D366]" />
              <span>Análise das Suas Mensagens na Prática</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Trechos reais enviados por você e o impacto que causaram no cliente.
            </p>
          </div>

          <div className="space-y-3">
            {evaluation.messageAnalysis.map((item, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-[#121920] border border-[#1F2B36] space-y-2.5">
                <div className="text-xs font-mono text-emerald-400 bg-emerald-950/40 p-2.5 rounded-lg border border-emerald-500/20">
                  "{item.userMessageSnippet}"
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs pt-1">
                  <div>
                    <span className="text-[11px] font-bold text-slate-400 block mb-0.5">O que funcionou:</span>
                    <span className="text-slate-300">{item.whatWorked}</span>
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-slate-400 block mb-0.5">O que poderia melhorar:</span>
                    <span className="text-slate-300">{item.whatCouldImprove}</span>
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-slate-400 block mb-0.5">Por que faz diferença:</span>
                    <span className="text-slate-300">{item.whyItMatters}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Exemplos Alternativos de Como Responder Melhor */}
      {evaluation.betterResponseExamples && evaluation.betterResponseExamples.length > 0 && (
        <div className="bg-[#0E151B] border border-[#1E2B35] p-6 rounded-2xl space-y-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-400" />
              <span>Como Responder Melhor (Modelos de Referência)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Exemplos prontos e didáticos para você aplicar em situações parecidas.
            </p>
          </div>

          <div className="space-y-3">
            {evaluation.betterResponseExamples.map((ex, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-[#121920] border border-[#1F2B36] space-y-2">
                <span className="text-xs font-semibold text-amber-400">{ex.context}</span>
                <div className="p-3 rounded-lg bg-[#0A1014] border border-[#233544] text-xs text-white leading-relaxed font-sans">
                  {ex.suggestedMessage}
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">{ex.explanation}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Próximo Desafio Recomendado */}
      <div className="bg-gradient-to-r from-emerald-950/40 to-[#121E18] border border-[#25D366]/30 p-5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#25D366]">
            <Target className="w-4 h-4" />
            <span>Próximo Treinamento Recomendado</span>
          </div>
          <h4 className="text-base font-bold text-white">
            {recommendedModality.emoji} {recommendedModality.title}
          </h4>
          <p className="text-xs text-slate-300 max-w-xl">
            {evaluation.recommendedChallengeReason || recommendedModality.description}
          </p>
        </div>

        <button
          onClick={() => onSelectRecommended(evaluation.recommendedChallengeId)}
          className="px-5 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shadow-md shadow-[#25D366]/20 shrink-0 cursor-pointer"
        >
          <span>Iniciar Este Treino</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Botões de Ação Final */}
      <div className="pt-4 border-t border-[#1E2B35] flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onRetry}
            className="px-4 py-2.5 rounded-xl bg-[#16222C] hover:bg-[#1E2E3C] text-white border border-[#263847] text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#25D366]" />
            <span>🔁 Tentar novamente</span>
          </button>

          <button
            onClick={onSelectAnother}
            className="px-4 py-2.5 rounded-xl bg-[#16222C] hover:bg-[#1E2E3C] text-white border border-[#263847] text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Target className="w-3.5 h-3.5 text-[#25D366]" />
            <span>🎯 Escolher outro treino</span>
          </button>

          <button
            onClick={onViewProgress}
            className="px-4 py-2.5 rounded-xl bg-[#16222C] hover:bg-[#1E2E3C] text-white border border-[#263847] text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
          >
            <History className="w-3.5 h-3.5 text-[#25D366]" />
            <span>📋 Ver minhas avaliações</span>
          </button>
        </div>

        <button
          onClick={onGoHome}
          className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Home className="w-3.5 h-3.5" />
          <span>🏠 Voltar ao início</span>
        </button>
      </div>
    </div>
  );
};
