import React, { useState } from 'react';
import { X, Sparkles, Check, ArrowRight, HelpCircle } from 'lucide-react';

interface CustomProfessionModalProps {
  initialData?: {
    name: string;
    productOrService: string;
    targetAudience: string;
    commonObjection?: string;
  };
  onSave: (customData: {
    name: string;
    productOrService: string;
    targetAudience: string;
    commonObjection?: string;
  }) => void;
  onClose: () => void;
}

export const CustomProfessionModal: React.FC<CustomProfessionModalProps> = ({
  initialData,
  onSave,
  onClose,
}) => {
  const [name, setName] = useState(initialData?.name || '');
  const [productOrService, setProductOrService] = useState(initialData?.productOrService || '');
  const [targetAudience, setTargetAudience] = useState(initialData?.targetAudience || '');
  const [commonObjection, setCommonObjection] = useState(
    initialData?.commonObjection || 'Cliente acha caro ou para de responder'
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onSave({
      name: name.trim(),
      productOrService: productOrService.trim() || 'Produtos e serviços especializados',
      targetAudience: targetAudience.trim() || 'Público geral e clientes interessados',
      commonObjection: commonObjection.trim() || 'Cliente acha caro ou para de responder',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#0D141A] border border-[#1E2C36] rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-2xl relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-44 h-44 bg-[#25D366]/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-[#1E2C36]">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#25D366] uppercase tracking-wider mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Personalização de Nicho</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-white">
              Minha profissão não está na lista
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Informe sua atividade para a IA adaptar todas as mensagens, simulações e treinos ao seu negócio real.
            </p>
          </div>

          <button
            onClick={onClose}
            type="button"
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800/60 transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Qual é o nome da sua profissão ou área? <span className="text-[#25D366]">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Arquiteta de Interiores, Tapeceiro, Energia Solar, Veterinário..."
              className="w-full bg-[#141E26] border border-[#253644] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              O que você vende no WhatsApp? (Produto ou Serviço) <span className="text-[#25D366]">*</span>
            </label>
            <input
              type="text"
              required
              value={productOrService}
              onChange={(e) => setProductOrService(e.target.value)}
              placeholder="Ex: Projetos executivos de reforma, Instalação de painéis solares..."
              className="w-full bg-[#141E26] border border-[#253644] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Quem é o seu público-alvo ou cliente ideal?
            </label>
            <input
              type="text"
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value)}
              placeholder="Ex: Casais comprando apartamento novo, Donos de sítios e residências..."
              className="w-full bg-[#141E26] border border-[#253644] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Qual é a maior objeção ou dúvida que seus clientes apresentam?
            </label>
            <input
              type="text"
              value={commonObjection}
              onChange={(e) => setCommonObjection(e.target.value)}
              placeholder="Ex: 'Achei o investimento muito alto', 'Vou pensar', 'É seguro?'..."
              className="w-full bg-[#141E26] border border-[#253644] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#25D366]/20 cursor-pointer"
            >
              <span>Salvar e Ativar Minha Profissão</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
