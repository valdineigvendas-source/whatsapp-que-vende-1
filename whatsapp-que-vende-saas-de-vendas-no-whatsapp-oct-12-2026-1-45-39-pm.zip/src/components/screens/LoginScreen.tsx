import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Mail,
  Lock,
  User,
  CheckCircle,
  ShieldCheck,
  ArrowRight,
  Loader2,
  KeyRound,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

export const LoginScreen: React.FC = () => {
  const {
    loginWithEmail,
    registerWithEmail,
    sendPasswordReset,
    resetPasswordWithToken,
    showToast,
  } = useApp();

  // Tabs: 'login' | 'register' | 'forgot' | 'reset'
  const [activeTab, setActiveTab] = useState<'login' | 'register' | 'forgot' | 'reset'>('login');

  // Form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Password Reset fields
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [resetSuccessMessage, setResetSuccessMessage] = useState('');

  // Status states
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resetSentMessage, setResetSentMessage] = useState('');

  // Detect #reset-password in URL hash or query params
  useEffect(() => {
    const handleUrlCheck = () => {
      const hash = window.location.hash || '';
      const search = window.location.search || '';
      const queryPart = hash.includes('?') ? hash.split('?')[1] : search.replace(/^\?/, '');
      const params = new URLSearchParams(queryPart);

      const token = params.get('token') || params.get('resetToken');
      const paramEmail = params.get('email');

      if (token && (hash.includes('reset-password') || params.has('token'))) {
        setActiveTab('reset');
        setResetToken(token);
        if (paramEmail) setEmail(paramEmail);
      }
    };

    handleUrlCheck();
    window.addEventListener('hashchange', handleUrlCheck);
    return () => window.removeEventListener('hashchange', handleUrlCheck);
  }, []);

  // Form submit handlers
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setError('Por favor, informe um e-mail válido.');
      return;
    }
    if (!password || password.length < 6) {
      setError('A senha deve possuir pelo menos 6 caracteres.');
      return;
    }

    setError('');
    setLoading(true);
    const result = await loginWithEmail(email, password);
    setLoading(false);

    if (!result.success) {
      setError(result.error || 'E-mail ou senha incorretos.');
      return;
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Por favor, informe seu nome completo.');
      return;
    }
    if (!email || !email.includes('@')) {
      setError('Por favor, informe um e-mail válido.');
      return;
    }
    if (!password || password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres.');
      return;
    }
    if (password !== confirmPassword) {
      setError('As senhas digitadas não coincidem.');
      return;
    }

    setError('');
    setLoading(true);
    const result = await registerWithEmail(email, password, name.trim());
    setLoading(false);

    if (!result.success) {
      setError(result.error || 'Erro ao criar conta.');
    }
  };

  const handleResetRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setError('Por favor, informe o seu e-mail cadastrado.');
      return;
    }

    setError('');
    setLoading(true);
    const result = await sendPasswordReset(email);
    setLoading(false);

    if (result.success) {
      setResetSentMessage(
        result.message ||
          'Enviamos um link seguro de recuperação para seu e-mail! Verifique sua Caixa de Entrada e a pasta de Spam.'
      );
      showToast('E-mail de recuperação enviado com sucesso!', 'success');
    } else {
      setError(result.error || 'Não foi possível enviar o e-mail de recuperação.');
    }
  };

  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      setError('A nova senha deve ter no mínimo 6 caracteres.');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setError('As senhas digitadas não coincidem.');
      return;
    }
    if (!resetToken) {
      setError('Token de recuperação ausente ou inválido. Solicite um novo link.');
      return;
    }

    setError('');
    setLoading(true);
    const result = await resetPasswordWithToken(email, resetToken, newPassword);
    setLoading(false);

    if (result.success) {
      setResetSuccessMessage(
        result.message || 'Senha redefinida com sucesso! Você já pode entrar com sua nova senha.'
      );
      showToast('Senha alterada com sucesso! 🎉', 'success');
      // Clean URL hash
      if (window.location.hash) {
        window.history.replaceState(null, '', window.location.pathname);
      }
    } else {
      setError(result.error || 'Erro ao redefinir senha.');
    }
  };

  return (
    <div className="min-h-screen bg-[#070B0E] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Subtle emerald ambient glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#25D366]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10">
        {/* Brand Logo & Name */}
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#25D366] text-[#0A1014] shadow-xl shadow-[#25D366]/20 mb-4 font-black text-2xl">
            W
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            WhatsApp <span className="text-[#25D366]">que Vende</span>
          </h1>
          <p className="mt-2 text-sm text-slate-400 max-w-sm mx-auto">
            Seu assistente para transformar conversas em clientes.
          </p>
        </div>

        {/* Card Container */}
        <div className="mt-8 bg-[#0D1419] border border-[#1F2C34] py-8 px-6 shadow-2xl rounded-2xl sm:px-10">
          
          {/* TAB 1: LOGIN */}
          {activeTab === 'login' && (
            <div>
              <div className="mb-6">
                <h2 className="text-lg font-bold text-white">Acesse sua conta</h2>
                <p className="text-xs text-slate-400 mt-0.5">Entre com seu e-mail e senha cadastrados.</p>
              </div>

              {error && (
                <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">E-mail</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu@email.com"
                      className="w-full bg-[#151F26] border border-[#26353F] rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-medium text-slate-300">Senha</label>
                    <button
                      type="button"
                      onClick={() => {
                        setError('');
                        setResetSentMessage('');
                        setActiveTab('forgot');
                      }}
                      className="text-xs text-[#25D366] hover:underline cursor-pointer"
                    >
                      Esqueci minha senha
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-[#151F26] border border-[#26353F] rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] disabled:opacity-50 text-[#0A1014] font-bold text-sm transition-all shadow-md shadow-[#25D366]/20 flex items-center justify-center gap-2 cursor-pointer"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Entrando...</span>
                    </>
                  ) : (
                    <>
                      <span>Entrar</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              <div className="mt-6 pt-6 border-t border-[#1F2C34] text-center">
                <p className="text-xs text-slate-400">
                  Ainda não tem conta no sistema?{' '}
                  <button
                    onClick={() => {
                      setError('');
                      setActiveTab('register');
                    }}
                    className="text-[#25D366] font-semibold hover:underline cursor-pointer"
                  >
                    Criar minha conta
                  </button>
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: CADASTRO / REGISTRO */}
          {activeTab === 'register' && (
            <div>
              <div className="mb-6">
                <h2 className="text-lg font-bold text-white">Criar minha conta</h2>
                <p className="text-xs text-slate-400 mt-0.5">Cadastre-se para acessar seu assistente imediatamente.</p>
              </div>

              {error && (
                <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleRegisterSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Nome completo</label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Seu nome"
                      className="w-full bg-[#151F26] border border-[#26353F] rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">E-mail</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu@email.com"
                      className="w-full bg-[#151F26] border border-[#26353F] rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Senha (mínimo 6 caracteres)</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-[#151F26] border border-[#26353F] rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Confirmar senha</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-[#151F26] border border-[#26353F] rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] disabled:opacity-50 text-[#0A1014] font-bold text-sm transition-all shadow-md shadow-[#25D366]/20 flex items-center justify-center gap-2 cursor-pointer"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Criando conta e acessando...</span>
                    </>
                  ) : (
                    <>
                      <span>Criar Conta e Acessar Agora</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              <div className="mt-6 pt-6 border-t border-[#1F2C34] text-center">
                <p className="text-xs text-slate-400">
                  Já possui uma conta?{' '}
                  <button
                    onClick={() => {
                      setError('');
                      setActiveTab('login');
                    }}
                    className="text-[#25D366] font-semibold hover:underline cursor-pointer"
                  >
                    Entrar
                  </button>
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: ESQUECI MINHA SENHA */}
          {activeTab === 'forgot' && (
            <div>
              <div className="mb-6">
                <h2 className="text-lg font-bold text-white">Recuperar senha</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Informe o seu e-mail cadastrado para enviarmos um link seguro e temporário para redefinição da senha.
                </p>
              </div>

              {resetSentMessage ? (
                <div className="bg-[#15241C] border border-[#25D366]/40 rounded-xl p-5 text-center space-y-3">
                  <CheckCircle className="w-8 h-8 text-[#25D366] mx-auto" />
                  <p className="text-sm font-semibold text-white">Link enviado com sucesso!</p>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {resetSentMessage}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    O link é válido por <strong>1 hora</strong>. Caso não localize na Caixa de Entrada, confira a pasta de Spam ou Lixo Eletrônico.
                  </p>
                  <button
                    onClick={() => {
                      setResetSentMessage('');
                      setError('');
                      setActiveTab('login');
                    }}
                    className="mt-4 px-4 py-2 text-xs font-semibold bg-[#25D366] text-[#0A1014] hover:bg-[#20bd5a] rounded-lg inline-block transition-colors cursor-pointer"
                  >
                    Voltar para o Login
                  </button>
                </div>
              ) : (
                <>
                  {error && (
                    <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{error}</span>
                    </div>
                  )}

                  <form onSubmit={handleResetRequestSubmit} className="space-y-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">E-mail cadastrado</label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                        <input
                          type="email"
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="seu@email.com"
                          className="w-full bg-[#151F26] border border-[#26353F] rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full py-3 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] disabled:opacity-50 text-[#0A1014] font-bold text-sm transition-all shadow-md shadow-[#25D366]/20 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Enviando link de recuperação...</span>
                        </>
                      ) : (
                        <span>Enviar link de recuperação</span>
                      )}
                    </button>
                  </form>

                  <div className="mt-6 pt-6 border-t border-[#1F2C34] text-center">
                    <button
                      onClick={() => {
                        setError('');
                        setActiveTab('login');
                      }}
                      className="text-xs text-slate-400 hover:text-white cursor-pointer"
                    >
                      ← Voltar para o Login
                    </button>
                  </div>
                </>
              )}
            </div>
          )}

          {/* TAB 4: REDEFINIR SENHA COM TOKEN */}
          {activeTab === 'reset' && (
            <div>
              <div className="mb-6">
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#15251C] text-[#25D366] border border-[#25D366]/30 mb-2">
                  <KeyRound className="w-5 h-5" />
                </div>
                <h2 className="text-lg font-bold text-white">Redefinir Senha</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Crie uma nova senha segura para sua conta: <strong className="text-slate-200">{email}</strong>
                </p>
              </div>

              {resetSuccessMessage ? (
                <div className="bg-[#15241C] border border-[#25D366]/40 rounded-xl p-5 text-center space-y-3">
                  <CheckCircle className="w-8 h-8 text-[#25D366] mx-auto" />
                  <p className="text-sm font-semibold text-white">Senha alterada com sucesso!</p>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {resetSuccessMessage}
                  </p>
                  <button
                    onClick={() => {
                      setResetSuccessMessage('');
                      setError('');
                      setPassword('');
                      setActiveTab('login');
                    }}
                    className="mt-3 px-5 py-2.5 text-xs font-bold bg-[#25D366] text-[#0A1014] hover:bg-[#20bd5a] rounded-xl inline-block transition-colors cursor-pointer shadow-lg shadow-[#25D366]/20"
                  >
                    Fazer Login com a Nova Senha
                  </button>
                </div>
              ) : (
                <>
                  {error && (
                    <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{error}</span>
                    </div>
                  )}

                  <form onSubmit={handleResetPasswordSubmit} className="space-y-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Nova Senha (mínimo 6 caracteres)
                      </label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                        <input
                          type="password"
                          required
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full bg-[#151F26] border border-[#26353F] rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Confirmar Nova Senha
                      </label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                        <input
                          type="password"
                          required
                          value={confirmNewPassword}
                          onChange={(e) => setConfirmNewPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full bg-[#151F26] border border-[#26353F] rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full py-3 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] disabled:opacity-50 text-[#0A1014] font-bold text-sm transition-all shadow-md shadow-[#25D366]/20 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Atualizando senha...</span>
                        </>
                      ) : (
                        <span>Salvar Nova Senha</span>
                      )}
                    </button>
                  </form>

                  <div className="mt-6 pt-6 border-t border-[#1F2C34] text-center">
                    <button
                      onClick={() => {
                        setError('');
                        setActiveTab('login');
                      }}
                      className="text-xs text-slate-400 hover:text-white cursor-pointer"
                    >
                      ← Voltar para o Login
                    </button>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Security badge footer */}
          <div className="mt-6 pt-4 border-t border-[#1F2C34]/60 flex items-center justify-center gap-2 text-[11px] text-slate-500">
            <ShieldCheck className="w-3.5 h-3.5 text-[#25D366]" />
            <span>Ambiente Seguro • WhatsApp que Vende</span>
          </div>
        </div>
      </div>
    </div>
  );
};
