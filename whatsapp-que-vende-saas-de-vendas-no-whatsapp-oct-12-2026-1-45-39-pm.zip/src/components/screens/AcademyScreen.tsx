import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  AcademyLevel,
  AcademyProgress,
  SalesTechnique,
  PracticalChallenge,
  UserDiagnostic,
  TrainingSession,
  AcademyLevelNumber,
} from '../../types';
import {
  ACADEMY_LEVELS,
  SALES_TECHNIQUES,
  PRACTICAL_CHALLENGES,
} from '../../data/academyData';
import { academyStorageService } from '../../services/academyStorageService';
import { trainingStorageService } from '../../services/trainingStorageService';
import { AcademyDiagnosticModal } from '../academy/AcademyDiagnosticModal';
import { AcademyTechniqueDetailModal } from '../academy/AcademyTechniqueDetailModal';
import { AcademyChallengeModal } from '../academy/AcademyChallengeModal';
import {
  GraduationCap,
  Sparkles,
  Trophy,
  Target,
  ArrowRight,
  CheckCircle2,
  BookOpen,
  Bot,
  TrendingUp,
  Settings,
  HelpCircle,
  Play,
  Award,
  Star,
  ChevronRight,
  Flame,
  Zap,
  BarChart3,
  Calendar,
} from 'lucide-react';

export const AcademyScreen: React.FC = () => {
  const { user, activeNiche, setScreen, showToast } = useApp();

  // Navigation tabs within Academy: 'hub' | 'techniques' | 'challenges' | 'performance'
  const [activeTab, setActiveTab] = useState<'hub' | 'techniques' | 'challenges' | 'performance'>('hub');

  // Academy user progress state
  const [progress, setProgress] = useState<AcademyProgress | null>(null);
  const [trainingSessions, setTrainingSessions] = useState<TrainingSession[]>([]);
  const [loading, setLoading] = useState(true);

  // Modals
  const [showDiagnosticModal, setShowDiagnosticModal] = useState(false);
  const [selectedTechnique, setSelectedTechnique] = useState<SalesTechnique | null>(null);
  const [selectedChallenge, setSelectedChallenge] = useState<PracticalChallenge | null>(null);

  // Load progress and training history
  const loadData = async () => {
    if (!user?.uid) return;
    setLoading(true);
    try {
      const [prog, sessions] = await Promise.all([
        academyStorageService.getProgress(user.uid),
        trainingStorageService.getUserTrainings(user.uid),
      ]);
      setProgress(prog);
      setTrainingSessions(sessions);
    } catch (err) {
      console.warn('Erro ao carregar dados da Academia:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user?.uid]);

  // Current level info
  const currentLevelInfo: AcademyLevel =
    ACADEMY_LEVELS.find((l) => l.level === (progress?.currentLevel || 1)) || ACADEMY_LEVELS[0];

  // Calculate completion percentage towards current level goals
  const totalLessons = SALES_TECHNIQUES.length;
  const completedLessonsCount = progress?.completedLessonIds?.length || 0;
  const totalChallenges = PRACTICAL_CHALLENGES.length;
  const completedChallengesCount = progress?.completedChallengeIds?.length || 0;

  const totalPoints = completedLessonsCount * 15 + completedChallengesCount * 10;
  const targetPointsForNextLevel = (progress?.currentLevel || 1) * 40;
  const progressPercent = Math.min(
    100,
    Math.round((totalPoints / targetPointsForNextLevel) * 100)
  );

  // Recommended technique
  const recommendedTechnique =
    SALES_TECHNIQUES.find((t) => t.id === progress?.recommendedTechniqueId) ||
    SALES_TECHNIQUES[0];

  // Save diagnostic callback
  const handleSaveDiagnostic = async (diagnostic: UserDiagnostic) => {
    if (!user?.uid) return;
    const updated = await academyStorageService.saveDiagnostic(user.uid, diagnostic);
    setProgress(updated);
    setShowDiagnosticModal(false);
    showToast('Diagnóstico atualizado! Sua trilha foi personalizada.', 'success');
  };

  // Complete lesson callback
  const handleCompleteLesson = async (techniqueId: string) => {
    if (!user?.uid) return;
    const updated = await academyStorageService.completeLesson(user.uid, techniqueId as any);
    setProgress(updated);
    showToast('Aula concluída! Você ganhou +15 pontos de evolução.', 'success');
  };

  // Complete challenge callback
  const handleCompleteChallenge = async (challengeId: string) => {
    if (!user?.uid) return;
    const updated = await academyStorageService.completeChallenge(user.uid, challengeId);
    setProgress(updated);
    showToast('Desafio superado! Você ganhou +10 pontos.', 'success');
  };

  // Start training with AI on the recommended modality
  const handlePracticeWithAi = (technique?: SalesTechnique) => {
    // Navigate to the existing interactive training simulator
    setScreen('training');
    showToast('Iniciando simulação prática no Treinamento com IA!', 'info');
  };

  return (
    <div className="flex-1 bg-[#090D10] text-[#E2E8F0] min-h-screen pb-20">
      {/* Top Banner / Breadcrumb */}
      <div className="bg-gradient-to-b from-[#101820] to-[#090D10] border-b border-[#1A2632] px-4 sm:px-6 lg:px-8 pt-6 pb-6">
        <div className="max-w-6xl mx-auto space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-[#25D366]/10 border border-[#25D366]/30 text-xs font-bold text-[#25D366]">
                <GraduationCap className="w-3.5 h-3.5" />
                <span>Academia de Vendas com IA</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                Olá, {user?.name?.split(' ')[0] || 'Vendedor'}! 👋
              </h1>
              <p className="text-xs sm:text-sm text-slate-300">
                Seu treinador pessoal para dominar a arte de vender pelo WhatsApp.
              </p>
            </div>

            {/* Nicho & Diagnóstico button */}
            <div className="flex items-center gap-2.5 bg-[#121A22] border border-[#202E3B] p-2 sm:p-2.5 rounded-2xl">
              <div className="w-8 h-8 rounded-xl bg-[#25D366]/15 text-[#25D366] flex items-center justify-center font-bold text-xs shrink-0">
                🎯
              </div>
              <div className="min-w-0 pr-2">
                <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                  Nicho de Atuação
                </div>
                <div className="text-xs font-bold text-white truncate max-w-[130px] sm:max-w-[170px]">
                  {progress?.diagnostic?.niche || activeNiche.name}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowDiagnosticModal(true)}
                className="text-[11px] font-semibold text-[#25D366] hover:text-[#20bd5a] bg-[#16241D] hover:bg-[#1A2E24] border border-[#25D366]/30 px-2.5 py-1 rounded-lg transition-colors cursor-pointer shrink-0"
              >
                Personalizar
              </button>
            </div>
          </div>

          {/* Sub Navigation Bar inside Academy */}
          <div className="flex items-center gap-1.5 overflow-x-auto pt-2 border-t border-[#1A2632]/80 no-scrollbar">
            <button
              onClick={() => setActiveTab('hub')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'hub'
                  ? 'bg-[#25D366] text-[#0A1014] font-bold shadow-md shadow-[#25D366]/20'
                  : 'text-slate-400 hover:text-white hover:bg-[#141E27]'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Início da Academia</span>
            </button>

            <button
              onClick={() => setActiveTab('techniques')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'techniques'
                  ? 'bg-[#25D366] text-[#0A1014] font-bold shadow-md shadow-[#25D366]/20'
                  : 'text-slate-400 hover:text-white hover:bg-[#141E27]'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Aprender uma Técnica ({completedLessonsCount}/{totalLessons})</span>
            </button>

            <button
              onClick={() => setActiveTab('challenges')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'challenges'
                  ? 'bg-[#25D366] text-[#0A1014] font-bold shadow-md shadow-[#25D366]/20'
                  : 'text-slate-400 hover:text-white hover:bg-[#141E27]'
              }`}
            >
              <Target className="w-4 h-4" />
              <span>Desafios Práticos ({completedChallengesCount}/{totalChallenges})</span>
            </button>

            <button
              onClick={() => setActiveTab('performance')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'performance'
                  ? 'bg-[#25D366] text-[#0A1014] font-bold shadow-md shadow-[#25D366]/20'
                  : 'text-slate-400 hover:text-white hover:bg-[#141E27]'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Meu Desempenho</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {/* ======================================================== */}
        {/* TAB 1: HUB / HOME DA ACADEMIA                            */}
        {/* ======================================================== */}
        {activeTab === 'hub' && (
          <div className="space-y-6">
            {/* Level & Progress Hero Card */}
            <div className="bg-gradient-to-r from-[#111C16] via-[#0E171E] to-[#141E28] border border-[#25D366]/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-2 max-w-xl">
                  <div className="flex items-center gap-2.5">
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-[#25D366]/20 text-[#25D366] border border-[#25D366]/40">
                      {currentLevelInfo.badge}
                    </span>
                    <span className="text-xs text-slate-400 font-medium">
                      {currentLevelInfo.tagline}
                    </span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-white">
                    {currentLevelInfo.name}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {currentLevelInfo.description}
                  </p>

                  {/* Progress bar */}
                  <div className="pt-2 space-y-1.5">
                    <div className="flex items-center justify-between text-xs text-slate-300 font-semibold">
                      <span>Progresso para o próximo nível</span>
                      <span className="text-[#25D366] font-bold">{progressPercent}%</span>
                    </div>
                    <div className="w-full bg-[#1A2632] h-2.5 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-[#25D366] to-[#34d399] h-full rounded-full transition-all duration-500"
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Quick Action Button Hero */}
                <div className="flex flex-col sm:flex-row md:flex-col gap-2.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => handlePracticeWithAi(recommendedTechnique)}
                    className="px-5 py-3 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#25D366]/20 transition-all cursor-pointer"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Continuar Treinamento</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('techniques')}
                    className="px-5 py-2.5 rounded-xl bg-[#14202A] hover:bg-[#1B2B38] text-white border border-[#273746] font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <BookOpen className="w-4 h-4 text-[#25D366]" />
                    <span>Aprender uma Técnica</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Personalized Recommendation Card */}
            <div className="bg-gradient-to-r from-[#131C24] to-[#12231A] border border-[#233544] rounded-2xl p-5 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="w-11 h-11 rounded-2xl bg-[#25D366]/15 border border-[#25D366]/30 flex items-center justify-center text-xl shrink-0">
                  {recommendedTechnique.emoji}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#25D366]">
                      Recomendação Personalizada
                    </span>
                    <span className="text-[10px] text-slate-400">
                      • Baseada nas suas respostas
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-white mt-0.5">
                    {recommendedTechnique.title}
                  </h3>
                  <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
                    {progress?.recommendationReason || recommendedTechnique.simpleExplanation}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
                <button
                  type="button"
                  onClick={() => setSelectedTechnique(recommendedTechnique)}
                  className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-[#1A2632] hover:bg-[#253646] text-white font-semibold text-xs transition-colors cursor-pointer text-center"
                >
                  Ver Aula
                </button>
                <button
                  type="button"
                  onClick={() => handlePracticeWithAi(recommendedTechnique)}
                  className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-[#25D366]/20 cursor-pointer"
                >
                  <Bot className="w-3.5 h-3.5" />
                  <span>Praticar com IA</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* 4 Feature Quick Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* 1. Aprender uma técnica */}
              <div
                onClick={() => setActiveTab('techniques')}
                className="bg-[#10171D] hover:bg-[#141E26] border border-[#1E2C37] hover:border-[#25D366]/50 p-4 rounded-2xl transition-all cursor-pointer group shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-400 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                    <BookOpen className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-white text-sm group-hover:text-[#25D366] transition-colors">
                    Aprender uma Técnica
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    SPIN Selling, AIDA, Venda Consultiva e Objeções no WhatsApp.
                  </p>
                </div>
                <div className="mt-4 flex items-center justify-between text-xs font-semibold text-sky-400">
                  <span>{completedLessonsCount} de {totalLessons} dominadas</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>

              {/* 2. Praticar com IA */}
              <div
                onClick={() => handlePracticeWithAi()}
                className="bg-[#10171D] hover:bg-[#141E26] border border-[#1E2C37] hover:border-[#25D366]/50 p-4 rounded-2xl transition-all cursor-pointer group shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-[#25D366]/10 border border-[#25D366]/20 text-[#25D366] flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                    <Bot className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-white text-sm group-hover:text-[#25D366] transition-colors">
                    Praticar com IA
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Clientes simulados em tempo real por áudio ou texto com nota instantânea.
                  </p>
                </div>
                <div className="mt-4 flex items-center justify-between text-xs font-semibold text-[#25D366]">
                  <span>Voz e Texto</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>

              {/* 3. Desafios Práticos */}
              <div
                onClick={() => setActiveTab('challenges')}
                className="bg-[#10171D] hover:bg-[#141E26] border border-[#1E2C37] hover:border-[#25D366]/50 p-4 rounded-2xl transition-all cursor-pointer group shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                    <Target className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-white text-sm group-hover:text-[#25D366] transition-colors">
                    Desafios Práticos
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Cenários curtos do dia a dia para responder e comparar com o modelo ideal.
                  </p>
                </div>
                <div className="mt-4 flex items-center justify-between text-xs font-semibold text-purple-400">
                  <span>{completedChallengesCount} de {totalChallenges} superados</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>

              {/* 4. Meu Desempenho */}
              <div
                onClick={() => setActiveTab('performance')}
                className="bg-[#10171D] hover:bg-[#141E26] border border-[#1E2C37] hover:border-[#25D366]/50 p-4 rounded-2xl transition-all cursor-pointer group shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                    <Trophy className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-white text-sm group-hover:text-[#25D366] transition-colors">
                    Meu Desempenho
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Notas comerciais, histórico de simulações e evolução pessoal.
                  </p>
                </div>
                <div className="mt-4 flex items-center justify-between text-xs font-semibold text-amber-400">
                  <span>{trainingSessions.length} treinos realizados</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>

            {/* Quick Preview of Techniques */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-[#25D366]" />
                  <span>Trilha de Técnicas Comerciais</span>
                </h3>
                <button
                  onClick={() => setActiveTab('techniques')}
                  className="text-xs text-[#25D366] hover:underline font-semibold cursor-pointer"
                >
                  Ver todas ({SALES_TECHNIQUES.length}) →
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {SALES_TECHNIQUES.slice(0, 3).map((tech) => {
                  const isDone = progress?.completedLessonIds?.includes(tech.id);
                  return (
                    <div
                      key={tech.id}
                      onClick={() => setSelectedTechnique(tech)}
                      className="bg-[#11181F] border border-[#1E2A35] hover:border-[#25D366]/40 p-4 rounded-2xl transition-all cursor-pointer flex flex-col justify-between space-y-3"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-2xl">{tech.emoji}</span>
                          {isDone ? (
                            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" /> Dominada
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold text-slate-400 bg-[#1A2632] px-2 py-0.5 rounded-full">
                              Nível {tech.level}
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-white text-sm">{tech.title}</h4>
                        <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                          {tech.simpleExplanation}
                        </p>
                      </div>

                      <div className="pt-2 border-t border-[#1C2833] flex items-center justify-between text-xs text-[#25D366] font-semibold">
                        <span>Acessar Aula</span>
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: APRENDER UMA TÉCNICA                              */}
        {/* ======================================================== */}
        {activeTab === 'techniques' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-white">
                  Técnicas de Vendas Aplicadas ao WhatsApp
                </h2>
                <p className="text-xs sm:text-sm text-slate-400">
                  Métodos comerciais comprovados, explicados de forma simples e direta com foco em mensagens reais.
                </p>
              </div>

              <div className="text-xs font-semibold text-slate-400 bg-[#121A22] border border-[#202E3B] px-3 py-1.5 rounded-xl">
                Progresso: <span className="text-[#25D366] font-bold">{completedLessonsCount}/{totalLessons}</span> técnicas dominadas
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {SALES_TECHNIQUES.map((tech) => {
                const isDone = progress?.completedLessonIds?.includes(tech.id);
                return (
                  <div
                    key={tech.id}
                    className="bg-[#11181F] border border-[#1E2A35] hover:border-[#25D366]/50 rounded-2xl p-5 flex flex-col justify-between space-y-4 transition-all shadow-sm"
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-3xl p-2 rounded-xl bg-[#17222B] border border-[#223342]">
                          {tech.emoji}
                        </span>
                        {isDone ? (
                          <span className="text-xs font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Concluída
                          </span>
                        ) : (
                          <span className="text-xs font-bold text-slate-300 bg-[#1A2632] px-2.5 py-1 rounded-full">
                            Nível {tech.level}
                          </span>
                        )}
                      </div>

                      <div className="text-[10px] font-bold text-[#25D366] uppercase tracking-wider">
                        {tech.category}
                      </div>

                      <h3 className="font-bold text-white text-base">
                        {tech.title}
                      </h3>

                      <p className="text-xs text-slate-300 line-clamp-3 leading-relaxed">
                        {tech.simpleExplanation}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-[#1C2833] flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedTechnique(tech)}
                        className="flex-1 py-2 px-3 rounded-xl bg-[#1A2632] hover:bg-[#253646] text-white font-semibold text-xs transition-colors cursor-pointer text-center"
                      >
                        Estudar Técnica
                      </button>

                      <button
                        type="button"
                        onClick={() => handlePracticeWithAi(tech)}
                        className="p-2 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] transition-all cursor-pointer"
                        title="Praticar no Treinamento IA"
                      >
                        <Bot className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 3: DESAFIOS PRÁTICOS                                 */}
        {/* ======================================================== */}
        {activeTab === 'challenges' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-white">
                  Desafios Práticos do WhatsApp
                </h2>
                <p className="text-xs sm:text-sm text-slate-400">
                  Resolva situações reais do cotidiano de vendas, compare sua resposta com o modelo de alta conversão.
                </p>
              </div>

              <div className="text-xs font-semibold text-slate-400 bg-[#121A22] border border-[#202E3B] px-3 py-1.5 rounded-xl">
                Superados: <span className="text-[#25D366] font-bold">{completedChallengesCount}/{totalChallenges}</span>
              </div>
            </div>

            <div className="space-y-3.5">
              {PRACTICAL_CHALLENGES.map((chal, index) => {
                const isDone = progress?.completedChallengeIds?.includes(chal.id);
                return (
                  <div
                    key={chal.id}
                    onClick={() => setSelectedChallenge(chal)}
                    className="bg-[#11181F] border border-[#1E2A35] hover:border-[#25D366]/40 p-4 sm:p-5 rounded-2xl transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
                  >
                    <div className="flex items-start gap-3.5">
                      <span className="text-2xl p-2.5 rounded-xl bg-[#17222B] border border-[#223342] shrink-0">
                        {chal.emoji}
                      </span>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-bold text-white group-hover:text-[#25D366] transition-colors">
                            {chal.title}
                          </span>
                          <span className="text-[10px] font-bold text-slate-400 bg-[#1A2632] px-2 py-0.5 rounded-full">
                            Nível {chal.level}
                          </span>
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
                          {chal.scenario}
                        </p>
                        <div className="text-[11px] text-sky-400 font-medium italic">
                          "{chal.customerMessage}"
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#1C2833]">
                      {isDone ? (
                        <span className="text-xs font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-3 py-1 rounded-full flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Superado
                        </span>
                      ) : (
                        <span className="text-xs font-bold text-[#0A1014] bg-[#25D366] group-hover:bg-[#20bd5a] px-3.5 py-1.5 rounded-xl flex items-center gap-1.5 transition-colors">
                          <Target className="w-3.5 h-3.5" /> Resolver Desafio
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 4: MEU DESEMPENHO                                    */}
        {/* ======================================================== */}
        {activeTab === 'performance' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white">
                Meu Desempenho e Evolução
              </h2>
              <p className="text-xs sm:text-sm text-slate-400">
                Acompanhe o seu progresso como negociador e o histórico de atendimentos avaliados pela inteligência artificial.
              </p>
            </div>

            {/* Performance Stats Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
              {/* Nível Atual */}
              <div className="bg-[#11181F] border border-[#1E2A35] p-4 rounded-2xl space-y-1">
                <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Nível de Domínio
                </div>
                <div className="text-lg font-black text-[#25D366]">
                  {currentLevelInfo.badge}
                </div>
                <div className="text-xs text-slate-400">
                  {currentLevelInfo.name.split('—')[1]?.trim() || 'Fundamentos'}
                </div>
              </div>

              {/* Técnicas */}
              <div className="bg-[#11181F] border border-[#1E2A35] p-4 rounded-2xl space-y-1">
                <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Aulas de Técnicas
                </div>
                <div className="text-xl font-black text-white">
                  {completedLessonsCount} / {totalLessons}
                </div>
                <div className="text-xs text-slate-400">
                  {Math.round((completedLessonsCount / totalLessons) * 100)}% concluído
                </div>
              </div>

              {/* Desafios */}
              <div className="bg-[#11181F] border border-[#1E2A35] p-4 rounded-2xl space-y-1">
                <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Desafios Superados
                </div>
                <div className="text-xl font-black text-white">
                  {completedChallengesCount} / {totalChallenges}
                </div>
                <div className="text-xs text-slate-400">
                  {Math.round((completedChallengesCount / totalChallenges) * 100)}% superados
                </div>
              </div>

              {/* Treinos com IA */}
              <div className="bg-[#11181F] border border-[#1E2A35] p-4 rounded-2xl space-y-1">
                <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Simulações com IA
                </div>
                <div className="text-xl font-black text-[#25D366]">
                  {trainingSessions.length}
                </div>
                <div className="text-xs text-slate-400">
                  {trainingSessions.filter((s) => s.status === 'completed').length} finalizadas com nota
                </div>
              </div>
            </div>

            {/* Diagnostic Snapshot Card */}
            {progress?.diagnostic && (
              <div className="bg-[#11181F] border border-[#1E2A35] rounded-2xl p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-[#25D366] uppercase tracking-wider flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    <span>Diagnóstico Comercial Ativo</span>
                  </div>
                  <button
                    onClick={() => setShowDiagnosticModal(true)}
                    className="text-xs text-slate-300 hover:text-white underline cursor-pointer"
                  >
                    Alterar
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-[#0E151B] border border-[#1C2731]">
                    <span className="text-slate-400 block mb-0.5">Nicho & O que Vende:</span>
                    <span className="font-bold text-white">{progress.diagnostic.niche}</span>
                    <span className="text-slate-400 block mt-0.5 text-[11px] truncate">{progress.diagnostic.productSold}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-[#0E151B] border border-[#1C2731]">
                    <span className="text-slate-400 block mb-0.5">Maior Dificuldade Atual:</span>
                    <span className="font-bold text-amber-300">{progress.diagnostic.biggestDifficulty}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-[#0E151B] border border-[#1C2731]">
                    <span className="text-slate-400 block mb-0.5">Habilidade em Treinamento:</span>
                    <span className="font-bold text-[#25D366]">{progress.diagnostic.skillToImprove}</span>
                  </div>
                </div>
              </div>
            )}

            {/* History of AI Training Sessions */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Bot className="w-4 h-4 text-[#25D366]" />
                  <span>Histórico Recente de Treinos Comerciais com IA</span>
                </h3>
                <button
                  type="button"
                  onClick={() => handlePracticeWithAi()}
                  className="text-xs text-[#25D366] hover:underline font-semibold cursor-pointer"
                >
                  Novo Treino +
                </button>
              </div>

              {trainingSessions.length === 0 ? (
                <div className="p-8 text-center bg-[#11181F] border border-[#1E2A35] rounded-2xl space-y-3">
                  <div className="w-12 h-12 rounded-full bg-[#1A2632] text-slate-400 flex items-center justify-center mx-auto">
                    <Bot className="w-6 h-6" />
                  </div>
                  <p className="text-xs sm:text-sm text-slate-400">
                    Você ainda não concluiu nenhuma simulação de vendas com a IA.
                  </p>
                  <button
                    type="button"
                    onClick={() => handlePracticeWithAi()}
                    className="px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-xs inline-flex items-center gap-2 cursor-pointer shadow-md"
                  >
                    <span>Fazer Primeiro Treino com IA</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {trainingSessions.slice(0, 5).map((sess) => {
                    const evalScore = sess.evaluation?.overallScore;
                    return (
                      <div
                        key={sess.id}
                        className="p-4 rounded-xl bg-[#11181F] border border-[#1E2A35] flex items-center justify-between gap-4"
                      >
                        <div className="space-y-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs sm:text-sm text-white truncate">
                              {sess.modalityTitle || 'Treinamento'}
                            </span>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                sess.status === 'completed'
                                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                              }`}
                            >
                              {sess.status === 'completed' ? 'Concluído' : 'Pausado'}
                            </span>
                          </div>

                          <div className="flex items-center gap-3 text-[11px] text-slate-400">
                            <span>Perfil: {sess.config?.customerProfile || 'Cliente'}</span>
                            <span>•</span>
                            <span>{sess.messages?.length || 0} mensagens trocadas</span>
                          </div>

                          {sess.evaluation?.scoreExplanation && (
                            <p className="text-xs text-slate-300 italic line-clamp-1">
                              "{sess.evaluation.scoreExplanation}"
                            </p>
                          )}
                        </div>

                        {evalScore !== undefined && (
                          <div className="text-right shrink-0">
                            <div className="text-xl font-black text-[#25D366]">
                              {evalScore}/100
                            </div>
                            <div className="text-[10px] text-slate-400 font-semibold">
                              Nota Final
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* ======================================================== */}
      {/* MODALS                                                   */}
      {/* ======================================================== */}
      {showDiagnosticModal && (
        <AcademyDiagnosticModal
          initialNiche={progress?.diagnostic?.niche || activeNiche.name}
          onSave={handleSaveDiagnostic}
          onCancel={() => setShowDiagnosticModal(false)}
        />
      )}

      {selectedTechnique && (
        <AcademyTechniqueDetailModal
          technique={selectedTechnique}
          isCompleted={Boolean(progress?.completedLessonIds?.includes(selectedTechnique.id))}
          userNiche={progress?.diagnostic?.niche || activeNiche.name}
          onComplete={handleCompleteLesson}
          onPracticeWithAi={(t) => {
            setSelectedTechnique(null);
            handlePracticeWithAi(t);
          }}
          onClose={() => setSelectedTechnique(null)}
        />
      )}

      {selectedChallenge && (
        <AcademyChallengeModal
          challenge={selectedChallenge}
          isCompleted={Boolean(progress?.completedChallengeIds?.includes(selectedChallenge.id))}
          onComplete={handleCompleteChallenge}
          onClose={() => setSelectedChallenge(null)}
        />
      )}
    </div>
  );
};
