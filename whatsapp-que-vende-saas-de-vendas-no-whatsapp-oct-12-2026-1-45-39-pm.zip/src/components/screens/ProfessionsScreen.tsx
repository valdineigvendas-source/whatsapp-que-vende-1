import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ALL_PROFESSION_CATEGORIES,
  ALL_PROFESSIONS,
} from '../../data/professionsData';
import {
  ProfessionNiche,
  ProfessionCategoryId,
  AttendanceSituation,
  AttendanceOption,
} from '../../types';
import { CustomProfessionModal } from '../professions/CustomProfessionModal';
import {
  Car,
  Bike,
  Truck,
  PieChart,
  Home,
  MapPin,
  Layers,
  Key,
  ShoppingBag,
  Smartphone,
  Armchair,
  Scissors,
  Sparkles,
  Heart,
  Scale,
  Calculator,
  Camera,
  MessageCircle,
  Tag,
  Shield,
  Dumbbell,
  Apple,
  Briefcase,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  RotateCcw,
  Clock,
  AlertCircle,
  Copy,
  Check,
  ChevronRight,
  DollarSign,
  Bot,
  Target,
  GraduationCap,
  Sparkles as SparklesIcon,
  ShieldCheck,
  Zap,
} from 'lucide-react';

export const ProfessionsScreen: React.FC = () => {
  const {
    selectedProfessionId,
    setSelectedProfessionId,
    copyToClipboard,
    user,
    setNicheProfession,
    nicheAutomationActive,
    setScreen,
    updateProfile,
    showToast,
  } = useApp();

  // Active category filter: 'all' | ProfessionCategoryId
  const [selectedCategory, setSelectedCategory] = useState<'all' | ProfessionCategoryId>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [activeProfId, setActiveProfId] = useState<string>(
    selectedProfessionId || 'vendedor-carros-seminovos'
  );

  // Copy feedback
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [copiedOptionId, setCopiedOptionId] = useState<string | null>(null);

  // Situation filters for professions with FAO attendance situations
  const [selectedSituationNumber, setSelectedSituationNumber] = useState<number | 'all'>('all');
  const [pillarFilter, setPillarFilter] = useState<'all' | string>('all');
  const [situationSearch, setSituationSearch] = useState<string>('');
  const [activeViewMode, setActiveViewMode] = useState<'situations' | 'sample' | 'aiContext'>('situations');

  // Custom profession modal
  const [showCustomModal, setShowCustomModal] = useState(false);

  // Icon resolver
  const getProfessionIcon = (iconName: string) => {
    switch (iconName) {
      case 'Car':
        return Car;
      case 'Bike':
        return Bike;
      case 'Truck':
        return Truck;
      case 'PieChart':
        return PieChart;
      case 'Home':
        return Home;
      case 'MapPin':
        return MapPin;
      case 'Layers':
        return Layers;
      case 'Key':
        return Key;
      case 'ShoppingBag':
        return ShoppingBag;
      case 'Smartphone':
        return Smartphone;
      case 'Armchair':
        return Armchair;
      case 'Scissors':
        return Scissors;
      case 'Sparkles':
        return Sparkles;
      case 'Heart':
        return Heart;
      case 'Scale':
        return Scale;
      case 'Calculator':
        return Calculator;
      case 'Camera':
        return Camera;
      case 'MessageCircle':
        return MessageCircle;
      case 'Tag':
        return Tag;
      case 'Shield':
        return Shield;
      case 'Dumbbell':
        return Dumbbell;
      case 'Apple':
        return Apple;
      default:
        return Briefcase;
    }
  };

  // Filtered professions list based on category and search query
  const filteredProfessions = useMemo(() => {
    return ALL_PROFESSIONS.filter((prof) => {
      const matchesCategory =
        selectedCategory === 'all' || prof.categoryId === selectedCategory;
      const matchesSearch =
        searchTerm.trim() === '' ||
        prof.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prof.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prof.commonObjection.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchTerm]);

  // Current active profession
  const currentProfession: ProfessionNiche =
    ALL_PROFESSIONS.find((p) => p.id === activeProfId) || ALL_PROFESSIONS[0];

  const hasAttendanceSituations =
    Boolean(currentProfession.attendanceSituations && currentProfession.attendanceSituations.length > 0);

  // Filtered attendance situations
  const filteredSituations = (currentProfession.attendanceSituations || []).filter((sit) => {
    const matchesNumber =
      selectedSituationNumber === 'all' || sit.number === selectedSituationNumber;
    const matchesPillar =
      pillarFilter === 'all' || sit.faoPillar.includes(pillarFilter);
    const matchesSearch =
      situationSearch.trim() === '' ||
      sit.title.toLowerCase().includes(situationSearch.toLowerCase()) ||
      sit.description.toLowerCase().includes(situationSearch.toLowerCase()) ||
      sit.options.some(
        (opt) =>
          opt.title.toLowerCase().includes(situationSearch.toLowerCase()) ||
          opt.text.toLowerCase().includes(situationSearch.toLowerCase()) ||
          opt.whenToUse.toLowerCase().includes(situationSearch.toLowerCase())
      );

    return matchesNumber && matchesPillar && matchesSearch;
  });

  const handleCopySample = (text: string, idx: number) => {
    copyToClipboard(text, 'Mensagem copiada para a área de transferência!');
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2200);
  };

  const handleCopyOption = (text: string, optId: string) => {
    copyToClipboard(text, 'Opção de mensagem copiada com sucesso!');
    setCopiedOptionId(optId);
    setTimeout(() => setCopiedOptionId(null), 2200);
  };

  const handleSetPrimary = () => {
    setNicheProfession(currentProfession.id);
  };

  const isUserProfession =
    user?.profession === currentProfession.name || selectedProfessionId === currentProfession.id;

  // Save custom profession
  const handleSaveCustomProfession = async (customData: {
    name: string;
    productOrService: string;
    targetAudience: string;
    commonObjection?: string;
  }) => {
    try {
      await updateProfile({
        profession: customData.name,
        businessType: customData.productOrService,
        customProfession: customData,
      });
      setSelectedProfessionId('custom-' + customData.name.toLowerCase().replace(/\s+/g, '-'));
      setShowCustomModal(false);
      showToast(
        `⚡ Profissão personalizada "${customData.name}" ativada em todo o aplicativo!`,
        'automation'
      );
    } catch (err) {
      console.error('Erro ao salvar profissão personalizada:', err);
    }
  };

  const getToneBadgeClass = (tone: string) => {
    switch (tone) {
      case 'Consultivo':
        return 'bg-blue-950/70 text-blue-300 border-blue-500/30';
      case 'Persuasivo':
        return 'bg-amber-950/70 text-amber-300 border-amber-500/30';
      case 'Empático':
        return 'bg-purple-950/70 text-purple-300 border-purple-500/30';
      case 'Direto':
        return 'bg-teal-950/70 text-teal-300 border-teal-500/30';
      default:
        return 'bg-emerald-950/70 text-[#25D366] border-[#25D366]/40';
    }
  };

  const CurrentIcon = getProfessionIcon(currentProfession.icon);

  return (
    <div className="space-y-8 animate-in fade-in duration-300 pb-16">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold text-[#25D366] uppercase tracking-wider mb-1">
            <Briefcase className="w-3.5 h-3.5" />
            <span>8 Categorias Comerciais • Modelos Especializados</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Roteiros por Profissão
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-400 max-w-2xl">
            Aulas, mensagens, diagnósticos e simulações com IA adaptados ao vocabulário, dores e objeções reais da sua atividade comercial.
          </p>
        </div>

        {/* Custom Profession Action Button */}
        <button
          type="button"
          onClick={() => setShowCustomModal(true)}
          className="px-4 py-2.5 rounded-xl bg-[#14231E] hover:bg-[#1A3025] text-[#25D366] border border-[#25D366]/40 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Minha profissão não está na lista</span>
        </button>
      </div>

      {/* User Custom Profession Active Notification if set */}
      {user?.customProfession && (
        <div className="bg-gradient-to-r from-[#14231A] via-[#0E1A14] to-[#121B24] border border-[#25D366]/40 p-4 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#25D366]/20 text-[#25D366] flex items-center justify-center font-bold text-sm shrink-0">
              ⭐
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#25D366]">
                  Profissão Personalizada Ativa
                </span>
                <span className="text-[9px] font-mono bg-[#25D366] text-[#0A1014] font-bold px-1.5 py-0.2 rounded">
                  SUA ATIVIDADE
                </span>
              </div>
              <h4 className="text-sm font-bold text-white mt-0.5">
                {user.customProfession.name} — {user.customProfession.productOrService}
              </h4>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setShowCustomModal(true)}
            className="text-xs text-[#25D366] hover:underline font-semibold self-start sm:self-auto cursor-pointer"
          >
            Editar Personalização
          </button>
        </div>
      )}

      {/* Category Pills Bar + Search */}
      <div className="space-y-3">
        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por profissão, nicho ou palavra-chave (ex: carros, terrenos, roupas, advogado, seguro)..."
            className="w-full bg-[#111921] border border-[#22303C] rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
          />
        </div>

        {/* Categories scrollable pill selector */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedCategory === 'all'
                ? 'bg-[#25D366] text-[#0A1014] shadow-sm'
                : 'bg-[#121A22] text-slate-300 hover:text-white border border-[#1F2C37]'
            }`}
          >
            <span>Todas as Áreas</span>
            <span className="text-[10px] opacity-75">({ALL_PROFESSIONS.length})</span>
          </button>

          {ALL_PROFESSION_CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-[#25D366] text-[#0A1014] shadow-sm'
                    : 'bg-[#121A22] text-slate-300 hover:text-white border border-[#1F2C37]'
                }`}
              >
                <span>{cat.emoji}</span>
                <span>{cat.title}</span>
                <span className="text-[10px] opacity-75">({cat.professions.length})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid of Professions */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Selecione a profissão para visualizar roteiros e situações:
          </span>
          <span className="text-xs text-slate-500 font-medium">
            {filteredProfessions.length} profissões disponíveis
          </span>
        </div>

        {filteredProfessions.length === 0 ? (
          <div className="p-8 text-center bg-[#111921] border border-[#22303C] rounded-2xl space-y-3">
            <p className="text-xs sm:text-sm text-slate-400">
              Nenhuma profissão encontrada com o termo "{searchTerm}".
            </p>
            <button
              type="button"
              onClick={() => setShowCustomModal(true)}
              className="px-4 py-2 rounded-xl bg-[#25D366] text-[#0A1014] font-bold text-xs inline-flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Cadastrar Minha Profissão Personalizada</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5">
            {filteredProfessions.map((prof) => {
              const Icon = getProfessionIcon(prof.icon);
              const isSelected = prof.id === activeProfId;
              const isUserCurrent = user?.profession === prof.name || selectedProfessionId === prof.id;

              return (
                <button
                  key={prof.id}
                  onClick={() => {
                    setActiveProfId(prof.id);
                    setSelectedSituationNumber('all');
                    setSituationSearch('');
                    // Auto-set as default view mode
                    if (prof.attendanceSituations && prof.attendanceSituations.length > 0) {
                      setActiveViewMode('situations');
                    } else {
                      setActiveViewMode('sample');
                    }
                  }}
                  className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between gap-2.5 group cursor-pointer relative ${
                    isSelected
                      ? 'bg-[#15251C] border-[#25D366] text-[#25D366] shadow-md ring-1 ring-[#25D366]'
                      : 'bg-[#0E151B] border-[#1E2B35] text-slate-300 hover:text-white hover:bg-[#131B22]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-1 w-full">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
                        isSelected
                          ? 'bg-[#25D366] text-[#0A1014]'
                          : 'bg-[#17222B] text-slate-400 group-hover:text-[#25D366]'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>

                    {isUserCurrent && (
                      <span className="text-[9px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                        <Check className="w-2.5 h-2.5" /> Ativa
                      </span>
                    )}

                    {!isUserCurrent && prof.badge && (
                      <span className="text-[9px] font-bold uppercase tracking-wider bg-[#25D366]/15 text-[#25D366] border border-[#25D366]/30 px-1.5 py-0.5 rounded-full">
                        {prof.badge}
                      </span>
                    )}
                  </div>

                  <div>
                    <h4 className="text-xs font-bold leading-tight line-clamp-2 text-white group-hover:text-[#25D366] transition-colors">
                      {prof.name}
                    </h4>
                    <span className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                      {prof.typicalTicket}
                    </span>
                  </div>

                  {prof.attendanceSituations && prof.attendanceSituations.length > 0 && (
                    <span className="text-[9px] font-semibold text-[#25D366] bg-[#12231A] px-2 py-0.5 rounded-md border border-[#25D366]/30 inline-block w-fit">
                      10 Situações F.A.O.
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* ======================================================== */}
      {/* DETAILED ACTIVE PROFESSION PANEL                         */}
      {/* ======================================================== */}
      <div className="bg-[#0E151B] border border-[#1E2B35] rounded-2xl p-5 sm:p-7 space-y-6">
        {/* Niche Summary Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#1A252E]">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-[#17251E] border border-[#25D366]/30 text-[#25D366] flex items-center justify-center shrink-0">
              <CurrentIcon className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg sm:text-xl font-bold text-white">
                  {currentProfession.name}
                </h2>
                {isUserProfession && (
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Sua Profissão Atual
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {currentProfession.description}
              </p>
            </div>
          </div>

          {/* Action buttons on active profession */}
          <div className="flex items-center gap-2 shrink-0">
            {!isUserProfession && (
              <button
                type="button"
                onClick={handleSetPrimary}
                className="px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-xs sm:text-sm transition-all shadow-md shadow-[#25D366]/20 cursor-pointer flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Ativar no Meu Perfil</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                setNicheProfession(currentProfession.id);
                setScreen('training');
              }}
              className="px-4 py-2 rounded-xl bg-[#17252F] hover:bg-[#20323F] text-white border border-[#2B3E4E] font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Bot className="w-4 h-4 text-[#25D366]" />
              <span>Simular com IA</span>
            </button>
          </div>
        </div>

        {/* Commercial Highlights Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-xl bg-[#111921] border border-[#1F2C37]">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
              Ticket Médio / Faixa de Valor
            </span>
            <span className="text-sm font-bold text-white">
              {currentProfession.typicalTicket}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-[#111921] border border-[#1F2C37]">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
              Objeção Mais Frequente
            </span>
            <span className="text-xs font-semibold text-amber-300">
              {currentProfession.commonObjection}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-[#111921] border border-[#1F2C37]">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
              Status de Automação
            </span>
            <span className="text-xs font-semibold text-[#25D366] flex items-center gap-1">
              <Zap className="w-3.5 h-3.5" />
              {isUserProfession && nicheAutomationActive
                ? 'Ativa em todas as mensagens'
                : 'Pronto para ativar'}
            </span>
          </div>
        </div>

        {/* View Mode Tabs Selector */}
        <div className="flex items-center gap-2 border-b border-[#1A252E] pb-3 overflow-x-auto no-scrollbar">
          {hasAttendanceSituations && (
            <button
              type="button"
              onClick={() => setActiveViewMode('situations')}
              className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                activeViewMode === 'situations'
                  ? 'bg-[#25D366] text-[#0A1014]'
                  : 'text-slate-400 hover:text-white hover:bg-[#141E26]'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>10 Situações de Atendimento (F.A.O.)</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setActiveViewMode('sample')}
            className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeViewMode === 'sample'
                ? 'bg-[#25D366] text-[#0A1014]'
                : 'text-slate-400 hover:text-white hover:bg-[#141E26]'
            }`}
          >
            <MessageCircle className="w-4 h-4" />
            <span>Modelos Prontos de Mensagens</span>
          </button>

          {currentProfession.aiContext && (
            <button
              type="button"
              onClick={() => setActiveViewMode('aiContext')}
              className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                activeViewMode === 'aiContext'
                  ? 'bg-[#25D366] text-[#0A1014]'
                  : 'text-slate-400 hover:text-white hover:bg-[#141E26]'
              }`}
            >
              <Bot className="w-4 h-4" />
              <span>Diretrizes e Critérios da IA</span>
            </button>
          )}
        </div>

        {/* -------------------------------------------------------- */}
        {/* VIEW 1: FAO ATTENDANCE SITUATIONS (e.g. Veículos / Imóveis) */}
        {/* -------------------------------------------------------- */}
        {activeViewMode === 'situations' && hasAttendanceSituations && (
          <div className="space-y-5">
            {/* Situation Filters Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#111921] p-3 rounded-xl border border-[#1F2C37]">
              {/* Pillar Filter */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1 shrink-0">
                  Pilar FAO:
                </span>
                {[
                  { id: 'all', label: 'Todos os Pilares' },
                  { id: 'Filtro', label: 'Filtro (F)' },
                  { id: 'Alinhamento', label: 'Alinhamento (A)' },
                  { id: 'Objeção', label: 'Objeção (O)' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setPillarFilter(item.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                      pillarFilter === item.id
                        ? 'bg-[#25D366] text-[#0A1014]'
                        : 'bg-[#17222B] text-slate-300 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              {/* In-Situation Search */}
              <div className="relative min-w-[200px]">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={situationSearch}
                  onChange={(e) => setSituationSearch(e.target.value)}
                  placeholder="Buscar na situação..."
                  className="w-full bg-[#17222B] border border-[#23313E] rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366]"
                />
              </div>
            </div>

            {/* List of FAO Situations */}
            <div className="space-y-4">
              {filteredSituations.map((sit) => (
                <div
                  key={sit.id}
                  className="bg-[#111921] border border-[#1F2C37] rounded-2xl p-4 sm:p-5 space-y-4"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="w-6 h-6 rounded-lg bg-[#25D366]/20 text-[#25D366] font-bold text-xs flex items-center justify-center">
                          {sit.number}
                        </span>
                        <span className="text-xs font-bold text-[#25D366] uppercase tracking-wider">
                          {sit.stageName}
                        </span>
                        <span className="text-[10px] font-bold text-slate-300 bg-[#17222B] px-2 py-0.5 rounded-full border border-[#23313E]">
                          {sit.faoPillar}
                        </span>
                      </div>
                      <h3 className="text-sm sm:text-base font-bold text-white">
                        {sit.title}
                      </h3>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        {sit.description}
                      </p>
                    </div>
                  </div>

                  {/* Options List */}
                  <div className="space-y-3 pt-2">
                    {sit.options.map((opt) => (
                      <div
                        key={opt.id}
                        className="bg-[#0C1217] border border-[#1C2833] rounded-xl p-3.5 sm:p-4 space-y-3"
                      >
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <span className="text-xs font-bold text-white">
                            {opt.title}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${getToneBadgeClass(
                              opt.tone
                            )}`}
                          >
                            Tom {opt.tone}
                          </span>
                        </div>

                        {/* WhatsApp Message Balloon */}
                        <div className="bg-[#0A160F] border border-[#25D366]/30 rounded-xl p-3 text-xs sm:text-sm text-emerald-100 font-mono whitespace-pre-line leading-relaxed shadow-inner">
                          {opt.text}
                        </div>

                        {/* Rationale and Strategy */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-400">
                          <div className="p-2 rounded-lg bg-[#111921] border border-[#1C2833]">
                            <span className="text-slate-300 font-bold block mb-0.5">📌 Quando Usar:</span>
                            <span>{opt.whenToUse}</span>
                          </div>
                          <div className="p-2 rounded-lg bg-[#111921] border border-[#1C2833]">
                            <span className="text-[#25D366] font-bold block mb-0.5">💡 Por que Funciona:</span>
                            <span>{opt.whyItWorks}</span>
                          </div>
                        </div>

                        {/* Copy button */}
                        <div className="flex justify-end pt-1">
                          <button
                            type="button"
                            onClick={() => handleCopyOption(opt.text, opt.id)}
                            className="px-3 py-1.5 rounded-lg bg-[#1A2632] hover:bg-[#253646] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                          >
                            {copiedOptionId === opt.id ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                                <span className="text-emerald-400">Copiado!</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copiar Script</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* -------------------------------------------------------- */}
        {/* VIEW 2: SAMPLE READY MESSAGES                            */}
        {/* -------------------------------------------------------- */}
        {activeViewMode === 'sample' && (
          <div className="space-y-4">
            {currentProfession.sampleMessages.map((sample, idx) => (
              <div
                key={idx}
                className="bg-[#111921] border border-[#1F2C37] rounded-xl p-4 sm:p-5 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white">{sample.title}</h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#16222C] text-[#25D366] border border-[#233543]">
                    Modelo #{idx + 1}
                  </span>
                </div>

                <div className="text-xs text-slate-400">
                  <span className="font-semibold text-slate-300">Situação: </span>
                  {sample.situation}
                </div>

                <div className="bg-[#0A160F] border border-[#25D366]/30 rounded-xl p-3.5 text-xs sm:text-sm text-emerald-100 font-mono whitespace-pre-line leading-relaxed shadow-inner">
                  {sample.text}
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 text-xs">
                  <span className="text-amber-300/90 text-[11px] italic">
                    💡 Dica: {sample.tip}
                  </span>

                  <button
                    type="button"
                    onClick={() => handleCopySample(sample.text, idx)}
                    className="self-end sm:self-auto px-3 py-1.5 rounded-lg bg-[#1A2632] hover:bg-[#253646] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedIndex === idx ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copiado!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copiar Mensagem</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* -------------------------------------------------------- */}
        {/* VIEW 3: AI CONTEXT & CRITERIA GUIDELINES                 */}
        {/* -------------------------------------------------------- */}
        {activeViewMode === 'aiContext' && currentProfession.aiContext && (
          <div className="space-y-4">
            <div className="bg-[#111921] border border-[#1F2C37] rounded-xl p-4 sm:p-5 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-[#25D366] uppercase tracking-wider">
                <Bot className="w-4 h-4" />
                <span>Como o Cliente Simulado por IA se Comporta neste Nicho</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {currentProfession.aiContext.roleDescription}
              </p>
            </div>

            {/* Typical Objections */}
            <div className="bg-[#111921] border border-[#1F2C37] rounded-xl p-4 sm:p-5 space-y-3">
              <div className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                Objeções que a IA pode apresentar durante a simulação:
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {currentProfession.aiContext.typicalObjections.map((obj, i) => (
                  <div
                    key={i}
                    className="p-2.5 rounded-lg bg-[#0E151B] border border-[#1C2731] text-xs text-slate-300"
                  >
                    • {obj}
                  </div>
                ))}
              </div>
            </div>

            {/* Evaluation Criteria */}
            <div className="bg-[#111921] border border-[#1F2C37] rounded-xl p-4 sm:p-5 space-y-3">
              <div className="text-xs font-bold text-sky-400 uppercase tracking-wider">
                Critérios de Avaliação Aplicados pela IA:
              </div>
              <div className="space-y-2">
                {currentProfession.aiContext.evaluationCriteria.map((crit, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-2 p-2.5 rounded-lg bg-[#0E151B] border border-[#1C2731] text-xs text-slate-300"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#25D366] shrink-0 mt-0.5" />
                    <span>{crit}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Direct CTA to Simulator */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-[#14231E] to-[#12242D] border border-[#25D366]/40 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <h4 className="text-sm font-bold text-white">
                  Praticar Atendimento com Cliente IA de {currentProfession.name}
                </h4>
                <p className="text-xs text-slate-300 mt-0.5">
                  Converse por áudio ou texto e receba feedback em tempo real com nota comercial.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setNicheProfession(currentProfession.id);
                  setScreen('training');
                }}
                className="px-4 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-md shadow-[#25D366]/20 cursor-pointer shrink-0"
              >
                <Bot className="w-4 h-4" />
                <span>Começar Treino Agora</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Custom Profession Modal */}
      {showCustomModal && (
        <CustomProfessionModal
          initialData={user?.customProfession}
          onSave={handleSaveCustomProfession}
          onClose={() => setShowCustomModal(false)}
        />
      )}
    </div>
  );
};
