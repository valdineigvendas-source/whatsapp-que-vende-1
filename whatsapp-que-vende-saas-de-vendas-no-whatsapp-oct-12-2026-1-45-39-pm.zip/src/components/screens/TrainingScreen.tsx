import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  TrainingModality,
  TrainingConfig,
  ChatMessage,
  TrainingEvaluation,
  TrainingModalityId,
  TrainingSession,
} from '../../types';
import { TRAINING_MODALITIES } from '../../data/trainingData';
import { trainingClientService } from '../../services/trainingClientService';
import { trainingStorageService } from '../../services/trainingStorageService';
import { TrainingChatSimulator } from '../training/TrainingChatSimulator';
import { TrainingConfigModal } from '../training/TrainingConfigModal';
import { TrainingEvaluationView } from '../training/TrainingEvaluationView';
import { TrainingProgressView } from '../training/TrainingProgressView';
import {
  Target,
  Trophy,
  Play,
  ArrowRight,
  Clock,
  MessageSquare,
  PauseCircle,
  RotateCcw,
} from 'lucide-react';

export const TrainingScreen: React.FC = () => {
  const { user, activeNiche, setScreen, showToast } = useApp();

  // Estados da jornada: 'hub' | 'config' | 'chat' | 'evaluation' | 'progress'
  const [viewState, setViewState] = useState<'hub' | 'config' | 'chat' | 'evaluation' | 'progress'>('hub');
  const [selectedModality, setSelectedModality] = useState<TrainingModality | null>(null);
  const [activeConfig, setActiveConfig] = useState<TrainingConfig | null>(null);
  const [activeMessages, setActiveMessages] = useState<ChatMessage[]>([]);
  const [currentEvaluation, setCurrentEvaluation] = useState<TrainingEvaluation | null>(null);
  const [currentSessionId, setCurrentSessionId] = useState<string>('');

  // Lista de sessões pausadas / em andamento para exibir no topo do Hub
  const [ongoingSessions, setOngoingSessions] = useState<TrainingSession[]>([]);

  // Carregar sessões pausadas para o Hub
  const refreshOngoingSessions = async () => {
    if (!user?.uid) return;
    try {
      const allSessions = await trainingStorageService.getUserTrainings(user.uid);
      const ongoings = allSessions.filter((s) => s.status === 'active' || s.status === 'paused');
      setOngoingSessions(ongoings);
    } catch (err) {
      console.warn('Erro ao carregar sessões em andamento:', err);
    }
  };

  useEffect(() => {
    refreshOngoingSessions();
  }, [user?.uid, viewState]);

  // 1. Iniciar modal de configuração de uma modalidade
  const handleOpenConfig = (modality: TrainingModality) => {
    setSelectedModality(modality);
    setViewState('config');
  };

  // 2. Iniciar nova simulação de chat
  const handleStartSession = async (config: TrainingConfig) => {
    setActiveConfig(config);
    const mod = TRAINING_MODALITIES.find((m) => m.id === config.modalityId) || TRAINING_MODALITIES[0];

    const initialCustomerMessage: ChatMessage = {
      id: 'msg-init-' + Date.now(),
      sender: 'customer',
      text: mod.initialCustomerMessage,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    };

    const newSessionId = 'train_' + Date.now();
    setCurrentSessionId(newSessionId);
    const initialList = [initialCustomerMessage];
    setActiveMessages(initialList);
    setViewState('chat');

    // Auto-salvar no Firestore imediatamente para permitir retomada
    if (user?.uid) {
      await trainingStorageService.saveTrainingSession(user.uid, {
        id: newSessionId,
        userId: user.uid,
        modalityId: config.modalityId,
        modalityTitle: mod.title,
        config,
        messages: initialList,
        status: 'active',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }
  };

  // 3. Retomar sessão existente de onde parou
  const handleResumeSession = (session: TrainingSession) => {
    const mod = TRAINING_MODALITIES.find((m) => m.id === session.modalityId) || TRAINING_MODALITIES[0];
    setSelectedModality(mod);
    setActiveConfig(session.config);
    setActiveMessages(session.messages || []);
    setCurrentSessionId(session.id);
    setViewState('chat');
    showToast(`Treinamento retomado! Continuando de onde parou.`, 'info');
  };

  // 4. Auto-save durante o chat (chamado a cada mensagem enviada ou recebida)
  const handleAutoSave = async (updatedMessages: ChatMessage[]) => {
    setActiveMessages(updatedMessages);
    if (user?.uid && currentSessionId && activeConfig && selectedModality) {
      await trainingStorageService.saveTrainingSession(user.uid, {
        id: currentSessionId,
        userId: user.uid,
        modalityId: activeConfig.modalityId,
        modalityTitle: selectedModality.title,
        config: activeConfig,
        messages: updatedMessages,
        status: 'active',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }
  };

  // 5. Pausar treinamento
  const handlePauseSession = async (currentMessages: ChatMessage[]) => {
    if (user?.uid && currentSessionId && activeConfig && selectedModality) {
      await trainingStorageService.saveTrainingSession(user.uid, {
        id: currentSessionId,
        userId: user.uid,
        modalityId: activeConfig.modalityId,
        modalityTitle: selectedModality.title,
        config: activeConfig,
        messages: currentMessages,
        status: 'paused',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }

    setViewState('hub');
    showToast('Treinamento pausado. Seu progresso foi salvo e você pode continuar quando quiser! ⏸️', 'success');
    refreshOngoingSessions();
  };

  // 6. Encerrar simulação e processar avaliação pela IA
  const handleFinishChat = async (finalMessages: ChatMessage[]) => {
    if (!activeConfig || !selectedModality) return;

    try {
      showToast('Avaliando sua condução e gerando feedback...', 'info');
      const evaluation = await trainingClientService.evaluateSession(
        activeConfig,
        finalMessages,
        selectedModality.title
      );

      setCurrentEvaluation(evaluation);
      setViewState('evaluation');

      // Salvar como concluído no Firestore
      if (user?.uid) {
        await trainingStorageService.saveTrainingSession(user.uid, {
          id: currentSessionId,
          userId: user.uid,
          modalityId: activeConfig.modalityId,
          modalityTitle: selectedModality.title,
          config: activeConfig,
          messages: finalMessages,
          evaluation,
          status: 'completed',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          completedAt: new Date().toISOString(),
        });
      }

      showToast('Avaliação concluída com sucesso! 🏆', 'success');
      refreshOngoingSessions();
    } catch (err) {
      console.error('Erro ao avaliar treino:', err);
      showToast('Erro ao processar avaliação. Tente novamente.', 'info');
    }
  };

  // 7. Reiniciar a mesma modalidade
  const handleRestartCurrent = () => {
    if (activeConfig) {
      handleStartSession(activeConfig);
    }
  };

  // 8. Selecionar o treino recomendado após avaliação
  const handleSelectRecommended = (modalityId: TrainingModalityId) => {
    const mod = TRAINING_MODALITIES.find((m) => m.id === modalityId) || TRAINING_MODALITIES[0];
    handleOpenConfig(mod);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Visualização de Progresso Completo */}
      {viewState === 'progress' && (
        <TrainingProgressView
          userId={user?.uid || ''}
          onResumeSession={handleResumeSession}
          onSelectModality={(mId) => {
            const mod = TRAINING_MODALITIES.find((m) => m.id === mId) || TRAINING_MODALITIES[0];
            handleOpenConfig(mod);
          }}
          onBackToHub={() => setViewState('hub')}
        />
      )}

      {/* Visualização da Avaliação Final */}
      {viewState === 'evaluation' && currentEvaluation && (
        <TrainingEvaluationView
          evaluation={currentEvaluation}
          onRetry={handleRestartCurrent}
          onSelectAnother={() => setViewState('hub')}
          onSelectRecommended={handleSelectRecommended}
          onViewProgress={() => setViewState('progress')}
          onGoHome={() => setScreen('dashboard')}
        />
      )}

      {/* Visualização do Simulador de Conversa (WhatsApp) */}
      {viewState === 'chat' && activeConfig && (
        <TrainingChatSimulator
          config={activeConfig}
          initialMessages={activeMessages}
          onFinish={handleFinishChat}
          onPause={handlePauseSession}
          onAutoSave={handleAutoSave}
          onCancel={() => {
            handlePauseSession(activeMessages);
          }}
          onRestart={handleRestartCurrent}
        />
      )}

      {/* Modal de Configuração Prévia (Texto vs Voz) */}
      {viewState === 'config' && selectedModality && (
        <TrainingConfigModal
          modality={selectedModality}
          defaultProduct={activeNiche.name}
          onStart={handleStartSession}
          onCancel={() => setViewState('hub')}
        />
      )}

      {/* HUB PRINCIPAL DE ESCOLHA DAS MODALIDADES */}
      {viewState === 'hub' && (
        <>
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-bold text-[#25D366] uppercase tracking-wider mb-1">
                <Target className="w-4 h-4" />
                <span>Simulador de Vendas com IA • Texto e Voz</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                Treine suas conversas. Prepare-se para vender.
              </h1>
              <p className="mt-1 text-sm sm:text-base text-slate-300 max-w-3xl leading-relaxed">
                Pratique situações reais com clientes simulados por IA, descubra onde pode melhorar e aprenda a conduzir conversas que avançam para a venda.
              </p>
            </div>

            <button
              onClick={() => setViewState('progress')}
              className="px-4 py-2.5 rounded-xl bg-[#16222C] hover:bg-[#1E2E3C] text-[#25D366] border border-[#25D366]/30 text-xs font-bold flex items-center gap-2 transition-all shadow-md self-start sm:self-auto cursor-pointer"
            >
              <Trophy className="w-4 h-4" />
              <span>📚 Seus Treinamentos & Avaliações</span>
            </button>
          </div>

          {/* SESSÃO DE RETOMADA: Seus Treinamentos em Andamento */}
          {ongoingSessions.length > 0 && (
            <div className="bg-[#0F171F] border border-amber-500/30 p-5 rounded-2xl space-y-3 shadow-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <PauseCircle className="w-4 h-4 text-amber-400" />
                  <h3 className="text-sm font-bold text-white">Continuar Treinando (Sessões Pausadas)</h3>
                </div>
                <span className="text-[11px] text-amber-400 font-mono font-semibold">
                  {ongoingSessions.length} sessão{ongoingSessions.length > 1 ? 'ões' : ''} em andamento
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                {ongoingSessions.slice(0, 4).map((sess) => (
                  <div
                    key={sess.id}
                    className="p-3.5 rounded-xl bg-[#141E27] border border-[#223545] flex items-center justify-between gap-3 hover:border-amber-500/50 transition-colors"
                  >
                    <div className="min-w-0 space-y-0.5">
                      <span className="text-xs font-bold text-white block truncate">
                        {sess.modalityTitle}
                      </span>
                      <p className="text-[11px] text-slate-400 truncate">
                        {sess.config.productOrService} • {sess.messages?.length || 0} msgs • {sess.config.interactionMode === 'voice' ? '🎙️ Voz' : '⌨️ Texto'}
                      </p>
                    </div>

                    <button
                      onClick={() => handleResumeSession(sess)}
                      className="px-3.5 py-1.5 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#0A1014] text-xs font-bold flex items-center gap-1.5 shrink-0 transition-all shadow-sm cursor-pointer"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Retomar</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Notice Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-[#121E17] via-[#0E1714] to-[#111A20] border border-[#25D366]/20 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#25D366]/15 border border-[#25D366]/30 flex items-center justify-center text-[#25D366] shrink-0 font-bold">
                🎙️
              </div>
              <div>
                <span className="text-xs font-bold text-white block">Treinamento por Texto ou por Voz com Salvamento Automático</span>
                <span className="text-[11px] text-slate-300 block">
                  Fale no microfone e ouça o cliente responder em áudio ou digite normalmente. Pause a qualquer momento e retome sem perder nada.
                </span>
              </div>
            </div>

            <span className="text-[10px] font-mono text-[#25D366] px-2 py-1 rounded bg-[#25D366]/10 border border-[#25D366]/30 shrink-0 hidden sm:inline">
              12 MODALIDADES
            </span>
          </div>

          {/* Grid de 12 Modalidades de Treinamento */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {TRAINING_MODALITIES.map((mod) => (
              <div
                key={mod.id}
                onClick={() => handleOpenConfig(mod)}
                className="group p-5 rounded-2xl bg-[#0E151B] hover:bg-[#121B22] border border-[#1E2B35] hover:border-[#25D366]/50 transition-all duration-200 cursor-pointer flex flex-col justify-between space-y-4 shadow-sm hover:shadow-xl hover:shadow-[#25D366]/5 relative overflow-hidden"
              >
                {/* Glow on hover */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-[#25D366]/0 group-hover:bg-[#25D366]/10 rounded-full blur-xl transition-all pointer-events-none" />

                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl p-2 rounded-xl bg-[#141E26] border border-[#223340] group-hover:scale-105 transition-transform inline-block">
                      {mod.emoji}
                    </span>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-[#16222C] text-[#25D366] border border-[#233543]">
                      {mod.categoryTag}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-white group-hover:text-[#25D366] transition-colors">
                      {mod.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed line-clamp-3">
                      {mod.description}
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#18232B] flex items-center justify-between text-xs">
                  <span className="text-[11px] text-slate-500 font-medium">
                    {mod.skillsFocus.slice(0, 2).join(' • ')}
                  </span>
                  <div className="text-[#25D366] font-bold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    <span>Praticar</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};
