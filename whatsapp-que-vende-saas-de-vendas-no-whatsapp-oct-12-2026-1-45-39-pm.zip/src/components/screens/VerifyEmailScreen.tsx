import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Mail,
  CheckCircle,
  RefreshCw,
  LogOut,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  KeyRound,
  Info,
  Clock,
  Sparkles,
} from 'lucide-react';

interface VerifyEmailScreenProps {
  email?: string;
  onVerified?: () => void;
}

export const VerifyEmailScreen: React.FC<VerifyEmailScreenProps> = ({
  email: propEmail,
  onVerified,
}) => {
  const {
    user,
    currentSession,
    resendVerificationEmail,
    confirmEmailVerification,
    checkEmailServiceStatus,
    logout,
    showToast,
  } = useApp();

  const targetEmail = propEmail || user?.email || currentSession?.email || '';

  const [loadingResend, setLoadingResend] = useState(false);
  const [loadingConfirm, setLoadingConfirm] = useState(false);
  const [code, setCode] = useState('');
  const [feedback, setFeedback] = useState<{
    message: string;
    type: 'success' | 'error' | 'info';
  } | null>(null);

  // Email service health and cooldown states
  const [emailServiceConfigured, setEmailServiceConfigured] = useState<boolean | null>(null);
  const [resendCooldown, setResendCooldown] = useState<number>(0);

  // Resend Sandbox detection states
  const [sandboxRestricted, setSandboxRestricted] = useState(
    !!currentSession?.isResendSandboxRestricted
  );
  const [sandboxOwnerEmail, setSandboxOwnerEmail] = useState(
    currentSession?.sandboxOwnerEmail || 'valdineigvendas@gmail.com'
  );
  const [sandboxCode, setSandboxCode] = useState<string | null>(
    currentSession?.sandboxCode || null
  );

  // Check email service status on mount
  useEffect(() => {
    checkEmailServiceStatus().then((status) => {
      setEmailServiceConfigured(status.configured);
    });
  }, [checkEmailServiceStatus]);

  // Sync session sandbox state
  useEffect(() => {
    if (currentSession?.isResendSandboxRestricted) {
      setSandboxRestricted(true);
      if (currentSession.sandboxOwnerEmail) setSandboxOwnerEmail(currentSession.sandboxOwnerEmail);
      if (currentSession.sandboxCode) setSandboxCode(currentSession.sandboxCode);
    }
  }, [currentSession]);

  // Cooldown countdown timer
  useEffect(() => {
    if (resendCooldown <= 0) return;
    const interval = setInterval(() => {
      setResendCooldown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [resendCooldown]);

  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Only accept numeric digits, maximum 6 characters
    const clean = e.target.value.replace(/\D/g, '').slice(0, 6);
    setCode(clean);
    if (feedback?.type === 'error') {
      setFeedback(null);
    }
  };

  const handleResend = async () => {
    if (!targetEmail || resendCooldown > 0) return;
    setLoadingResend(true);
    setFeedback(null);
    try {
      const result = await resendVerificationEmail(targetEmail);
      if (result.isResendSandboxRestricted) {
        setSandboxRestricted(true);
        if (result.sandboxOwnerEmail) setSandboxOwnerEmail(result.sandboxOwnerEmail);
        if (result.sandboxCode) setSandboxCode(result.sandboxCode);
        setFeedback({
          message:
            'Aviso de Modo Sandbox: O servidor de envio (Resend) está sem domínio verificado e só entrega na conta dona (' +
            (result.sandboxOwnerEmail || 'valdineigvendas@gmail.com') +
            '). Utilize o código de teste abaixo ou verifique seu domínio em resend.com/domains.',
          type: 'info',
        });
        showToast('Resend Sandbox: domínio pendente', 'info');
        setResendCooldown(15);
      } else if (result.success && result.delivered) {
        setFeedback({
          message:
            'Novo código de verificação enviado com sucesso para seu e-mail! Verifique sua caixa de entrada e spam.',
          type: 'success',
        });
        showToast('Novo código enviado com sucesso!', 'success');
        setResendCooldown(30);
      } else if (!result.delivered) {
        setFeedback({
          message:
            result.message ||
            result.error ||
            'Não foi possível enviar o e-mail. Verifique a configuração do servidor SMTP.',
          type: 'error',
        });
      } else {
        setFeedback({
          message: result.error || 'Erro ao processar o reenvio de código.',
          type: 'error',
        });
      }
    } catch {
      setFeedback({
        message: 'Falha de comunicação com o servidor ao tentar reenviar o código.',
        type: 'error',
      });
    } finally {
      setLoadingResend(false);
    }
  };

  const handleConfirm = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!targetEmail) return;

    const trimmedCode = code.trim();
    if (!trimmedCode) {
      setFeedback({
        message: 'Por favor, digite o código de 6 dígitos enviado para seu e-mail.',
        type: 'error',
      });
      return;
    }

    if (trimmedCode.length !== 6) {
      setFeedback({
        message: 'O código de confirmação deve conter exatamente 6 números.',
        type: 'error',
      });
      return;
    }

    setLoadingConfirm(true);
    setFeedback(null);
    try {
      const result = await confirmEmailVerification(targetEmail, trimmedCode);
      if (result.success) {
        setFeedback({
          message: 'Código confirmado com sucesso! Redirecionando para o aplicativo...',
          type: 'success',
        });
        showToast('E-mail verificado com sucesso! 🎉', 'success');
        if (onVerified) onVerified();
      } else {
        setFeedback({
          message:
            result.error ||
            'Código de confirmação incorreto. Verifique os 6 dígitos e tente novamente.',
          type: 'error',
        });
      }
    } catch {
      setFeedback({
        message: 'Erro ao validar confirmação de e-mail.',
        type: 'error',
      });
    } finally {
      setLoadingConfirm(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070B0E] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#25D366]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10">
        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#25D366] text-[#0A1014] shadow-xl shadow-[#25D366]/20 mb-3 font-black text-2xl">
            W
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            WhatsApp <span className="text-[#25D366]">que Vende</span>
          </h1>
        </div>

        {/* Card Box */}
        <div className="bg-[#0D1419] border border-[#1F2C34] py-8 px-6 shadow-2xl rounded-2xl sm:px-10 space-y-6">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#15251C] text-[#25D366] border border-[#25D366]/30 mb-1">
              <KeyRound className="w-6 h-6 text-[#25D366]" />
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Verifique seu E-mail
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              Enviamos um código de verificação de <strong>6 dígitos</strong> para:
            </p>
            <div className="inline-block bg-[#121A21] border border-[#22303C] px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold text-[#25D366] max-w-full truncate">
              {targetEmail || 'seu e-mail'}
            </div>
            <p className="text-[11px] text-slate-400 pt-1">
              Insira o código de 6 dígitos recebido para desbloquear todos os treinamentos e recursos.
            </p>
          </div>

          {/* Feedback alerts */}
          {feedback && (
            <div
              className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 transition-all ${
                feedback.type === 'success'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : feedback.type === 'info'
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                  : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
              }`}
            >
              {feedback.type === 'success' ? (
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              ) : feedback.type === 'info' ? (
                <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              )}
              <span className="leading-relaxed">{feedback.message}</span>
            </div>
          )}

          {/* Resend Sandbox Notice Card */}
          {sandboxRestricted && (
            <div className="bg-[#121E28] border border-amber-500/30 rounded-xl p-3.5 space-y-2.5 text-xs text-slate-200">
              <div className="flex items-center gap-2 text-amber-300 font-bold">
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Resend Sandbox Ativo</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                A conta Resend está no plano de testes sem domínio próprio verificado. Nesse modo, a Resend só despacha e-mails reais para a conta dona (<strong>{sandboxOwnerEmail}</strong>).
              </p>
              {sandboxCode && (
                <div className="bg-[#0A1014] border border-amber-500/30 rounded-lg p-2.5 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-semibold">Código para validação de teste:</span>
                    <span className="font-mono font-black text-amber-300 text-lg tracking-widest">{sandboxCode}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setCode(sandboxCode);
                      showToast('Código inserido!', 'success');
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-amber-400 text-[#0A1014] font-bold text-xs hover:bg-amber-300 transition-colors cursor-pointer flex items-center gap-1 shadow"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Inserir Código</span>
                  </button>
                </div>
              )}
              <p className="text-[10px] text-slate-400 leading-relaxed pt-0.5">
                💡 <strong>Para entregar para qualquer cliente em produção:</strong> Acesse{' '}
                <a
                  href="https://resend.com/domains"
                  target="_blank"
                  rel="noreferrer"
                  className="text-[#25D366] underline font-semibold"
                >
                  resend.com/domains
                </a>
                , adicione e verifique seu domínio próprio, ou configure o SMTP do Gmail (com Senha de App) nas variáveis de ambiente.
              </p>
            </div>
          )}

          {/* Verification Code Form */}
          <form onSubmit={handleConfirm} className="space-y-4 pt-1">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2 text-center">
                Código de 6 Dígitos <span className="text-rose-400">*</span>
              </label>

              <div className="relative">
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={code}
                  onChange={handleCodeChange}
                  placeholder="000000"
                  maxLength={6}
                  autoComplete="one-time-code"
                  className="w-full bg-[#121920] border-2 border-[#202C36] focus:border-[#25D366] rounded-xl px-4 py-3 text-2xl font-black font-mono text-center tracking-[0.4em] text-white placeholder-slate-600 focus:outline-none transition-colors shadow-inner"
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 px-1">
                <span>Dígitos: {code.length}/6</span>
                <span className={code.length === 6 ? 'text-[#25D366] font-semibold' : 'text-slate-500'}>
                  {code.length === 6 ? '✓ Pronto para validar' : 'Insira 6 números'}
                </span>
              </div>
            </div>

            <button
              type="submit"
              disabled={loadingConfirm || code.trim().length !== 6}
              className="w-full py-3.5 px-4 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] disabled:opacity-40 disabled:cursor-not-allowed text-[#0A1014] font-extrabold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#25D366]/20 cursor-pointer"
            >
              {loadingConfirm ? (
                <span>Validando código...</span>
              ) : (
                <>
                  <span>Confirmar Código e Acessar</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Real Email Delivery Information Card */}
          <div className="bg-[#101920] border border-[#1E2E3C] p-3.5 rounded-xl text-[11px] text-slate-300 space-y-2">
            <div className="flex items-center gap-1.5 font-semibold text-slate-200">
              <Mail className="w-3.5 h-3.5 text-[#25D366] shrink-0" />
              <span>Orientações de recebimento:</span>
            </div>
            <ul className="text-slate-400 leading-relaxed list-disc list-inside space-y-1">
              <li>O código é enviado para sua caixa de entrada.</li>
              <li>Caso não localize em 1 minuto, confira a pasta de <strong>Spam / Lixo Eletrônico</strong> ou <strong>Promoções</strong>.</li>
              <li>O código é de uso único e possui validade de 30 minutos.</li>
            </ul>

            {emailServiceConfigured === false && (
              <div className="mt-2 pt-2 border-t border-[#1F2C34] text-[11px] text-amber-300 flex items-start gap-1.5">
                <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
                <span>
                  Configure as variáveis de ambiente SMTP no backend para envio real dos e-mails.
                </span>
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="pt-2 border-t border-[#1F2C34] flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              disabled={loadingResend || resendCooldown > 0}
              onClick={handleResend}
              className="w-full sm:w-auto text-xs text-slate-300 hover:text-[#25D366] disabled:opacity-50 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg hover:bg-slate-800/40 transition-colors cursor-pointer"
            >
              {resendCooldown > 0 ? (
                <>
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Aguarde {resendCooldown}s para reenviar</span>
                </>
              ) : (
                <>
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingResend ? 'animate-spin text-[#25D366]' : ''}`} />
                  <span>{loadingResend ? 'Reenviando...' : 'Reenviar código por e-mail'}</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={logout}
              className="w-full sm:w-auto text-xs text-slate-400 hover:text-rose-400 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg hover:bg-rose-500/10 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Voltar para login</span>
            </button>
          </div>

          <div className="text-center pt-1">
            <div className="inline-flex items-center gap-1 text-[11px] text-slate-500">
              <ShieldCheck className="w-3.5 h-3.5 text-[#25D366]" />
              <span>Proteção e validação de segurança com código criptografado</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
