import { AttendanceSituation } from '../types';

export const VEHICLES_FAO_SITUATIONS: AttendanceSituation[] = [
  {
    id: 'fao-veh-1',
    number: 1,
    title: 'Cliente pergunta apenas o preço ("Quanto tá? / Menor valor?")',
    stageName: 'Filtro e Acolhimento Imediato',
    description: 'Quando o lead chega pelo anúncio (Webmotors, OLX, Instagram) e manda mensagem seca: "Qual o valor?", "Quanto tá?", "Menor à vista?".',
    faoPillar: 'Filtro (F)',
    iconName: 'BadgeDollarSign',
    options: [
      {
        id: 'opt-veh-1-1',
        title: 'Opção 1: Confirmação do Valor + Pergunta de Uso (Acolhedor & Consultivo)',
        tone: 'Consultivo',
        text: `Olá, [Nome]! Tudo bem? Aqui é o [Seu Nome] da [Nome da Loja].

Ele está anunciado por [Valor do Veículo], impecável, periciado e com laudo cautelar 100% aprovado!

Só para eu te passar a melhor condição: você busca esse carro mais para o uso no dia a dia da família, viagens ou para trabalhar?`,
        whenToUse: 'Ideal para 90% dos contatos que perguntam o preço logo na primeira mensagem.',
        whyItWorks: 'Informa o preço com transparência e imediatamente faz uma pergunta de qualificação sobre a rotina de uso, impedindo que a conversa morra no preço.',
        faoPillar: 'Filtro (F)',
      },
      {
        id: 'opt-veh-1-2',
        title: 'Opção 2: Para quem perguntou "Qual o menor valor à vista?"',
        tone: 'Persuasivo',
        text: `Fala, [Nome]! Tudo ótimo por aqui.

Esse [Modelo do Carro] está muito novo e com preço super competitivo no mercado. Consigo sentar com o meu gerente para brigar pelo seu melhor número sim!

Me conta: você pretende fazer o pagamento 100% à vista no Pix, vai utilizar financiamento ou tem algum veículo usado para entrar na troca?`,
        whenToUse: 'Quando o cliente pede desconto ou "menor valor" logo de cara.',
        whyItWorks: 'Demonstra disposição para negociar, mas condiciona a flexibilidade à forma de pagamento e se há usado envolvido antes de dar desconto solto.',
        faoPillar: 'Filtro (F)',
      },
    ],
  },
  {
    id: 'fao-veh-2',
    number: 2,
    title: 'Cliente compara o veículo com o de outra loja ("Lá está mais barato")',
    stageName: 'Alinhamento de Valor e Procedência',
    description: 'O cliente diz que encontrou o mesmo modelo e ano por R$ 3.000 ou R$ 5.000 a menos em outra loja ou particular.',
    faoPillar: 'Alinhamento (A)',
    iconName: 'Scale',
    options: [
      {
        id: 'opt-veh-2-1',
        title: 'Opção 1: Valorização da Cautelar e Histórico de Manutenção',
        tone: 'Consultivo',
        text: `Faz todo sentido você comparar, [Nome]! Na internet realmente tem de tudo.

A grande diferença é que o nosso veículo é de procedência garantida: laudo cautelar 100% aprovado, sem histórico de leilão, sem batida estrutural e com revisão preventiva feita (pneus, freios e suspensão).

O outro que você viu já possui laudo cautelar aprovado e garantia de motor e câmbio por escrito na nota fiscal?`,
        whenToUse: 'Quando o cliente tenta baixar seu preço usando anúncio de concorrente ou particular.',
        whyItWorks: 'Não ataca a concorrência. Ensina o cliente a auditar o risco do carro mais barato (batido, leilão, pneu careca, revisão pendente).',
        faoPillar: 'Alinhamento (A)',
      },
    ],
  },
  {
    id: 'fao-veh-3',
    number: 3,
    title: 'Cliente considera o preço elevado ("Achei caro / Acima da FIPE")',
    stageName: 'Ancoragem de Opcionais e Conservação',
    description: 'O comprador alega que o preço pedido está acima da tabela FIPE ou de sua expectativa financeira.',
    faoPillar: 'Alinhamento (A)',
    iconName: 'AlertCircle',
    options: [
      {
        id: 'opt-veh-3-1',
        title: 'Opção 1: Reenquadre FIPE x Estado de Conservação Real',
        tone: 'Empático',
        text: `Compreendo perfeitamente, [Nome]. A tabela FIPE é uma média de mercado que inclui carros bem gastos, frotas e carros sem histórico.

O nosso exemplar é diferenciado: [Citar opcionais: bancos em couro / multimídia / baixa quilometragem / único dono], com 4 pneus novos e estepe sem uso. Um carro que você pega e não gasta 1 real na oficina.

Além do investimento, o modelo e os opcionais dele atenderam exatamente o que você procura?`,
        whenToUse: 'Quando o cliente joga a FIPE contra a sua margem de venda.',
        whyItWorks: 'Isola a objeção: se o cliente amar o carro, o diferencial de preço é facilmente absorvido na parcela ou na segurança de não gastar em oficina.',
        faoPillar: 'Alinhamento (A)',
      },
    ],
  },
  {
    id: 'fao-veh-4',
    number: 4,
    title: 'Cliente que quer dar um carro usado na troca ("Avalia o meu?")',
    stageName: 'Qualificação do Usado e Convite para Avaliação',
    description: 'O lead tem um carro para dar como entrada e pergunta: "Quanto vocês pagam no meu Ford Ka 2018?".',
    faoPillar: 'Filtro (F)',
    iconName: 'RotateCcw',
    options: [
      {
        id: 'opt-veh-4-1',
        title: 'Opção 1: Coleta de Dados Básicos + Convite para Avaliação Presencial Justa',
        tone: 'Consultivo',
        text: `Pegamos o seu usado sim, [Nome]! Aceitamos na troca com uma das melhores avaliações da região.

Para eu puxar uma prévia com o nosso avaliador, me manda aqui:
1. Qual o ano, modelo exato e versão?
2. Quantos km ele está marcando?
3. Câmbio manual ou automático?

Se tiver umas 4 fotos dele por fora e por dentro, manda aqui que já te passo uma estimativa realista!`,
        whenToUse: 'Quando o cliente pergunta o valor do usado pelo WhatsApp.',
        whyItWorks: 'Demonstra receptividade, organiza a coleta de informações e evita dar um valor seco que depois frustre o cliente pessoalmente.',
        faoPillar: 'Filtro (F)',
      },
      {
        id: 'opt-veh-4-2',
        title: 'Opção 2: Convite com Test-Drive Duplo na Loja',
        tone: 'Persuasivo',
        text: `[Nome], para conseguirmos a avaliação máxima no seu carro, o melhor caminho é você trazer ele aqui na loja para um café.

Enquanto nosso avaliador checa a pintura e mecânica para te pagar o melhor valor possível, você já faz o test-drive no [Carro de Interesse]!

Prefere dar um pulo aqui hoje à tarde por volta das 16h ou amanhã pela manhã?`,
        whenToUse: 'Quando o cliente mora na mesma cidade e está com pressa de fechar.',
        whyItWorks: 'Tira o cliente do WhatsApp e coloca ele dentro da loja física fazendo test-drive, aumentando em 80% a chance de fechamento.',
        faoPillar: 'Objeção & Agendamento (O)',
      },
    ],
  },
  {
    id: 'fao-veh-5',
    number: 5,
    title: 'Cliente pergunta sobre financiamento ("Quanto fica a parcela? / Qual a entrada?")',
    stageName: 'Simulação Segura sem Inventar Taxas',
    description: 'Lead pergunta sobre financiamento bancário pelo WhatsApp.',
    faoPillar: 'Filtro (F)',
    iconName: 'Calculator',
    options: [
      {
        id: 'opt-veh-5-1',
        title: 'Opção 1: Simulação Personalizada via CPF sem Comprometimento',
        tone: 'Consultivo',
        text: `Trabalhamos com os principais bancos (Santander, Itaú, BV, Bradesco e Safra) para buscar a menor taxa e a parcela mais confortável para você, [Nome]!

A parcela depende do seu score e do valor que você deseja dar de entrada (a partir de R$ 0 ou com seu usado).

Você tem em mente dar quanto de entrada aproximadamente? Se quiser me passar seu CPF e data de nascimento, já rodo uma simulação oficial agora sem compromisso!`,
        whenToUse: 'Quando o cliente quer saber parcelas e condições de financiamento.',
        whyItWorks: 'Explica com transparência que taxas dependem de score e entrada bancária real, capturando os dados para simulação sem inventar parcelas fictícias.',
        faoPillar: 'Filtro (F)',
      },
    ],
  },
  {
    id: 'fao-veh-6',
    number: 6,
    title: 'Dúvidas sobre documentação, garantia ou procedência / laudo cautelar',
    stageName: 'Construção de Segurança Absoluta',
    description: 'Cliente com receio de carro de leilão, sinistro, multas atrasadas ou motor com vício oculto.',
    faoPillar: 'Alinhamento (A)',
    iconName: 'ShieldCheck',
    options: [
      {
        id: 'opt-veh-6-1',
        title: 'Opção 1: Envio de Prova Social e Transparência Total',
        tone: 'Consultivo',
        text: `Compreendo total sua preocupação, [Nome]! Comprar carro exige segurança máxima.

Aqui nós garantimos:
✅ Laudo Cautelar 100% Aprovado (sem histórico de leilão, furto ou batida estrutural).
✅ Documentação 2026 totalmente em dia e quitada, pronta para transferir no seu nome.
✅ Garantia formal de 90 dias de motor e câmbio em contrato.

Se você quiser, te mando uma foto do laudo cautelar dele agora por aqui para você conferir com seus próprios olhos! Quer que eu te mande?`,
        whenToUse: 'Quando o comprador demonstra desconfiança ou medo de cair em golpe.',
        whyItWorks: 'Desarma qualquer dúvida oferecendo a documentação aberta na hora, gerando autoridade e credibilidade inabaláveis.',
        faoPillar: 'Alinhamento (A)',
      },
    ],
  },
  {
    id: 'fao-veh-7',
    number: 7,
    title: 'Cliente que deseja uma parcela menor ("Ficou pesado no mês")',
    stageName: 'Engenharia Financeira sem Perder a Venda',
    description: 'Após a simulação, o cliente achou a parcela de R$ 1.800 muito alta e seu orçamento é de R$ 1.300.',
    faoPillar: 'Alinhamento (A)',
    iconName: 'DollarSign',
    options: [
      {
        id: 'opt-veh-7-1',
        title: 'Opção 1: Ajuste de Prazo, Entrada Facilitada ou Opção de Modelo Irmão',
        tone: 'Consultivo',
        text: `Entendo perfeitamente, [Nome]. A parcela precisa caber com folga no seu orçamento sem apertar seu mês.

Nós temos 3 alternativas inteligentes para baixar essa parcela para o que você planejou:
1. Estender o prazo de 48x para 60x para diluir a parcela.
2. Parcelar uma complementação de entrada no cartão de crédito em até 18x.
3. Te apresentar uma versão ou modelo similar tão bom quanto este, mas que encaixe certinho no valor de parcela que você busca.

Qual dessas alternativas você prefere que eu recalcule agora para você?`,
        whenToUse: 'Quando a parcela ficou acima da capacidade de pagamento do cliente.',
        whyItWorks: 'Apresenta soluções práticas de crédito ou adequação de produto, mantendo a conversa quente em direção ao fechamento.',
        faoPillar: 'Alinhamento (A)',
      },
    ],
  },
  {
    id: 'fao-veh-8',
    number: 8,
    title: 'Cliente com interesse que não agenda visita nem test-drive',
    stageName: 'Chamada com Escassez Real e Agendamento Confortável',
    description: 'O cliente tirou dúvidas, gostou das fotos e vídeos, mas fica enrolando para ir até a loja física.',
    faoPillar: 'Objeção & Agendamento (O)',
    iconName: 'Clock',
    options: [
      {
        id: 'opt-veh-8-1',
        title: 'Opção 1: Reserva de Veículo para Test-Drive sem Compromisso',
        tone: 'Persuasivo',
        text: `[Nome], esse modelo está tendo bastante procura essa semana porque o estado dele é impecável.

Carro a gente precisa sentar ao volante, sentir o motor e ver de perto para ter certeza.

Para não correr o risco de outro cliente fechar antes de você ver, eu posso deixar ele reservado aqui no pátio para o seu test-drive hoje às 17h ou amanhã às 10h. Qual horário fica melhor para você?`,
        whenToUse: 'Lead qualificado que fica cozinhando no WhatsApp.',
        whyItWorks: 'Usa escassez natural do estoque e oferece uma escolha binária simples de horário, facilitando o sim.',
        faoPillar: 'Objeção & Agendamento (O)',
      },
    ],
  },
  {
    id: 'fao-veh-9',
    number: 9,
    title: 'Cliente que visitou a loja e não concluiu ("Vou pensar / Falar com a esposa")',
    stageName: 'Follow-up de Pós-Visita e Desempate de Decisão',
    description: 'O cliente fez test-drive, gostou, mas foi embora sem assinar a proposta dizendo que vai pensar.',
    faoPillar: 'Objeção & Agendamento (O)',
    iconName: 'MessageSquare',
    options: [
      {
        id: 'opt-veh-9-1',
        title: 'Opção 1: Acolhimento da Decisão Compartilhada com Benefício Adicional',
        tone: 'Consultivo',
        text: `Oi, [Nome]! Foi um grande prazer receber você aqui na loja hoje para o test-drive!

Imagino que você esteja conversando com sua esposa sobre a decisão. Carro para a família tem que ser aprovado por todos mesmo!

Para ajudar vocês: conversei com a diretoria e consegui segurar [Transferência grátis / 1 ano de garantia / Primeira parcela para 60 dias] caso confirmemos a proposta até amanhã às 12h.

Ficou algum ponto que ela queira tirar dúvida ou quer que eu grave um vídeo dos detalhes internos para ela ver?`,
        whenToUse: 'Dentro de 24h após a visita na loja física.',
        whyItWorks: 'Respeita o processo familiar, coloca um benefício concreto na mesa com prazo limite e oferece suporte em vídeo.',
        faoPillar: 'Objeção & Agendamento (O)',
      },
    ],
  },
  {
    id: 'fao-veh-10',
    number: 10,
    title: 'Cliente que parou de responder no WhatsApp (Lead Frio / Sumido)',
    stageName: 'Reativação com Novidade e Saída Honrosa',
    description: 'O cliente visualizou as fotos ou a simulação há 2 ou 3 dias e não disse mais nada.',
    faoPillar: 'Objeção & Agendamento (O)',
    iconName: 'Sparkles',
    options: [
      {
        id: 'opt-veh-10-1',
        title: 'Opção 1: Pergunta Direta com Saída Elegante',
        tone: 'Empático',
        text: `Oi, [Nome]! Tudo bem?

Imagino que sua semana esteja super corrida! Lembrei de você porque liberou uma condição bem diferenciada para a entrega desse [Modelo do Carro] hoje.

Só para eu atualizar meus atendimentos por aqui: você ainda tem interesse em ver essa opção ou prefere que eu pause seu contato por enquanto?`,
        whenToUse: 'Após 48h a 72h sem retorno do cliente.',
        whyItWorks: 'Dá ao cliente a liberdade de dizer "não", o que tira o peso da cobrança e faz 70% das pessoas responderem imediatamente justificando o sumiço.',
        faoPillar: 'Objeção & Agendamento (O)',
      },
    ],
  },
];
