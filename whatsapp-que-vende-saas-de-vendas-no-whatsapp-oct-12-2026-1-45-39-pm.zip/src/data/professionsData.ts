import { ProfessionNiche, ProfessionCategory, ProfessionCategoryId } from '../types';
import { REAL_ESTATE_FAO_SITUATIONS } from './realEstateAttendanceData';
import { VEHICLES_FAO_SITUATIONS } from './vehiclesAttendanceData';

export const ALL_PROFESSION_CATEGORIES: ProfessionCategory[] = [
  // 1. VEÍCULOS
  {
    id: 'veiculos',
    title: 'Veículos & Automotivo',
    emoji: '🚗',
    description: 'Carros novos, seminovos, motos, caminhões e consórcios automotivos.',
    professions: [
      {
        id: 'vendedor-carros-seminovos',
        name: 'Vendedor de Carros Usados e Seminovos',
        icon: 'Car',
        badge: 'Destaque',
        categoryId: 'veiculos',
        description: 'Venda de seminovos, avaliação de usados na troca, financiamento e laudo cautelar aprovado.',
        commonObjection: '"Achei acima da FIPE / Concorrente tem mais barato"',
        typicalTicket: 'R$ 45.000 - R$ 160.000',
        attendanceSituations: VEHICLES_FAO_SITUATIONS,
        aiContext: {
          roleDescription: 'Vendedor de carros usados e seminovos em concessionária ou loja multimarcas. Foco em qualificar uso do cliente (família, trabalho, lazer), valorizar laudo cautelar e procedência, e agendar test-drive.',
          typicalObjections: [
            'Cliente que pergunta apenas o preço e para de responder',
            'Compara o carro com o de outra loja que está mais barato',
            'Considera o preço alto comparado à tabela FIPE',
            'Quer dar o carro usado na troca e pede avaliação inflada',
            'Dúvidas sobre juros de financiamento e valor de parcela',
            'Receio de histórico de leilão, sinistro ou motor com defeito',
            'Quer parcela menor sem aumentar a entrada',
            'Tem interesse mas não agenda a visita na loja',
            'Visitou a loja, fez test-drive e disse que vai pensar',
            'Parou de responder após receber fotos ou simulação',
          ],
          discoveryQuestions: [
            'Você busca esse veículo mais para o uso no dia a dia da família ou trabalho?',
            'Hoje você já tem algum carro que pretende colocar na troca como entrada?',
            'Prefere pagar à vista ou fazer uma simulação de financiamento?',
            'Você prioriza economia de combustível ou espaço interno e conforto?',
          ],
          evaluationCriteria: [
            'Investigou o uso pretendido do veículo antes de jogar preços soltos?',
            'Valorizou procedência, laudo cautelar e garantia formal?',
            'Tratou a objeção de preço sem queimar margem de imediato?',
            'Conduziu com firmeza para um agendamento de test-drive na loja física?',
            'Não inventou taxas de juros irreais nem prometeu avaliação cega sem ressalvas?',
          ],
          recommendedTechniques: ['spin-selling', 'tratamento-objecoes', 'tecnicas-fechamento'],
        },
        sampleMessages: [
          {
            title: 'Qualificação inicial de uso do veículo',
            situation: 'Cliente perguntou se o carro está disponível e o valor.',
            text: 'Olá, [Nome]! Está disponível sim, 100% periciado com laudo cautelar aprovado e garantia de procedência! Só para eu te orientar da melhor forma: você busca esse modelo mais para viagens com a família ou para sua rotina de trabalho?',
            tip: 'Qualifica o perfil de uso e gera conexão humana antes de falar de números frios.',
          },
          {
            title: 'Convite para test-drive duplo com avaliação de usado',
            situation: 'Cliente quer avaliar o carro dele na troca.',
            text: '[Nome], conseguimos uma excelente avaliação no seu usado sim! Para conseguirmos o melhor valor com o nosso perito, que tal dar um pulo aqui na loja hoje à tarde? Enquanto avaliamos seu carro com carinho, você já dá uma volta e faz o test-drive no [Modelo do Carro]!',
            tip: 'Atrai o cliente para a loja física, onde a taxa de fechamento é 5x maior.',
          },
        ],
      },
      {
        id: 'vendedor-carros-novos',
        name: 'Vendedor de Carros Novos (Zero KM)',
        icon: 'Sparkles',
        categoryId: 'veiculos',
        description: 'Venda de veículos zero km em concessionárias, versões, opcionais e prazos de faturamento.',
        commonObjection: '"Prazo de entrega muito longo / IPVA grátis"',
        typicalTicket: 'R$ 80.000 - R$ 280.000',
        attendanceSituations: VEHICLES_FAO_SITUATIONS,
        aiContext: {
          roleDescription: 'Consultor de vendas de veículos zero km em concessionária autorizada. Apresentação de versões, tecnologia embarcada, garantias de fábrica de 3 a 5 anos e bônus de fábrica.',
          typicalObjections: ['Prazo de espera para entrega', 'Comparação com versão de entrada', 'Pedido de bônus ou acessórios de cortesia'],
          discoveryQuestions: ['Qual versão você mais gostou?', 'Prefere pronta-entrega ou pedido de fábrica?', 'Pretende financiar pelo banco da montadora?'],
          evaluationCriteria: ['Explicou garantias de fábrica e tecnologia?', 'Conduziu para test-drive na concessionária?'],
          recommendedTechniques: ['venda-consultiva', 'aida', 'tecnicas-fechamento'],
        },
        sampleMessages: [
          {
            title: 'Diferença entre versões sem forçar a mais cara',
            situation: 'Cliente em dúvida entre versão básica e intermediária.',
            text: 'Oi, [Nome]! A versão intermediária se destaca principalmente pelos assistentes de segurança e central multimídia sem fio. Para quem roda bastante na cidade, traz muito mais conforto e valor de revenda futuro. Quer fazer o test-drive nas duas hoje para comparar?',
            tip: 'Postura de consultor que ajuda a escolher o melhor custo-benefício.',
          },
        ],
      },
      {
        id: 'vendedor-motos',
        name: 'Vendedor de Motos',
        icon: 'Bike',
        categoryId: 'veiculos',
        description: 'Motos urbanas, esportivas, scooters e modelos de alta cilindrada.',
        commonObjection: '"Parcela alta / Medo de aprovação de crédito"',
        typicalTicket: 'R$ 14.000 - R$ 75.000',
        aiContext: {
          roleDescription: 'Vendedor de motocicletas. Foco em economia de combustível, agilidade urbana ou lazer nos fins de semana.',
          typicalObjections: ['Entrada alta', 'Aprovação de crédito difícil', 'Custo do seguro'],
          discoveryQuestions: ['Você busca a moto para trabalho/aplicativo ou lazer?', 'Já tem habilitação categoria A?'],
          evaluationCriteria: ['Destacou economia e agilidade?', 'Simulou crédito com transparência?'],
          recommendedTechniques: ['spin-selling', 'tecnicas-fechamento'],
        },
        sampleMessages: [
          {
            title: 'Economia e agilidade para o dia a dia',
            situation: 'Cliente buscando moto para fugir do trânsito ou trabalhar.',
            text: 'E aí, [Nome]! Esse modelo faz mais de 38 km por litro — na prática, você economiza mais de R$ 400 por mês de combustível comparado a transporte público ou carro! Consigo simular com entrada facilitada no cartão. Posso puxar sua prévia no sistema?',
            tip: 'Fracione a economia mensal para justificar a parcela.',
          },
        ],
      },
      {
        id: 'vendedor-caminhoes',
        name: 'Vendedor de Caminhões & Veículos Comerciais',
        icon: 'Truck',
        categoryId: 'veiculos',
        description: 'Caminhões pesados, médios, VUCs, furgões e utilitários de carga.',
        commonObjection: '"Custo por km / Retorno do frete"',
        typicalTicket: 'R$ 120.000 - R$ 750.000',
        aiContext: {
          roleDescription: 'Vendedor B2B de caminhões e utilitários. Foco no cálculo de capacidade de carga, consumo por km, planos de manutenção e retorno sobre o investimento.',
          typicalObjections: ['Taxa de juros do BNDES/Finame', 'Disponibilidade de implemento rodoviário'],
          discoveryQuestions: ['Qual rota e tipo de carga você transporta?', 'Qual a capacidade em toneladas necessária?'],
          evaluationCriteria: ['Falou a linguagem do frete e produtividade?', 'Apresentou custo total de operação?'],
          recommendedTechniques: ['spin-selling', 'venda-consultiva'],
        },
        sampleMessages: [
          {
            title: 'Foco em produtividade e autonomia',
            situation: 'Autônomo ou frotista buscando renovar caminhão.',
            text: 'Olá, [Nome]! Esse modelo entrega a maior relação de torque com menor consumo de diesel na categoria, reduzindo o custo por km rodado nas suas viagens. Você já tem a rota e implemento definidos para esse veículo?',
            tip: 'Fale de retorno financeiro e confiabilidade de estrada.',
          },
        ],
      },
      {
        id: 'consorcio-veiculos',
        name: 'Consultor de Consórcios de Veículos',
        icon: 'PieChart',
        categoryId: 'veiculos',
        description: 'Cartas de crédito para carros, motos e pesados sem juros abusivos.',
        commonObjection: '"Demora para ser contemplado / Preciso do carro agora"',
        typicalTicket: 'R$ 30.000 - R$ 200.000',
        aiContext: {
          roleDescription: 'Consultor especialista em consórcio automotivo. Foco em planejamento sem juros, lance embutido, lance livre e estratégias reais de contemplação sem promessas falsas de sorteio imediato.',
          typicalObjections: ['Preciso do bem para ontem', 'Medo de pagar e não pegar a carta'],
          discoveryQuestions: ['Qual valor de veículo você planeja comprar?', 'Você tem algum recurso ou usado para ofertar de lance?'],
          evaluationCriteria: ['Transparência absoluta sem prometer data de contemplação?', 'Explicou funcionamento de lances?'],
          recommendedTechniques: ['venda-consultiva', 'spin-selling'],
        },
        sampleMessages: [
          {
            title: 'Consórcio x Financiamento sem juros abusivos',
            situation: 'Cliente quer comprar carro nos próximos meses sem pagar o dobro no financiamento.',
            text: 'Oi, [Nome]! Enquanto no financiamento você paga 2 carros para levar 1, no consórcio você paga taxa de administração justa e tem a estratégia de ofertar lance livre ou embutido para acelerar a contemplação. Qual valor de carta você tem em mente?',
            tip: 'Mostre a economia de dezenas de milhares de reais no médio prazo.',
          },
        ],
      },
    ],
  },

  // 2. IMÓVEIS
  {
    id: 'imoveis',
    title: 'Imóveis & Construção',
    emoji: '🏠',
    description: 'Corretores, loteamentos, lançamentos na planta, locação e imóveis prontos.',
    professions: [
      {
        id: 'corretor-imoveis',
        name: 'Corretor de Imóveis (Geral)',
        icon: 'Home',
        badge: 'Destaque',
        categoryId: 'imoveis',
        description: 'Venda de casas, apartamentos, visitas presenciais, financiamento habitacional e negociação.',
        commonObjection: '"Qual o valor? / Vou pensar e te aviso"',
        typicalTicket: 'R$ 220.000 - R$ 1.800.000',
        attendanceSituations: REAL_ESTATE_FAO_SITUATIONS,
        aiContext: {
          roleDescription: 'Corretor de imóveis consultivo. Foco em acolher, investigar perfil de moradia ou investimento, apresentar opções selecionadas e agendar visita presencial.',
          typicalObjections: ['Preço por metro quadrado', 'Taxa de condomínio alta', 'Indecisão entre bairros'],
          discoveryQuestions: ['Moradia da família ou investimento?', 'Quantos quartos e vagas são fundamentais?'],
          evaluationCriteria: ['Filtrou necessidades antes do preço?', 'Conduziu para agendamento de visita?'],
          recommendedTechniques: ['spin-selling', 'venda-consultiva', 'tecnicas-fechamento'],
        },
        sampleMessages: [
          {
            title: 'Qualificação de moradia vs investimento',
            situation: 'Lead vindo de anúncio no portal.',
            text: 'Olá, [Nome]! Tudo bem? Aqui é o [Seu Nome], corretor de imóveis. Já separei as fotos e a planta do imóvel. Só para eu te orientar com máxima precisão: você busca esse imóvel para moradia da família ou para investimento?',
            tip: 'Evita despejar PDF frio e abre diálogo imediato.',
          },
        ],
      },
      {
        id: 'vendedor-terrenos',
        name: 'Vendedor de Terrenos & Loteamentos',
        icon: 'MapPin',
        categoryId: 'imoveis',
        description: 'Lotes residenciais e comerciais em condomínio fechado ou bairros planejados.',
        commonObjection: '"Localização distante / Obras ainda não começaram"',
        typicalTicket: 'R$ 80.000 - R$ 450.000',
        aiContext: {
          roleDescription: 'Vendedor de lotes e terrenos. Foco em potencial de valorização futura, parcelamento direto com a loteadora e liberdade de construção.',
          typicalObjections: ['Distância do centro', 'Infraestrutura ainda em obras'],
          discoveryQuestions: ['Pretende construir de imediato ou segurar para valorização?'],
          evaluationCriteria: ['Demonstrou histórico de valorização da região?'],
          recommendedTechniques: ['aida', 'spin-selling'],
        },
        sampleMessages: [
          {
            title: 'Potencial de valorização com entrada parcelada',
            situation: 'Cliente interessado em lote em condomínio.',
            text: 'Oi, [Nome]! Os lotes estão com parcelamento direto com a loteadora, sem burocracia bancária. Quem compra na fase atual garante o metro quadrado com até 35% de valorização até a entrega. Prefere lote plano ou com vista mais alta?',
            tip: 'Estimule a visão de futuro e ganho patrimonial.',
          },
        ],
      },
      {
        id: 'vendedor-lancamentos',
        name: 'Vendedor de Lançamentos Imobiliários (Na Planta)',
        icon: 'Layers',
        categoryId: 'imoveis',
        description: 'Venda de apartamentos na planta com construtoras e incorporadoras.',
        commonObjection: '"Medo de atraso na obra / Entrada durante a obra pesada"',
        typicalTicket: 'R$ 280.000 - R$ 1.200.000',
        aiContext: {
          roleDescription: 'Especialista em lançamentos na planta. Apresentação de maquetes, decorados e fluxo de pagamento durante o período de obras.',
          typicalObjections: ['Correção de INCC durante a obra', 'Prazo de entrega em 3 anos'],
          discoveryQuestions: ['Qual fluxo mensal de pagamento fica confortável até as chaves?'],
          evaluationCriteria: ['Convidou para visitar o decorado?', 'Explicou fluxo de obras de forma simples?'],
          recommendedTechniques: ['aida', 'venda-consultiva'],
        },
        sampleMessages: [
          {
            title: 'Convite para conhecer o apartamento decorado',
            situation: 'Lead se cadastrou no lançamento.',
            text: 'Olá, [Nome]! O projeto do [Nome do Empreendimento] ficou incrível. O apartamento decorado está aberto para visitação exclusiva com vaga reservada. Você tem melhor disponibilidade amanhã às 15h ou sábado às 10h?',
            tip: 'Visitar o decorado gera desejo imediato de compra.',
          },
        ],
      },
      {
        id: 'consultor-locacao',
        name: 'Consultor de Locação Imobiliária',
        icon: 'Key',
        categoryId: 'imoveis',
        description: 'Locação rápida de imóveis residenciais e comerciais sem fiador.',
        commonObjection: '"Garantia locatícia exigente / Taxas extras"',
        typicalTicket: 'R$ 1.200 - R$ 6.000/mês',
        aiContext: {
          roleDescription: 'Consultor de locação. Foco em agilidade na análise de crédito, facilidade de garantia (seguro-fiança ou caução) e agendamento de visita.',
          typicalObjections: ['Exigência de comprovante de renda', 'Condomínio e IPTU altos'],
          discoveryQuestions: ['Para quando você precisa da mudança?', 'Tem pets ou precisa de mobília?'],
          evaluationCriteria: ['Agilidade máxima na resposta?', 'Clareza nas garantias aceitas?'],
          recommendedTechniques: ['aida', 'tecnicas-fechamento'],
        },
        sampleMessages: [
          {
            title: 'Visita rápida para locação sem burocracia',
            situation: 'Interessado em alugar imóvel pronto.',
            text: 'Olá, [Nome]! O imóvel está desocupado e liberado para visitação hoje mesmo. Aceitamos seguro-fiança digital aprovado em 15 minutos sem precisar de fiador. Quer agendar para ver hoje às 16h?',
            tip: 'Agilidade é o fator decisivo para quem está buscando locação.',
          },
        ],
      },
    ],
  },

  // 3. COMÉRCIO E VAREJO
  {
    id: 'comercio-varejo',
    title: 'Comércio & Varejo',
    emoji: '🛍️',
    description: 'Roupas, calçados, celulares, eletrônicos, móveis e produtos diversos.',
    professions: [
      {
        id: 'vendedor-roupas',
        name: 'Vendedor de Roupas e Acessórios',
        icon: 'ShoppingBag',
        categoryId: 'comercio-varejo',
        description: 'Moda feminina, masculina, infantil, moda praia e acessórios com fotos e provador.',
        commonObjection: '"Tem do meu tamanho? / Entrega hoje?"',
        typicalTicket: 'R$ 90 - R$ 450',
        aiContext: {
          roleDescription: 'Vendedor de moda pelo WhatsApp. Foco em enviar fotos no corpo, sugerir combinações (looks) e facilitar entrega/retirada.',
          typicalObjections: ['Dúvida de tamanho e caimento', 'Custo do frete'],
          discoveryQuestions: ['Qual tamanho você costuma vestir?', 'Procura algo casual ou para evento especial?'],
          evaluationCriteria: ['Sugeriu peças complementares (cross-sell)?', 'Criou senso de urgência com peças limitadas?'],
          recommendedTechniques: ['aida', 'tecnicas-fechamento'],
        },
        sampleMessages: [
          {
            title: 'Envio de opções de tamanho e caimento',
            situation: 'Cliente quer saber se veste bem.',
            text: 'Oi, [Nome]! Essa peça tem um caimento impecável e o tecido não amassa! Separei as fotos dela no corpo nos tamanhos M e G. Prefere que eu envie por aqui ou quer que eu separe no provador da loja para você experimentar hoje?',
            tip: 'Demonstre a peça no corpo para facilitar a visualização.',
          },
        ],
      },
      {
        id: 'vendedor-eletronicos',
        name: 'Vendedor de Celulares & Eletrônicos',
        icon: 'Smartphone',
        categoryId: 'comercio-varejo',
        description: 'iPhones, smartphones Android, notebooks, caixas de som e periféricos com garantia.',
        commonObjection: '"É original? / Tem garantia de quanto tempo?"',
        typicalTicket: 'R$ 800 - R$ 7.500',
        aiContext: {
          roleDescription: 'Vendedor de celulares e eletrônicos. Foco em garantia, procedência de aparelhos novos ou seminovos revisados e entrega segura.',
          typicalObjections: ['Saúde da bateria', 'Aparelho de vitrine ou recondicionado', 'Medo de golpe online'],
          discoveryQuestions: ['Qual modelo você usa atualmente?', 'Prioriza câmera de alta qualidade ou bateria de longa duração?'],
          evaluationCriteria: ['Passou segurança de procedência e garantia?', 'Apresentou opção de parcelamento clara?'],
          recommendedTechniques: ['venda-consultiva', 'tratamento-objecoes'],
        },
        sampleMessages: [
          {
            title: 'Procedência garantida e nota fiscal',
            situation: 'Cliente com receio sobre a originalidade do aparelho.',
            text: 'Oi, [Nome]! Nossos aparelhos são 100% originais, homologados pela Anatel, com nota fiscal e garantia de 1 ano. Entregamos em mãos com teste na hora antes de você pagar. Qual capacidade de memória você prefere: 128GB ou 256GB?',
            tip: 'A opção de pagar após conferir destrói qualquer desconfiança.',
          },
        ],
      },
      {
        id: 'vendedor-moveis',
        name: 'Vendedor de Móveis & Eletrodomésticos',
        icon: 'Armchair',
        categoryId: 'comercio-varejo',
        description: 'Sofás, camas, guarda-roupas, cozinhas planejadas e eletros com frete e montagem.',
        commonObjection: '"O frete e montagem estão inclusos?"',
        typicalTicket: 'R$ 600 - R$ 6.500',
        aiContext: {
          roleDescription: 'Vendedor de móveis. Foco em medidas exatas do ambiente, conforto, durabilidade da estrutura e facilidade de entrega/montagem.',
          typicalObjections: ['Medo de não caber no cômodo', 'Prazo de montagem longo'],
          discoveryQuestions: ['Qual a medida aproximada da sua sala/quarto?', 'Prefere tecido impermeável ou suede toque macio?'],
          evaluationCriteria: ['Perguntou as medidas do espaço?', 'Esclareceu frete e montagem?'],
          recommendedTechniques: ['spin-selling', 'venda-consultiva'],
        },
        sampleMessages: [
          {
            title: 'Verificação de medidas do ambiente',
            situation: 'Cliente interessado em sofá retrátil.',
            text: 'Olá, [Nome]! Esse modelo tem molas ensacadas e espuma D33, super aconchegante! Ele tem 2,30m de largura. Para garantir que vai ficar perfeito na sua sala, você tem o espaço medido aí para checarmos juntos?',
            tip: 'Cuidar das medidas evita devoluções e gera autoridade.',
          },
        ],
      },
    ],
  },

  // 4. BELEZA E ESTÉTICA
  {
    id: 'beleza-estetica',
    title: 'Beleza & Estética',
    emoji: '✂️',
    description: 'Barbearias, cabeleireiros, manicures, esteticistas, clínicas e profissionais autônomos.',
    professions: [
      {
        id: 'barbeiro',
        name: 'Barbeiro / Barbearia',
        icon: 'Scissors',
        categoryId: 'beleza-estetica',
        description: 'Cortes masculinos, barba terapia, químicas e combos de final de semana.',
        commonObjection: '"Tem vaga agora? / Quanto é o corte com barba?"',
        typicalTicket: 'R$ 50 - R$ 130',
        aiContext: {
          roleDescription: 'Barbeiro profissional. Foco em horários agendados sem atrasos, combos de barba + cabelo e mensagens de retorno para clientes sumidos.',
          typicalObjections: ['Fila de espera', 'Preço acima da barbearia de bairro simples'],
          discoveryQuestions: ['Prefere horário hoje no fim da tarde ou amanhã?'],
          evaluationCriteria: ['Ofereceu duas opções objetivas de horário?'],
          recommendedTechniques: ['aida', 'tecnicas-fechamento'],
        },
        sampleMessages: [
          {
            title: 'Duas opções de horário para preencher a grade',
            situation: 'Cliente quer saber se tem vaga.',
            text: 'E aí, [Nome]! Beleza? Para hoje estamos com as últimas vagas. Você prefere encaixar seu horário às 17h30 ou às 19h para dar aquele talento no visual?',
            tip: 'Ofereça dois horários exatos para preencher buracos na agenda.',
          },
        ],
      },
      {
        id: 'manicure',
        name: 'Manicure & Lash Designer',
        icon: 'Sparkles',
        categoryId: 'beleza-estetica',
        description: 'Alongamento em fibra, esmaltação em gel, extensão de cílios e spa dos pés.',
        commonObjection: '"Tem que pagar sinal antes para marcar?"',
        typicalTicket: 'R$ 80 - R$ 220',
        aiContext: {
          roleDescription: 'Manicure e extensionista de cílios. Foco em durabilidade do procedimento, biossegurança (autoclave) e cobrança de sinal para evitar faltas.',
          typicalObjections: ['Resistência ao pagamento de sinal antecipado'],
          discoveryQuestions: ['Prefere horário antes do fim de semana?'],
          evaluationCriteria: ['Explicou o sinal com naturalidade e acolhimento?'],
          recommendedTechniques: ['venda-consultiva', 'tecnicas-fechamento'],
        },
        sampleMessages: [
          {
            title: 'Explicação elegante do sinal antecipado',
            situation: 'Cliente pergunta por que precisa pagar R$ 30 adiantado.',
            text: 'Oi, [Nome]! Para travar esse horário exclusivo de 2h na minha agenda só para você, solicitamos um sinal de R$ 30 que já é abatido no valor final. Posso gerar o Pix para garantir sua vaga de sábado?',
            tip: 'O sinal evita furos e valoriza seu tempo profissional.',
          },
        ],
      },
      {
        id: 'esteticista',
        name: 'Esteticista & Clínica de Estética',
        icon: 'Heart',
        categoryId: 'beleza-estetica',
        description: 'Limpeza de pele, botox, harmonização, drenagem linfática e protocolos corporais.',
        commonObjection: '"Quantas sessões são necessárias? / Dói?"',
        typicalTicket: 'R$ 200 - R$ 1.800',
        aiContext: {
          roleDescription: 'Esteticista ou biomédica. Foco em anamnese personalizada, produtos aprovados pela Anvisa, resultados graduais e seguros.',
          typicalObjections: ['Medo de dor ou reação alérgica', 'Comparação com clínicas populares'],
          discoveryQuestions: ['Qual é o seu principal incômodo na pele ou corpo hoje?'],
          evaluationCriteria: ['Investigou o histórico antes de passar protocolo genérico?'],
          recommendedTechniques: ['spin-selling', 'venda-consultiva'],
        },
        sampleMessages: [
          {
            title: 'Avaliação personalizada antes de prometer resultado',
            situation: 'Cliente quer saber se o procedimento vai tirar todas as manchas.',
            text: 'Olá, [Nome]! Cada pele responde de uma forma única. Para te indicar o protocolo com melhor custo e resultado duradouro, fazemos uma avaliação inicial com lâmpada especial. Você tem disponibilidade nesta quinta às 15h ou sexta às 10h?',
            tip: 'A avaliação presencial gera autoridade médica e estética.',
          },
        ],
      },
    ],
  },

  // 5. SERVIÇOS PROFISSIONAIS
  {
    id: 'servicos-profissionais',
    title: 'Serviços Profissionais',
    emoji: '💼',
    description: 'Consultores, marketing, fotógrafos, advogados, contadores e prestadores locais.',
    professions: [
      {
        id: 'advogado',
        name: 'Advogado / Escritório Jurídico',
        icon: 'Scale',
        categoryId: 'servicos-profissionais',
        description: 'Consultoria jurídica, contratos, causas trabalhistas, cíveis, tributárias e de família.',
        commonObjection: '"Quanto cobra para dar uma olhadinha no processo?"',
        typicalTicket: 'R$ 800 - R$ 8.500',
        aiContext: {
          roleDescription: 'Advogado. Atendimento com respeito ao código de ética da OAB, acolhimento da dúvida jurídica, agendamento de consulta inicial e diagnóstico do caso.',
          typicalObjections: ['Cobrança de consulta prévia', 'Ansiedade pelo resultado do processo'],
          discoveryQuestions: ['Já existe processo aberto ou notificação recebida?'],
          evaluationCriteria: ['Ética, discrição e clareza sobre etapas jurídicas?'],
          recommendedTechniques: ['venda-consultiva', 'spin-selling'],
        },
        sampleMessages: [
          {
            title: 'Agendamento de consulta para análise de documentos',
            situation: 'Cliente manda dúvida jurídica pelo WhatsApp.',
            text: 'Olá, [Nome]! Compreendo a urgência da sua situação. Questões como essa exigem análise minuciosa dos documentos para traçar a melhor estratégia de defesa. Podemos agendar uma consulta presencial ou por videoconferência nesta quarta às 14h para avaliar seu caso?',
            tip: 'Valorize o tempo da análise jurídica com discrição e postura.',
          },
        ],
      },
      {
        id: 'contador',
        name: 'Contador / BPO Financeiro',
        icon: 'Calculator',
        categoryId: 'servicos-profissionais',
        description: 'Abertura de empresas, assessoria fiscal, folha de pagamento e redução de tributos.',
        commonObjection: '"Meu contador atual cobra mais barato"',
        typicalTicket: 'R$ 350 - R$ 2.500/mês',
        aiContext: {
          roleDescription: 'Contador consultivo. Foco em planejamento tributário para pagar menos imposto dentro da lei, relatórios de gestão e atendimento humanizado sem burocracia.',
          typicalObjections: ['Preço de mensalidade'],
          discoveryQuestions: ['Qual é o faturamento mensal médio e regime tributário atual?'],
          evaluationCriteria: ['Demonstrou economia tributária em números claros?'],
          recommendedTechniques: ['spin-selling', 'venda-consultiva'],
        },
        sampleMessages: [
          {
            title: 'Diagnóstico tributário gratuito inicial',
            situation: 'Empresário insatisfeito com atendimento do contador atual.',
            text: 'Olá, [Nome]! Mais do que emitir guias, nosso papel é ajudar sua empresa a economizar impostos legalmente. Se você me enviar o extrato do Simples do último mês, faço uma revisão gratuita para ver se você não está pagando imposto duplicado. O que acha?',
            tip: 'Oferecer diagnóstico prévio gera valor imediato.',
          },
        ],
      },
      {
        id: 'designer-fotografo',
        name: 'Designer & Fotógrafo',
        icon: 'Camera',
        categoryId: 'servicos-profissionais',
        description: 'Ensaios fotográficos, cobertura de eventos, identidade visual e criação de marcas.',
        commonObjection: '"Só queria as fotos sem edição / Só um logotipo simples"',
        typicalTicket: 'R$ 450 - R$ 3.800',
        aiContext: {
          roleDescription: 'Designer ou fotógrafo. Foco em briefing visual, portfólio de projetos anteriores, entrega de arquivos em alta resolução e direitos de uso.',
          typicalObjections: ['Comparação com ferramentas automáticas (Canva)', 'Pedido de desconto em projetos autorais'],
          discoveryQuestions: ['Qual é o objetivo principal do ensaio ou da nova marca?'],
          evaluationCriteria: ['Apresentou portfólio relevante e escopo claro?'],
          recommendedTechniques: ['aida', 'venda-consultiva'],
        },
        sampleMessages: [
          {
            title: 'Apresentação de proposta com valor agregado e portfólio',
            situation: 'Cliente pedindo orçamento de ensaio corporativo.',
            text: 'Oi, [Nome]! Uma foto profissional transmite autoridade imediata para o seu perfil e atrai clientes de maior ticket. Nosso pacote inclui direção de poses guiada, tratamento de pele natural e entrega em 48h. Você prefere fotos em estúdio ou no seu próprio escritório?',
            tip: 'Elimina a vergonha do cliente dizendo que você guia todas as poses.',
          },
        ],
      },
    ],
  },

  // 6. VENDAS ONLINE E EMPREENDEDORISMO
  {
    id: 'vendas-online',
    title: 'Vendas Online & MEI',
    emoji: '🌐',
    description: 'Vendedores do Instagram, lojas virtuais, revendedores, MEIs e infoprodutos.',
    professions: [
      {
        id: 'vendedor-social',
        name: 'Vendedor pelo Instagram & WhatsApp',
        icon: 'MessageCircle',
        categoryId: 'vendas-online',
        description: 'Atendimento de leads que chegam pelo direct do Instagram, stories ou links de bio.',
        commonObjection: '"Frete muito caro / Vou deixar para depois"',
        typicalTicket: 'R$ 70 - R$ 380',
        aiContext: {
          roleDescription: 'Vendedor do comércio social. Foco em atendimento rápido antes que o lead esfrie, envio de chave Pix ou link de pagamento facilitado.',
          typicalObjections: ['Custo do frete comparado ao produto'],
          discoveryQuestions: ['Para qual CEP seria o envio?'],
          evaluationCriteria: ['Respondeu rápido e com entusiasmo comercial?'],
          recommendedTechniques: ['aida', 'tecnicas-fechamento'],
        },
        sampleMessages: [
          {
            title: 'Fechamento com chave Pix e frete facilitado',
            situation: 'Lead pediu informações do produto visto nos stories.',
            text: 'Oi, [Nome]! Que bom que gostou! Essa peça é campeã de vendas. Para o seu CEP consigo um frete fixo promocional de apenas R$ 12 com envio hoje mesmo. Se confirmar até às 14h, você já recebe o código de rastreio à tarde. Posso gerar o Pix para você?',
            tip: 'Crie facilidade máxima de pagamento na hora.',
          },
        ],
      },
      {
        id: 'revendedor',
        name: 'Revendedor (Cosméticos, Semijoias, Catálogo)',
        icon: 'Tag',
        categoryId: 'vendas-online',
        description: 'Revenda direta de produtos de beleza, perfumes, semijoias e catálogos.',
        commonObjection: '"Já compro com outra pessoa / Não tenho dinheiro agora"',
        typicalTicket: 'R$ 60 - R$ 320',
        aiContext: {
          roleDescription: 'Revendedor independente. Foco em relacionamento próximo, lembrete de datas comemorativas e novidades exclusivas de pronta-entrega.',
          typicalObjections: ['Falta de dinheiro imediato'],
          discoveryQuestions: ['É para você usar ou para presentear alguém especial?'],
          evaluationCriteria: ['Ofereceu amostra ou opção de pronta-entrega?'],
          recommendedTechniques: ['atendimento-relacionamento', 'aida'],
        },
        sampleMessages: [
          {
            title: 'Pronta-entrega exclusiva para presente',
            situation: 'Cliente precisa de algo rápido para o fim de semana.',
            text: 'Oi, [Nome]! Lembrei de você porque chegaram os kits especiais de presente com embalagem linda e pronta-entrega. Consigo deixar com você hoje à tarde sem custo de entrega. Quer dar uma olhadinha nas fotos dos kits?',
            tip: 'Pronta-entrega resolve urgências de presentes de última hora.',
          },
        ],
      },
    ],
  },

  // 7. VENDAS CONSULTIVAS
  {
    id: 'vendas-consultivas',
    title: 'Vendas Consultivas & Finanças',
    emoji: '📊',
    description: 'Corretores de seguros, consórcios, consultores financeiros e vendas B2B.',
    professions: [
      {
        id: 'corretor-seguros',
        name: 'Corretor de Seguros (Auto, Vida, Saúde)',
        icon: 'Shield',
        categoryId: 'vendas-consultivas',
        description: 'Seguro auto, residencial, plano de saúde e seguro de vida com foco em proteção patrimonial.',
        commonObjection: '"Nunca usei seguro, acho que não preciso / Muito caro"',
        typicalTicket: 'R$ 1.200 - R$ 8.000/ano',
        aiContext: {
          roleDescription: 'Corretor de seguros consultivo. Foco em identificar riscos reais para a família ou empresa e apresentar apólices sob medida com coberturas essenciais sem custos inúteis.',
          typicalObjections: ['Achar que nunca vai acontecer nada', 'Seguradora anterior demorou para indenizar'],
          discoveryQuestions: ['Hoje quem depende financeiramente da sua renda?', 'Qual o uso principal do seu veículo?'],
          evaluationCriteria: ['Sensibilizou sobre proteção sem apelo sensacionalista?', 'Comparou coberturas reais?'],
          recommendedTechniques: ['spin-selling', 'venda-consultiva'],
        },
        sampleMessages: [
          {
            title: 'Comparativo de coberturas e franquia reduzida',
            situation: 'Cliente renovando seguro ou contratando primeira vez.',
            text: 'Olá, [Nome]! Cotei em 6 seguradoras líderes e encontrei uma opção que inclui carro reserva ilimitado e guincho sem limite de km por um valor menor que a sua apólice anterior. Posso te enviar o comparativo em uma página?',
            tip: 'Mostrar que você garimpou a melhor opção gera gratidão.',
          },
        ],
      },
    ],
  },

  // 8. SAÚDE, FITNESS E BEM-ESTAR
  {
    id: 'saude-fitness',
    title: 'Saúde, Fitness & Bem-Estar',
    emoji: '🏋️',
    description: 'Personal trainers, academias, nutricionistas, clínicas médicas e bem-estar.',
    professions: [
      {
        id: 'personal-trainer',
        name: 'Personal Trainer & Consultoria Fitness',
        icon: 'Dumbbell',
        categoryId: 'saude-fitness',
        description: 'Aulas particulares, treinos em academia/parque e consultoria de treino online.',
        commonObjection: '"A mensalidade da academia já é cara / Falta de tempo"',
        typicalTicket: 'R$ 250 - R$ 1.200/mês',
        aiContext: {
          roleDescription: 'Personal trainer. Foco em quebrar o sedentarismo, adaptar treinos à rotina corrida do aluno, prevenir lesões e garantir disciplina.',
          typicalObjections: ['Preguiça / Falta de tempo / Histórico de desistências'],
          discoveryQuestions: ['Qual é o seu objetivo nos próximos 3 meses (emagrecer, dor nas costas, massa muscular)?'],
          evaluationCriteria: ['Focou na dor e no objetivo do aluno, não apenas no número de aulas?'],
          recommendedTechniques: ['spin-selling', 'venda-consultiva', 'tecnicas-fechamento'],
        },
        sampleMessages: [
          {
            title: 'Treino adaptado à rotina sem dietas malucas',
            situation: 'Aluno indeciso que já desistiu de academias antes.',
            text: 'E aí, [Nome]! Entendo perfeitamente. O erro da maioria é tentar treinar 2 horas por dia logo de cara. Meu método foca em 40 minutos eficientes, 3x por semana, adaptados ao seu ritmo. Que tal fazermos uma aula experimental gratuita esta semana para você sentir a diferença?',
            tip: 'Elimina a barreira de esforço e convida para testar na prática.',
          },
        ],
      },
      {
        id: 'nutricionista',
        name: 'Nutricionista Clínico & Esportivo',
        icon: 'Apple',
        categoryId: 'saude-fitness',
        description: 'Planos alimentares personalizados para emagrecimento, hipertrofia e exames de sangue.',
        commonObjection: '"Tenho medo de dieta muito restritiva / Não gosto de passar fome"',
        typicalTicket: 'R$ 180 - R$ 600 por consulta/plano',
        aiContext: {
          roleDescription: 'Nutricionista. Foco em reeducação alimentar sustentável com alimentos do dia a dia, sem dietas punitivas.',
          typicalObjections: ['Medo de gastar caro com comida especial', 'Dificuldade de cozinhar'],
          discoveryQuestions: ['Como é a sua rotina de refeições hoje?'],
          evaluationCriteria: ['Acolheu a rotina do paciente sem julgamentos?'],
          recommendedTechniques: ['venda-consultiva', 'spin-selling'],
        },
        sampleMessages: [
          {
            title: 'Alimentação prática com comida que você já come',
            situation: 'Paciente com medo de restrições severas.',
            text: 'Olá, [Nome]! Meu acompanhamento não trabalha com passar fome nem ingredientes caros. Nós adaptamos a comida que você já gosta dentro das quantidades certas para sua meta. Você prefere atendimento presencial no consultório ou online por vídeo?',
            tip: 'Acalma o medo de restrição e oferece facilidade de formato.',
          },
        ],
      },
    ],
  },
];

// Helper: Obter todas as profissões planificadas
export const ALL_PROFESSIONS: ProfessionNiche[] = ALL_PROFESSION_CATEGORIES.flatMap(
  (c) => c.professions
);

// Helper: Buscar profissão por ID
export function getProfessionById(id: string): ProfessionNiche | undefined {
  return ALL_PROFESSIONS.find((p) => p.id === id);
}
