import {
  AcademyLevel,
  SalesTechnique,
  PracticalChallenge,
  AcademyLevelNumber,
} from '../types';

export const ACADEMY_LEVELS: AcademyLevel[] = [
  {
    level: 1,
    name: 'Nível 1 — Fundamentos',
    tagline: 'Primeiro Contato e Conexão Humana',
    description: 'Aprenda a iniciar conversas sem parecer invasivo, ouvir ativamente, fazer boas perguntas e descobrir necessidades reais no WhatsApp.',
    badge: '🌱 Iniciante',
    color: '#25D366',
    minCompletedSessions: 0,
  },
  {
    level: 2,
    name: 'Nível 2 — Atendimento Estratégico',
    tagline: 'Investigação e Apresentação de Solução',
    description: 'Investigue dores profundas com método, gere valor antes do preço e apresente produtos ou serviços conectados exatamente ao que o cliente procura.',
    badge: '⚡ Consultor',
    color: '#3B82F6',
    minCompletedSessions: 3,
  },
  {
    level: 3,
    name: 'Nível 3 — Objeções e Negociação',
    tagline: 'Firmeza sem Pressão Comercial',
    description: 'Contorne com elegância: "está caro", "vou pensar", comparações com concorrentes e indecisão, sem dar descontos desnecessários.',
    badge: '🛡️ Negociador',
    color: '#F59E0B',
    minCompletedSessions: 7,
  },
  {
    level: 4,
    name: 'Nível 4 — Conversão e Domínio',
    tagline: 'Fechamento Natural e Alta Conversão',
    description: 'Conduza atendimentos completos de ponta a ponta, combine técnicas dinamicamente e proponha próximos passos e fechamentos com confiança máxima.',
    badge: '👑 Mestre em Vendas',
    color: '#8B5CF6',
    minCompletedSessions: 12,
  },
];

export const SALES_TECHNIQUES: SalesTechnique[] = [
  {
    id: 'spin-selling',
    title: 'SPIN Selling no WhatsApp',
    shortName: 'SPIN Selling',
    emoji: '🧭',
    category: 'Diagnóstico & Perguntas',
    level: 2,
    simpleExplanation:
      'Método criado por Neil Rackham focado em 4 tipos de perguntas: Situação (entender o contexto), Problema (identificar a dor), Implicação (mostrar o custo de não resolver) e Necessidade de Solução (fazer o cliente pedir a solução).',
    howItWorks: [
      '1. Perguntas de Situação: coletar dados básicos do momento atual do cliente.',
      '2. Perguntas de Problema: trazer à tona insatisfações ou dificuldades enfrentadas.',
      '3. Perguntas de Implicação: ajudar o cliente a perceber as consequências negativas de adiar uma solução.',
      '4. Perguntas de Necessidade: fazer o próprio cliente verbalizar o valor de resolver isso agora.',
    ],
    whenToUse:
      'Ideal para vendas de médio e alto ticket, serviços ou quando o cliente está hesitante e ainda não percebeu a urgência de fechar.',
    poorApproachExample:
      '“Oi! Temos esse plano por R$ 350. Quer fechar hoje? É o melhor do mercado.” (Tentativa prematura de empurrar o produto sem entender nada).',
    improvedApproachExample:
      '“Entendi o que você precisa! Me conta: há quanto tempo você vem enfrentando essa situação? Se você não resolver isso esse mês, que tipo de impacto isso traz pra sua rotina ou faturamento?”',
    nicheSpecificExampleTip:
      'Em vez de enviar a tabela de preços logo no primeiro minuto, faça 2 perguntas para fazer o cliente sentir o peso do problema.',
    practicalExercise: {
      title: 'Elaborar uma Pergunta de Implicação',
      description: 'Crie uma pergunta que faça o cliente refletir sobre o prejuízo ou cansaço de continuar com o problema atual.',
      taskPrompt: 'O cliente disse que está fazendo tudo manualmente e perdendo tempo. Como você pergunta sobre o impacto disso?',
      sampleSolution: '“E esse tempo gasto manualmente... o que você deixa de produzir ou atender no seu dia a dia por causa disso?”',
    },
    recommendedModalityId: 'descoberta-necessidades',
    customerProfileDefault: 'indeciso',
  },
  {
    id: 'aida',
    title: 'Método AIDA para Mensagens Rápidas',
    shortName: 'AIDA',
    emoji: '🎯',
    category: 'Estrutura de Conversão',
    level: 1,
    simpleExplanation:
      'AIDA organiza qualquer mensagem em 4 blocos sequenciais: Atenção (chamar o olho), Interesse (falar de algo relevante para ele), Desejo (mostrar o benefício e transformação) e Ação (chamar para um passo simples).',
    howItWorks: [
      'A - Atenção: Primeira linha impactante e personalizada.',
      'I - Interesse: Conexão direta com uma dor ou objetivo que o cliente tem.',
      'D - Desejo: Prova social, benefício exclusivo ou alívio imediato.',
      'A - Ação: Chamada para ação clara com pergunta aberta ou escolha binária.',
    ],
    whenToUse:
      'Mensagens de primeiro contato, follow-up, reativação de clientes antigos ou envio de propostas resumidas no WhatsApp.',
    poorApproachExample:
      '“Olá, tudo bem? Segue em anexo nossa apresentação com 20 páginas com todas as informações sobre nossos serviços.” (Pesado, chato e sem chamada clara).',
    improvedApproachExample:
      '“Oi Juliana! Vi que você buscou opções de imóveis no bairro Jardins [A]. Separei 2 opções que acabaram de liberar antes de ir pro portal [I], com varanda gourmet e 2 vagas [D]. Prefere que eu envie as fotos por aqui ou um vídeo de 1 minuto? [A]”',
    nicheSpecificExampleTip:
      'Sempre termine com UMA pergunta objetiva que exija pouco esforço para o cliente responder.',
    practicalExercise: {
      title: 'Montar Chamada para Ação (CTA) Leve',
      description: 'Substitua "Qualquer dúvida estou à disposição" por uma pergunta de ação prática.',
      taskPrompt: 'Você acabou de enviar uma foto de um produto. Como encerra a mensagem?',
      sampleSolution: '“Você busca essa cor específica ou gostaria de ver outras opções que combinam com você?”',
    },
    recommendedModalityId: 'primeiro-contato',
    customerProfileDefault: 'apressado',
  },
  {
    id: 'venda-consultiva',
    title: 'Venda Consultiva e Empatia',
    shortName: 'Venda Consultiva',
    emoji: '🤝',
    category: 'Relacionamento & Confiança',
    level: 2,
    simpleExplanation:
      'Postura de especialista conselheiro, não de tirador de pedido. Você orienta a melhor escolha para a realidade do cliente, gerando confiança absoluta.',
    howItWorks: [
      '1. Validação imediata: acolher a dúvida do cliente com respeito.',
      '2. Diagnóstico sincero: se o produto mais caro não for o melhor para ele, recomende a opção certa.',
      '3. Transparência comercial: explicar o porquê de cada recomendação.',
      '4. Parceria de longo prazo: focar no sucesso dele, não apenas na comissão do dia.',
    ],
    whenToUse:
      'Sempre que o cliente tiver medo de errar, pedir indicações ou quando você vender serviços de alta responsabilidade (saúde, estética, imóveis, consultoria, reformas).',
    poorApproachExample:
      '“Compra esse aqui que é o mais caro e o que todo mundo leva.”',
    improvedApproachExample:
      '“Para o seu momento atual, o pacote intermediário é muito mais indicado que o completo. Você economiza agora e atinge exatamente o resultado que conversamos. Faz sentido pra você?”',
    nicheSpecificExampleTip:
      'Dizer "não recomendo essa opção pra você pelo motivo X" gera 10 vezes mais autoridade do que tentar vender tudo.',
    practicalExercise: {
      title: 'Demonstrar Recomendação Sincera',
      description: 'Explique por que uma opção atende melhor a situação do cliente.',
      taskPrompt: 'O cliente quer contratar o pacote mais caro mas não tem tempo de usá-lo.',
      sampleSolution: '“Como seu tempo está corrido esse mês, sugiro começar pelo módulo essencial. Assim você tem resultado sem desperdiçar investimento.”',
    },
    recommendedModalityId: 'conexao-confianca',
    customerProfileDefault: 'desconfiado',
  },
  {
    id: 'tratamento-objecoes',
    title: 'Contorno de Objeções: F.A.O. e Empatia',
    shortName: 'Tratamento de Objeções',
    emoji: '🛡️',
    category: 'Negociação & Firmeza',
    level: 3,
    simpleExplanation:
      'Método de 3 passos: Filtro (concordar sem se rebaixar), Alinhamento (isolar a verdadeira dúvida) e Objeção/Orientação (apresentar nova perspectiva ou próximo passo seguro).',
    howItWorks: [
      '1. Não confronte nem debata: comece com "Entendo perfeitamente sua preocupação..."',
      '2. Isole a objeção: descubra se o problema é realmente o dinheiro ou a falta de confiança no retorno.',
      '3. Reenquadre o valor: compare com o custo de continuar sem a solução.',
      '4. Próximo passo seguro: ofereça uma garantia, teste ou condição facilitada.',
    ],
    whenToUse:
      'Quando o cliente disser: "Tá caro", "Vou falar com meu marido/esposa", "Pesquisando outras opções" ou "Agora não".',
    poorApproachExample:
      '“Não tá caro nada, nosso produto tem qualidade superior aos outros que você viu por aí.” (Reativo e arrogante).',
    improvedApproachExample:
      '“Faz todo sentido sua comparação! O valor realmente reflete um investimento sério. Me conta uma coisa: além do valor, tem mais algum detalhe que te deixou em dúvida sobre os resultados?”',
    nicheSpecificExampleTip:
      'Nunca dê desconto logo no primeiro "tá caro". Primeiro valide se o cliente entendeu os benefícios.',
    practicalExercise: {
      title: 'Isolar a Objeção de Preço',
      description: 'Descubra se o cliente tem outra dúvida oculta por trás do "tá caro".',
      taskPrompt: 'O cliente disse que achou o orçamento pesado.',
      sampleSolution: '“Compreendo perfeitamente. Se o valor couber no seu fluxo, você sente que esse é o serviço ideal para o que você precisa?”',
    },
    recommendedModalityId: 'objecoes',
    customerProfileDefault: 'sensivel-preco',
  },
  {
    id: 'tecnicas-fechamento',
    title: 'Técnicas de Fechamento Natural',
    shortName: 'Fechamento Natural',
    emoji: '✅',
    category: 'Conversão & Ação',
    level: 4,
    simpleExplanation:
      'Conduzir o fechamento como a consequência natural da conversa, utilizando escolhas alternativas, fechamento por urgência real ou fechamento por passo seguinte.',
    howItWorks: [
      '1. Fechamento de Alternativa: nunca pergunte "Quer comprar?". Pergunte "Prefere no Pix com 5% ou parcelar em 3x?".',
      '2. Fechamento de Agendamento: "Tenho terça às 14h ou quinta às 10h. Qual encaixa melhor na sua agenda?"',
      '3. Fechamento de Próximo Passo: "Se você me enviar seu e-mail agora, já gero a reserva e seguro essa condição."',
      '4. Pergunta Termômetro: "De 0 a 10, o quanto essa proposta atende o que você estava procurando?"',
    ],
    whenToUse:
      'Depois que o cliente tirou as dúvidas, concordou com os benefícios e está apenas esperando um empurrão amigável.',
    poorApproachExample:
      '“E aí, vamos fechar? Posso emitir o contrato agora?” (Gera pressão e ansiedade).',
    improvedApproachExample:
      '“Ficou bem claro como funciona! Para darmos início e garantir a vaga dessa semana, você prefere acertar pelo Pix ou cartão de crédito?”',
    nicheSpecificExampleTip:
      'Facilite a tomada de decisão oferecendo sempre duas opções simples em vez de uma pergunta aberta difícil.',
    practicalExercise: {
      title: 'Criar Fechamento por Duas Opções',
      description: 'Proponha duas alternativas simples para o cliente escolher.',
      taskPrompt: 'O cliente disse que gostou da proposta de serviço.',
      sampleSolution: '“Excelente! Para agendarmos sua primeira sessão, você tem melhor disponibilidade pela manhã ou à tarde?”',
    },
    recommendedModalityId: 'fechamento',
    customerProfileDefault: 'muito-interessado',
  },
  {
    id: 'atendimento-relacionamento',
    title: 'Follow-up e Recuperação sem Ser Chato',
    shortName: 'Follow-up Elegante',
    emoji: '🔄',
    category: 'Pós-Contato & Reengajamento',
    level: 3,
    simpleExplanation:
      'Como reativar conversas paradas ou clientes que sumiram sem mandar o temido "Oi sumido" ou "E aí, pensou?". Sempre traga um novo motivo de valor real.',
    howItWorks: [
      '1. Regra de Ouro: nunca cobre resposta. Ofereça valor.',
      '2. Traga novidades: uma condição nova, uma peça que chegou, uma matéria que lembrou dele.',
      '3. Desarme a pressão: deixe claro que está tudo bem se ele ainda não estiver no momento.',
      '4. Pergunta de encerramento amigável: "Ainda faz sentido pra você ou prefere que eu encerre seu cadastro por aqui?"',
    ],
    whenToUse:
      'Cliente visualizou a proposta e não respondeu há 48h, ou lead antigo que esfriou no mês passado.',
    poorApproachExample:
      '“Oi, visualizou e não respondeu... vai querer fechar ou não?” (Desesperado e grosseiro).',
    improvedApproachExample:
      '“Oi Ricardo, tudo bem? Lembrei de você hoje porque liberou uma condição especial para a data que você queria. Ainda faz sentido vermos isso ou você já resolveu por aí?”',
    nicheSpecificExampleTip:
      'Dar ao cliente a liberdade de dizer "não" com elegância faz ele responder muito mais rápido.',
    practicalExercise: {
      title: 'Redigir Follow-up com Saída Honrosa',
      description: 'Envie uma mensagem dando permissão para o cliente dizer se ainda tem interesse.',
      taskPrompt: 'Cliente sumiu há 3 dias após receber o valor do orçamento.',
      sampleSolution: '“Oi Ana! Imagino que sua semana esteja corrida. Só passando pra ver se você ainda quer dar sequência ou se prefere pausar por enquanto?”',
    },
    recommendedModalityId: 'follow-up',
    customerProfileDefault: 'indeciso',
  },
];

export const PRACTICAL_CHALLENGES: PracticalChallenge[] = [
  {
    id: 'desafio-1',
    title: 'Desafio 1: Melhorar uma Resposta Genérica',
    techniqueId: 'aida',
    level: 1,
    emoji: '✏️',
    scenario: 'Cliente manda mensagem dizendo: "Olá, quanto custa o serviço?".',
    customerMessage: 'Olá! Qual o valor do trabalho de vocês?',
    instruction:
      'Em vez de apenas mandar o preço seco "R$ 300", monte uma resposta acolhedora com contexto e uma pergunta no final.',
    exampleGoodAnswer:
      '“Olá! Que bom ter você por aqui. Nossos planos começam a partir de R$ 250 dependendo do que você precisa. Para te indicar o pacote ideal, qual é a sua principal necessidade hoje?”',
    whyItWorks: 'Evita afastar o cliente por preço e abre diálogo para entender o contexto.',
  },
  {
    id: 'desafio-2',
    title: 'Desafio 2: Pergunta de Diagnóstico (SPIN)',
    techniqueId: 'spin-selling',
    level: 2,
    emoji: '🔍',
    scenario: 'O cliente disse que já tentou resolver o problema antes e não deu certo.',
    customerMessage: 'Já tentei fazer isso mês passado com outra empresa e não funcionou.',
    instruction:
      'Faça uma pergunta empática para entender o motivo do fracasso anterior antes de prometer nada.',
    exampleGoodAnswer:
      '“Entendo totalmente sua frustração! O que exatamente não funcionou com eles que você gostaria que fosse diferente agora?”',
    whyItWorks: 'Demonstra escuta ativa e descobre o critério exato que o cliente usará para te avaliar.',
  },
  {
    id: 'desafio-3',
    title: 'Desafio 3: Contornar "Está Caro"',
    techniqueId: 'tratamento-objecoes',
    level: 3,
    emoji: '💰',
    scenario: 'O cliente elogiou a proposta mas reclamou do valor.',
    customerMessage: 'Gostei bastante do seu trabalho, mas achei bem caro comparado a outros.',
    instruction:
      'Valide o comentário do cliente e faça uma pergunta para isolar o valor percebido sem baixar o preço.',
    exampleGoodAnswer:
      '“Faz todo sentido sua comparação! O valor reflete acompanhamento individual e garantia de resultado. Além da questão do investimento, o formato da solução te atende 100%?”',
    whyItWorks: 'Descobre se a barreira é realmente o bolso ou se ainda falta confiança no retorno.',
  },
  {
    id: 'desafio-4',
    title: 'Desafio 4: Retomada sem Pressão (Follow-up)',
    techniqueId: 'atendimento-relacionamento',
    level: 3,
    emoji: '👻',
    scenario: 'O cliente visualizou o orçamento há 48 horas e não retornou.',
    customerMessage: '(Mensagem visualizada há 2 dias sem resposta)',
    instruction:
      'Envie uma mensagem educada de reengajamento com um motivo real e saída honrosa.',
    exampleGoodAnswer:
      '“Oi Carlos! Sei que a rotina é corrida. Conseguiu dar uma olhada na proposta com calma ou prefere tirar alguma dúvida antes de decidir?”',
    whyItWorks: 'Mostra respeito ao tempo do cliente sem parecer desesperado ou agressivo.',
  },
  {
    id: 'desafio-5',
    title: 'Desafio 5: Fechamento por Duas Opções',
    techniqueId: 'tecnicas-fechamento',
    level: 4,
    emoji: '🚀',
    scenario: 'O cliente tirou todas as dúvidas e disse: "Ficou ótimo, entendi tudo!".',
    customerMessage: 'Ficou ótimo, entendi tudo como funciona!',
    instruction:
      'Proponha o próximo passo com duas opções objetivas de pagamento ou agendamento.',
    exampleGoodAnswer:
      '“Perfeito! Para formalizarmos sua vaga dessa semana, você prefere acertar no Pix à vista com 5% de desconto ou parcelar no cartão em até 3x sem juros?”',
    whyItWorks: 'Facilita a decisão transformando o "se vai comprar" em "como prefere pagar".',
  },
];
